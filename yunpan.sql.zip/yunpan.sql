-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1:3306
-- 生成日期： 2026-09-27 13:31:05
-- 服务器版本： 8.0.43
-- PHP 版本： 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `yunpan`
--

-- --------------------------------------------------------

--
-- 表的结构 `all_book`
--

CREATE TABLE IF NOT EXISTS `all_book` (
  `book_id` int NOT NULL AUTO_INCREMENT,
  `book_slug` varchar(100) NOT NULL,
  `book_name` varchar(100) NOT NULL,
  `book_author` varchar(100) NOT NULL,
  `book_ori_author` varchar(100) NOT NULL,
  `book_isbn` varchar(30) NOT NULL,
  `book_content` text NOT NULL,
  `book_info` text NOT NULL,
  `book_status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`book_id`),
  UNIQUE KEY `book_slug` (`book_slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- 表的结构 `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `book_id` int NOT NULL AUTO_INCREMENT,
  `book_slug` varchar(300) NOT NULL,
  `book_name` text NOT NULL,
  `book_status` int NOT NULL DEFAULT '0',
  `book_date` varchar(50) NOT NULL,
  PRIMARY KEY (`book_id`),
  UNIQUE KEY `book_slug` (`book_slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- 表的结构 `link`
--

CREATE TABLE IF NOT EXISTS `link` (
  `link_id` int NOT NULL AUTO_INCREMENT,
  `link_slug` varchar(300) NOT NULL,
  `link_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `link_desc` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `link_url` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `isbn_list` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `content_length_kb` int NOT NULL DEFAULT '0',
  `link_status` int NOT NULL DEFAULT '0',
  `link_date` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `link_download` int DEFAULT '0',
  PRIMARY KEY (`link_id`),
  UNIQUE KEY `link_slug` (`link_slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- 表的结构 `yunpan_link`
--

CREATE TABLE IF NOT EXISTS `yunpan_link` (
  `link_id` int NOT NULL AUTO_INCREMENT,
  `link_slug` varchar(300) NOT NULL,
  `link_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `link_desc` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `link_words` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `link_url` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `link_psw` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `isbn_list` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `content_length_kb` int NOT NULL DEFAULT '0',
  `link_status` int NOT NULL DEFAULT '0',
  `link_date` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `link_download` int DEFAULT '0',
  `file_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `file_category` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `file_tag` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `file_size` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `file_time` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `file_dir` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `userid` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `username` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `file_id` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `link_send` int DEFAULT '0',
  `file_chk` text,
  `file_download_url` text,
  `file_is_download` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`link_id`),
  UNIQUE KEY `link_slug` (`link_slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- 转储表的索引
--

--
-- 表的索引 `all_book`
--
ALTER TABLE `all_book` ADD FULLTEXT KEY `book_content` (`book_content`);

--
-- 表的索引 `yunpan_link`
--
ALTER TABLE `yunpan_link` ADD FULLTEXT KEY `link_words` (`link_words`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
