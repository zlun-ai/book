<?php
include "config.php";
include "fun.php";
?>
<?php
$q = get_param("keyword");
//$q = base64_decode($q);
//echo $q;
$safe_q = get_safe_search($q);
get_search($q);
?>