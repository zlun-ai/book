<?php
require_once __DIR__ . '/src/Autoloader.php';
\App\Config::load(__DIR__ . '/config/app.php');
\App\Cache::configure(\App\Config::cache());

\App\Cache::flush();

echo "Cache cleared." . PHP_EOL;

// Test Service layer
$service = new \App\Service\BookService();

// Get initial hot books
echo "=== Before download ===" . PHP_EOL;
$result = $service->getHot(5);
echo 'Hot books: ' . count($result) . PHP_EOL;
foreach ($result as $i => $book) {
    echo "  {$i}. {$book->title} (downloads: {$book->downloadCount})" . PHP_EOL;
}

// Test recordDownload
if (!empty($result)) {
    $slug = $result[0]->slug;
    echo PHP_EOL . "=== Recording download for: {$slug} ===" . PHP_EOL;
    $service->recordDownload($slug, 'test');
    
    // Check updated count
    $book = $service->getBook($slug);
    echo "After download: {$book->title} (downloads: {$book->downloadCount})" . PHP_EOL;
    
    // Check hot books again
    echo PHP_EOL . "=== After download ===" . PHP_EOL;
    $result = $service->getHot(5);
    echo 'Hot books: ' . count($result) . PHP_EOL;
    foreach ($result as $i => $book) {
        echo "  {$i}. {$book->title} (downloads: {$book->downloadCount})" . PHP_EOL;
    }
}