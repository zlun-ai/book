<?php
include "./inc/fenci.php";
$text = "a ad dfbd this this is a 单独发第三方安抚大概违法打分.padf dafdf44533er3 844";
get_fenci_words($text);
?>