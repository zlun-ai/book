<?php
require_once __DIR__ . '/src/Autoloader.php';
\App\Config::load(__DIR__ . '/config/app.php');

$pdo = \App\Database::getInstance();
try {
    $pdo->exec('ALTER TABLE all_links ADD COLUMN last_download_time datetime NULL DEFAULT NULL AFTER link_download');
    echo 'Column last_download_time added successfully.' . PHP_EOL;
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage() . PHP_EOL;
}