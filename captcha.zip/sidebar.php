<?php
include_once "config.php";
include_once "post.php";
?>
<?php
?>
<?php
$all_cats = get_all_cats();
include_once "template/link-sidebar-demo.html";
?>