<?php
include "config.php";
include "fun.php";
?>
<?php
$all_cats = get_all_cats();
?>
<?php
$c_cat_name = get_param("cat");

$page = get_param("p");
//echo $c_cat_name;
if (!array_key_exists($c_cat_name, $all_cats)) {
	die("参数错误".$c_cat_name);
}
$title = $c_cat_name;
if($page>1){
	$title .=" - 第".$page."页";
}
$c_cat_icon = $all_cats[$c_cat_name][1];
$c_cat_url = $all_cats[$c_cat_name][0];
?>
<?php
if($page<1 || $page>5){
	die("参数错误".$c_cat_name);
}
$res = get_files_by_cat_name_from_local($c_cat_name, $page, 30);
//print_r($res);
?>
<?php
include "template/link-cat-demo.html";

?>