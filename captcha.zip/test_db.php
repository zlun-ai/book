<?php
/**
 * 测试脚本：验证数据库连接和查询
 * 运行方式：php test_db.php
 */

require_once __DIR__ . '/src/Autoloader.php';
\App\Config::load(__DIR__ . '/config/app.php');
\App\Cache::configure(\App\Config::cache());

use App\Database;
use App\Repository\BookRepository;
use App\Service\BookService;

echo "=== 数据库连接测试 ===\n";
try {
    $pdo = Database::getInstance();
    echo "✓ 数据库连接成功\n";
    
    // 检查表是否存在
    $tables = $pdo->query("SHOW TABLES LIKE 'all_links'")->fetchAll();
    if ($tables) {
        echo "✓ 表 all_links 存在\n";
    } else {
        echo "✗ 表 all_links 不存在！\n";
        exit(1);
    }
    
    // 检查数据量
    $count = $pdo->query("SELECT COUNT(*) as c FROM all_links")->fetch()['c'] ?? 0;
    echo "✓ all_links 记录数: $count\n";
    
    if ($count === 0) {
        echo "\n⚠️ 表中没有数据！需要先导入数据。\n";
    }
    
} catch (\Throwable $e) {
    echo "✗ 数据库连接失败: " . $e->getMessage() . "\n";
    exit(1);
}

echo "\n=== Repository 查询测试 ===\n";
$repo = new BookRepository();

// 测试 getLatest
echo "\n1. 测试 getLatest(5):\n";
$latest = $repo->getLatest(5);
echo "结果数量: " . count($latest) . "\n";
foreach ($latest as $i => $book) {
    echo "  [$i] {$book->title} | {$book->category} | {$book->format} | {$book->size}\n";
}

// 测试 getHot
echo "\n2. 测试 getHot(5, 30):\n";
$hot = $repo->getHot(5, 30);
echo "结果数量: " . count($hot) . "\n";
foreach ($hot as $i => $book) {
    echo "  [$i] {$book->title} | {$book->category} | {$book->format} | {$book->size}\n";
}

// 测试 getCategories
echo "\n3. 测试 getCategories():\n";
$cats = $repo->getCategories();
echo "分类数量: " . count($cats) . "\n";
foreach (array_slice($cats, 0, 5) as $cat) {
    echo "  - {$cat['name']}: {$cat['count']} 本\n";
}

// 测试 Service 层
echo "\n=== Service 层测试 ===\n";
$service = new BookService();

echo "\n4. 测试 getLatest(3):\n";
$latest = $service->getLatest(3);
echo "结果数量: " . count($latest) . "\n";
foreach ($latest as $i => $book) {
    echo "  [$i] {$book->title}\n";
}

echo "\n5. 测试 getHot(3):\n";
$hot = $service->getHot(3);
echo "结果数量: " . count($hot) . "\n";
foreach ($hot as $i => $book) {
    echo "  [$i] {$book->title}\n";
}

echo "\n=== 缓存测试 ===\n";
echo "缓存目录: " . sys_get_temp_dir() . '/yunlio_cache' . "\n";
echo "缓存文件数量: " . count(glob(sys_get_temp_dir() . '/yunlio_cache/*.cache')) . "\n";

echo "\n=== 测试完成 ===\n";