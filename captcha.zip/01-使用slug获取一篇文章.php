<?php
//----------------------post---------------------
include "config.php";
include "Request.php";
include "post.php";

function get_url_content($url){
    echo $url;
    $request = new Request($url);
    $request->execute();
    $response = $request->getResponse();
    //echo $request->getError();
    return $response;
}

# 按照slug文章,包括类型等
function get_post_by_slug($slug, $post_type = "posts", $field=""){
    //http://127.0.0.1/wordpress/wp-json/wp/v2/tutorial?slug=llamafactory&_fields=author,id,excerpt,title,link
    if($field == ""){
        $url = Config::$url.$post_type."?slug=".$slug."&_embed=true";
    } else{
        $url = Config::$url.$post_type."?slug=".$slug."&_fields=".$field;
    }

    $json = get_url_content($url);

    $obj = json_decode($json)[0];          // 转换为对象


    $p = new Post();

    $p->post_title = $obj->title->rendered;
    $p->post_link  = $obj->link;
    $p->post_slug = $obj->slug;
    $p->post_modified  = $obj->modified;
    $p->post_id  = $obj->id;
    $p->post_excerpt = $obj->excerpt->rendered;

    # 缩略图
    $p->post_img = $obj->_embedded->{'wp:featuredmedia'}[0]->source_url;
    $p->init_term($obj->_embedded->{"wp:term"});
    return $p;
 }
print_r(get_post_by_slug("llamafactory","tutorial"));

// 获取最近文章
function get_latest_posts($post_type="posts", $num = 10, $field=""){
    #?_embed=true
    #http://test.com/wp-json/wp/v2/posts?page=1&per_page=5
    if($field == ""){
        $url = Config::$url.$post_type."?_embed=true";
    } else{
        $url = Config::$url.$post_type."?_fields=".$field."&_embed=true";
    }

    $json = get_url_content($url);
    $objx = json_decode($json);
    //print_r($objx);
    echo "---------------------";
    $posts = array();
    foreach($objx as $obj){
        $p = new Post();

        $p->post_title = $obj->title->rendered;
        $p->post_link  = $obj->link;
        $p->post_slug = $obj->slug;
        $p->post_modified  = $obj->modified;
        $p->post_id  = $obj->id;
        $p->post_excerpt = $obj->excerpt->rendered;

        # 缩略图
        $p->post_img = $obj->_embedded->{'wp:featuredmedia'}[0]->source_url;
        $p->init_term($obj->_embedded->{"wp:term"});
        $posts[] = $p;
    }
    print_r($posts);
}
get_latest_posts($post_type="posts", $num = 10);
?>


