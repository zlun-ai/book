<?php
header('Content-Type: text/xml; charset=UTF-8');
include "fun.php";
?>
<?php
$xml = get_param("xml");
//echo $xml;
$url = "https://frontendpik.com/".$xml.".xml";
$content = get_url_content($url);

// 去除
$content = preg_replace('/<\?xml-stylesheet[^>]*>/', '', $content); 
$content = str_replace("<![CDATA[","",$content);
$content = str_replace("]]>","",$content);

$content = str_replace("https://frontendpik.com","https://www.yunlio.com",$content);
echo $content;
?>