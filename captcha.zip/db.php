<?php
/**
 * Database - 单例模式MySQL数据库连接类
 */
include_once 'config.php';
class Database {
    /** @var PDO|null 数据库连接实例 */
    private static $instance = null;
    
    /** @var string 主机名 */
    private $host = DB_HOST;
    
    /** @var string 数据库名 */
    private $dbname = DB_NAME;
    
    /** @var string 用户名 */
    private $username = DB_USER;
    
    /** @var string 密码 */
    private $password = DB_PSW;
    
    /** @var array PDO配置选项 */
    private $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_TIMEOUT => 5
    ];
    
    /**
     * 私有构造函数，防止直接实例化
     */
    private function __construct() {
        try {
            $dsn = "mysql:host={$this->host};dbname={$this->dbname};charset=utf8mb4";
            self::$instance = new PDO($dsn, $this->username, $this->password, $this->options);
        } catch (PDOException $e) {
            // 记录错误日志
            die("数据库连接失败: " . $e->getMessage());
            // 根据环境决定是否显示详细错误
            if ($_SERVER['SERVER_NAME'] === 'localhost') {
                die("数据库连接错误: " . $e->getMessage());
            } else {
                die("服务暂时不可用，请稍后再试");
            }
        }
    }
    
    /**
     * 禁止克隆
     */
    public function __clone() {}
    
    /**
     * 禁止反序列化
     */
    public function __wakeup() {}
    
    /**
     * 获取数据库连接实例
     * 
     * @return PDO
     */
    public static function getInstance() {
        if (self::$instance === null) {
            new self();
        }
        return self::$instance;
    }
    
    /**
     * 执行查询（SELECT语句）
     * 
     * @param string $sql SQL查询语句
     * @param array $params 参数绑定
     * @return array 查询结果
     */
    public static function query($sql, $params = []) {
        try {
            $stmt = self::getInstance()->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("查询错误: " . $e->getMessage() . " - SQL: " . $sql);
            return false;
        }
    }
    
    /**
     * 执行非查询语句（INSERT, UPDATE, DELETE）
     * 
     * @param string $sql SQL语句
     * @param array $params 参数绑定
     * @return int|bool 影响的行数或false
     */
    public static function execute($sql, $params = []) {
        try {
            $stmt = self::getInstance()->prepare($sql);
            $stmt->execute($params);
            return $stmt->rowCount();
        } catch (PDOException $e) {
            error_log("执行错误: " . $e->getMessage() . " - SQL: " . $sql);
            return false;
        }
    }
    
    /**
     * 获取最后插入的ID
     * 
     * @return string
     */
    public static function lastInsertId() {
        return self::getInstance()->lastInsertId();
    }
    
    /**
     * 开始事务
     */
    public static function beginTransaction() {
        return self::getInstance()->beginTransaction();
    }
    
    /**
     * 提交事务
     */
    public static function commit() {
        return self::getInstance()->commit();
    }
    
    /**
     * 回滚事务
     */
    public static function rollBack() {
        return self::getInstance()->rollBack();
    }
    
    /**
     * 关闭连接
     */
    public static function closeConnection() {
        self::$instance = null;
    }
}

// 使用示例
//try {
    // 1. 查询数据
    //$users = Database::query("SELECT * FROM all_links WHERE link_id = ?", [1]);
    //if ($users) {
        //echo "找到 " . count($users) . " 个活跃用户<br>";
        //foreach ($users as $user) {
            //echo "ID: {$user['link_id']}, 名称: {$user['link_url']}<br>";
        //}
   // }
    /*
    // 2. 插入数据
    $result = Database::execute(
        "INSERT INTO users (name, email, created_at) VALUES (?, ?, NOW())",
        ['张三', 'zhangsan@example.com']
    );
    
    if ($result) {
        $newUserId = Database::lastInsertId();
        echo "成功插入用户，ID: $newUserId<br>";
        
        // 3. 更新数据
        $updated = Database::execute(
            "UPDATE users SET status = ? WHERE id = ?",
            [1, $newUserId]
        );
        echo "更新了 $updated 条记录<br>";
        
        // 4. 事务示例
        Database::beginTransaction();
        try {
            // 插入日志
            Database::execute(
                "INSERT INTO user_logs (user_id, action) VALUES (?, ?)",
                [$newUserId, 'account_created']
            );
            
            // 更新用户状态
            Database::execute(
                "UPDATE users SET status = ? WHERE id = ?",
                [2, $newUserId]
            );
            
            Database::commit();
            echo "事务成功提交<br>";
        } catch (Exception $e) {
            Database::rollBack();
            echo "事务已回滚: " . $e->getMessage() . "<br>";
        }
        
        // 5. 参数化查询防止SQL注入
        $searchTerm = $_GET['search'] ?? '';
        $safeUsers = Database::query(
            "SELECT * FROM users WHERE name LIKE ?",
            ["%$searchTerm%"]
        );
        
        // 6. 获取单条记录
        $user = Database::query("SELECT * FROM users WHERE id = ?", [1]);
        $singleUser = $user ? $user[0] : null;
        
    } else {
        echo "插入用户失败<br>";
    }
    
    // 7. 关闭连接（通常不需要，PHP会在脚本结束时自动关闭）
    // Database::closeConnection();
	*/
    
//} catch (Exception $e) {
    //echo "发生错误: " . $e->getMessage();
//}
?>