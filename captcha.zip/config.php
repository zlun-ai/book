<?php
//ini_set('display_errors', 0);
//error_reporting(0);
?>
<?php
//ini_set('error_log', 'php_errors.log');
//error_log("自定义位置的错误日志");
define('HOME_URL', 'http://127.0.0.1/01-book-link');
define('RESTAPI', 'http://127.0.0.1/wp-link-search/wp-json/restapi/v1');
define('DB_HOST', "127.0.0.1");
define('DB_USER', "root");
define('DB_PSW', "Pass@1234");
define('DB_NAME', "01_yunpan_link_site");
define('API_KEY', 'xxyyxx');

define('SITE_NAME', 'YunLio');
define('SITE_DESC', '免费下载epub、mobi、azw3、pdf、txt等格式电子书！');

class Config {

    //intialize static variable
    public static $url = "http://127.0.0.1/wp-link-search/wp-json/restapi/v1";
	public static $home = "http://127.0.0.1/01-book-link";
	
	//db
	public static $db_host = "127.0.0.1";
	public static $db_user = "root";
	public static $db_psw = "";
	public static $db_name = "01_yunpan_link_site";
}
?>