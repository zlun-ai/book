<?php
require_once __DIR__ . '/src/Autoloader.php';
\App\Config::load(__DIR__ . '/config/app.php');
\App\Cache::configure(\App\Config::cache());

// Simulate a request with headers
$_SERVER['REQUEST_METHOD'] = 'GET';
$_SERVER['REQUEST_URI'] = '/';
$_SERVER['QUERY_STRING'] = '';
$_SERVER['SCRIPT_NAME'] = '/index.php';
$_SERVER['SCRIPT_FILENAME'] = __DIR__ . '/public/index.php';

// Capture output and headers
ob_start();
include __DIR__ . '/public/index.php';
$output = ob_get_clean();

// Check headers that would be sent
echo "=== Response Headers ===\n";
echo "Content-Type: text/html; charset=utf-8\n";
echo "Content-Length: " . strlen($output) . "\n\n";

echo "=== First 500 chars of output ===\n";
echo substr($output, 0, 500) . "\n\n";

// Check for proper UTF-8
if (mb_check_encoding($output, 'UTF-8')) {
    echo "\n✓ Output is valid UTF-8\n";
} else {
    echo "\n✗ Output is NOT valid UTF-8\n";
}

// Check for any non-printable characters
$nonPrintable = preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $output);
if ($nonPrintable) {
    echo "WARNING: Non-printable control characters found\n";
}

echo "\nDone.\n";