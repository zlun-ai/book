<?php
/** @var array $data */
require_once __DIR__ . '/partials/header.php';
?>

<!-- Hero: 简洁设计 - 核心价值+搜索 -->
<section class="mb-8">
    <div class="relative bg-gradient-to-br from-brand-600 via-brand-700 to-brand-900 rounded-2xl p-5 md:p-8 lg:p-10 text-white overflow-hidden">
        <!-- 背景装饰：淡化书本图案 -->
        <div class="absolute inset-0 opacity-3" aria-hidden="true" style="background-image:url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22none%22 fill-rule=%22evenodd%22%3E%3Cg fill=%22%23ffffff%22 fill-opacity=%220.03%22%3E%3Cpath d=%22M30 0c16.569 0 30 13.431 30 30s-13.431 30-30 30-30-13.431-30-30 13.431-30 30-30zm0 10c11.046 0 20 8.954 20 20s-8.954 20-20 20-20-8.954-20-20-8.954-20-20-20zm0 4c-8.837 0-16 7.163-16 16s7.163 16 16 16 16-7.163 16-16-7.163-16-16-16zM0 30c0-16.569 13.431-30 30-30s30 13.431 30 30-13.431 30-30 30-13.431 30-30 30z%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')"></div>

        <div class="relative max-w-4xl mx-auto">
            <!-- 主标题：价值主张 -->
            <h1 class="text-2xl md:text-3xl lg:text-4xl font-extrabold leading-tight mb-2 max-w-3xl">
                发现好书，<span class="text-brand-200">免费下载</span>
            </h1>
            
            <!-- 副标题：核心优势 - 显示在主标题下一行 -->
            <p class="text-brand-100 text-base md:text-lg leading-relaxed max-w-2xl">
                收录 <strong class="text-white"><?= number_format($data['stats']['total_books'] ?? 0) ?></strong> 本电子书 · 
                EPUB/MOBI/PDF/TXT/AZW3/CHM 全格式
            </p>

            <!-- 搜索框：核心转化入口 - 无按钮，回车搜索 -->
            <form action="<?= \App\Config::url('/search/') ?>" method="get" role="search" class="relative max-w-2xl mx-auto lg:mx-0 mt-6">
                <div class="relative">
                    <input 
                        type="search" 
                        id="hero-search" 
                        name="q" 
                        placeholder="输入书名、作者、ISBN、标签..." 
                        class="w-full px-5 py-4 pl-12 text-base md:text-lg text-gray-900 rounded-xl bg-white focus:outline-none focus:ring-3 focus:ring-white/40 transition-all placeholder-gray-400"
                        autocomplete="off"
                        required
                        aria-label="搜索"
                    >
                    <div class="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400">
                        <i class="fa fa-search text-xl"></i>
                    </div>
                </div>
            </form>

            <!-- 热门标签：搜索框下方 -->
            <div class="mt-6 flex flex-wrap items-center gap-2 text-xs" role="group" aria-label="热门标签">
                <span class="text-brand-200">热门标签：</span>
                <?php if (!empty($data['tags'])): ?>
                <?php foreach (array_slice($data['tags'], 0, 8) as $tag): ?>
                <a href="<?= \App\Config::url('/tag/' . urlencode($tag['name']) . '/') ?>" class="px-2.5 py-1 bg-white/10 hover:bg-white/20 rounded-full transition-all duration-200 text-brand-100 hover:text-white whitespace-nowrap text-xs">
                    #<?= htmlspecialchars($tag['name']) ?>
                </a>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- 主布局：侧边栏 + 主内容区 -->
<div class="flex flex-col lg:flex-row gap-6">
    <!-- 侧边栏：分类导航 -->
    <aside class="lg:w-56 flex-shrink-0 hidden lg:block" aria-label="筛选导航">
        <div class="bg-white rounded-xl border border-gray-200 p-4 sticky top-24 space-y-6">
            <!-- 分类导航 -->
            <nav aria-label="分类导航">
                <h3 class="font-semibold text-gray-900 mb-3 flex items-center gap-2"><i class="fa fa-folder text-brand-600"></i> 全部分类</h3>
                <ul class="space-y-1" role="list">
                    <?php foreach (array_slice($data['categories'] ?? [], 0, 15) as $cat): ?>
                    <?php if ($cat['name'] === '其他类型') continue; ?>
                    <li>
                        <a href="<?= \App\Config::url('/category/' . urlencode($cat['name']) . '/') ?>" class="flex items-center justify-between px-3 py-2.5 text-sm text-gray-600 hover:text-brand-600 hover:bg-brand-50 rounded-lg transition group">
                            <span><?= htmlspecialchars($cat['name']) ?></span>
                            <span class="text-gray-400 group-hover:text-brand-500 text-xs"><?= number_format($cat['count']) ?></span>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </nav>
        </div>
    </aside>
    
    <!-- 主内容区 -->
    <main class="flex-1 min-w-0">
        
        <!-- 移动端快捷入口 -->
        <div class="mb-8 lg:hidden flex flex-wrap items-center gap-3 text-sm" role="group" aria-label="快捷浏览">
            <span class="text-brand-200">快速浏览：</span>
            <a href="<?= \App\Config::url('/search/?sort=hot') ?>" class="px-4 py-2 bg-white/10 hover:bg-white/20 rounded-full transition-all duration-200 text-brand-100 hover:text-white whitespace-nowrap flex items-center gap-1">
                <i class="fa fa-fire text-brand-300"></i> 热门下载榜
            </a>
            <?php if (!empty($data['tags'])): ?>
            <div class="flex items-center gap-2 ml-2">
                <span class="text-brand-300">|</span>
                <?php foreach (array_slice($data['tags'], 0, 5) as $tag): ?>
                <a href="<?= \App\Config::url('/tag/' . urlencode($tag['name']) . '/') ?>" class="px-3 py-1.5 bg-white/10 hover:bg-white/20 rounded-full transition-all duration-200 text-brand-100 hover:text-white whitespace-nowrap text-xs">
                    #<?= htmlspecialchars($tag['name']) ?>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- 热门榜单 Tab 切换 - 在主内容区顶部 -->
        <section class="mb-10" x-data="{ activeTab: 'popular24h' }" x-init="document.querySelector('[x-show]')?.dispatchEvent(new Event('show'))">
            <!-- Tab 导航 -->
            <div class="mb-6" role="tablist" aria-label="热门榜单时间范围">
                <div class="flex flex-wrap gap-2 bg-white rounded-xl border border-gray-200 p-1" role="tablist">
                    <button 
                        role="tab" 
                        aria-selected="true" 
                        aria-controls="panel-popular24h"
                        x-on:click="activeTab = 'popular24h'"
                        :class="activeTab === 'popular24h' ? 'bg-brand-600 text-white shadow-md' : 'text-gray-600 hover:bg-gray-100'"
                        class="px-5 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
                        type="button">
                        <i class="fa fa-bolt mr-1.5"></i> 24小时
                    </button>
                    <button 
                        role="tab" 
                        aria-selected="false" 
                        aria-controls="panel-popularWeek"
                        x-on:click="activeTab = 'popularWeek'"
                        :class="activeTab === 'popularWeek' ? 'bg-brand-600 text-white shadow-md' : 'text-gray-600 hover:bg-gray-100'"
                        class="px-5 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
                        type="button">
                        <i class="fa fa-calendar-week mr-1.5"></i> 本周
                    </button>
                    <button 
                        role="tab" 
                        aria-selected="false" 
                        aria-controls="panel-popularMonth"
                        x-on:click="activeTab = 'popularMonth'"
                        :class="activeTab === 'popularMonth' ? 'bg-brand-600 text-white shadow-md' : 'text-gray-600 hover:bg-gray-100'"
                        class="px-5 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
                        type="button">
                        <i class="fa fa-calendar-alt mr-1.5"></i> 本月
                    </button>
                    <button 
                        role="tab" 
                        aria-selected="false" 
                        aria-controls="panel-hotBooks"
                        x-on:click="activeTab = 'hotBooks'"
                        :class="activeTab === 'hotBooks' ? 'bg-brand-600 text-white shadow-md' : 'text-gray-600 hover:bg-gray-100'"
                        class="px-5 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-brand-500"
                        type="button">
                        <i class="fa fa-trophy mr-1.5"></i> 30天榜
                    </button>
                </div>
            </div>

            <!-- Tab 内容面板 -->
            <!-- 24小时热门 -->
            <div 
                role="tabpanel" 
                id="panel-popular24h" 
                aria-labelledby="popular24h-tab"
                x-show="activeTab === 'popular24h'"
                x-transition:enter="transition ease-out duration-200"
                x-transition:enter-start="opacity-0 transform translate-y-2"
                x-transition:enter-end="opacity-100 transform translate-y-0"
                x-transition:leave="transition ease-in duration-150"
                x-transition:leave-start="opacity-100 transform translate-y-0"
                x-transition:leave-end="opacity-0 transform translate-y-2"
                class="min-h-[300px]"
>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3" role="list">
                    <?php if (!empty($data['popular24h'])): ?>
                    <?php foreach ($data['popular24h'] as $i => $book): ?>
                    <?php 
                        $book['category_url'] = $book['category'] ? \App\Config::url("/category/" . urlencode($book['category']) . "/") : '';
                        $book['relative_time'] = $book['relative_time'] ?? '';
                        $book['iso_date'] = $book['iso_date'] ?? '';
                        require_once __DIR__ . '/partials/book-card.php';
                    ?>
                    <?php endforeach; ?>
                    <?php else: ?>
                    <div class="col-span-full text-center py-8 text-gray-500">暂无24小时热门数据</div>
                    <?php endif; ?>
                </div>
        </div>

        <!-- 本周热门 -->
        <div 
            role="tabpanel" 
            id="panel-popularWeek" 
            aria-labelledby="popularWeek-tab"
            x-show="activeTab === 'popularWeek'"
            x-transition:enter="transition ease-out duration-200"
            x-transition:enter-start="opacity-0 transform translate-y-2"
            x-transition:enter-end="opacity-100 transform translate-y-0"
            x-transition:leave="transition ease-in duration-150"
            x-transition:leave-start="opacity-100 transform translate-y-0"
            x-transition:leave-end="opacity-0 transform translate-y-2"
            class="min-h-[300px]"
        >
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3" role="list">
                <?php if (!empty($data['popularWeek'])): ?>
                <?php foreach ($data['popularWeek'] as $i => $book): ?>
                <?php 
                    $book['category_url'] = $book['category'] ? \App\Config::url("/category/" . urlencode($book['category']) . "/") : '';
                    $book['relative_time'] = $book['relative_time'] ?? '';
                    $book['iso_date'] = $book['iso_date'] ?? '';
                    require_once __DIR__ . '/partials/book-card.php';
                ?>
                <?php endforeach; ?>
                <?php else: ?>
                <div class="col-span-full text-center py-8 text-gray-500">暂无本周热门数据</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- 本月热门 -->
        <div 
            role="tabpanel" 
            id="panel-popularMonth" 
            aria-labelledby="popularMonth-tab"
            x-show="activeTab === 'popularMonth'"
            x-transition:enter="transition ease-out duration-200"
            x-transition:enter-start="opacity-0 transform translate-y-2"
            x-transition:enter-end="opacity-100 transform translate-y-0"
            x-transition:leave="transition ease-in duration-150"
            x-transition:leave-start="opacity-100 transform translate-y-0"
            x-transition:leave-end="opacity-0 transform translate-y-2"
            class="min-h-[300px]"
        >
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3" role="list">
                <?php if (!empty($data['popularMonth'])): ?>
                <?php foreach ($data['popularMonth'] as $i => $book): ?>
                <?php 
                    $book['category_url'] = $book['category'] ? \App\Config::url("/category/" . urlencode($book['category']) . "/") : '';
                    $book['relative_time'] = $book['relative_time'] ?? '';
                    $book['iso_date'] = $book['iso_date'] ?? '';
                    require_once __DIR__ . '/partials/book-card.php';
                ?>
                <?php endforeach; ?>
                <?php else: ?>
                <div class="col-span-full text-center py-8 text-gray-500">暂无本月热门数据</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- 30天热门榜单 -->
        <div 
            role="tabpanel" 
            id="panel-hotBooks" 
            aria-labelledby="hotBooks-tab"
            x-show="activeTab === 'hotBooks'"
            x-transition:enter="transition ease-out duration-200"
            x-transition:enter-start="opacity-0 transform translate-y-2"
            x-transition:enter-end="opacity-100 transform translate-y-0"
            x-transition:leave="transition ease-in duration-150"
            x-transition:leave-start="opacity-100 transform translate-y-0"
            x-transition:leave-end="opacity-0 transform translate-y-2"
            class="min-h-[300px]"
        >
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3" role="list">
                <?php if (!empty($data['hotBooks'])): ?>
                <?php foreach ($data['hotBooks'] as $i => $book): ?>
                <?php 
                    $book['category_url'] = $book['category'] ? \App\Config::url("/category/" . urlencode($book['category']) . "/") : '';
                    $book['relative_time'] = $book['relative_time'] ?? '';
                    $book['iso_date'] = $book['iso_date'] ?? '';
                    require_once __DIR__ . '/partials/book-card.php';
                ?>
                <?php endforeach; ?>
                <?php else: ?>
                <div class="col-span-full text-center py-8 text-gray-500">暂无30天热门数据</div>
                <?php endif; ?>
            </div>
        </div>

    </main>
</div>

<?php require_once __DIR__ . '/partials/footer.php'; ?>