<?php
/** @var array $data */
require_once __DIR__ . '/../partials/header.php';
?>

<article class="max-w-3xl mx-auto prose prose-gray">
    <h1 class="text-2xl font-bold text-gray-900 mb-6">关于我们</h1>
    
    <section class="mb-8">
        <h2 class="text-xl font-semibold text-gray-900 mb-3">站点使命</h2>
        <p><?= htmlspecialchars($data['siteDesc']) ?></p>
        <p class="mt-2">本站致力于为广大读者提供便捷、免费的电子书下载服务，支持 PDF、EPUB、MOBI、TXT、AZW3、CHM 等主流格式，<strong>无需注册、无需积分、无广告干扰、无捆绑软件</strong>，点击即下载。</p>
    </section>
    
    <section class="mb-8">
        <h2 class="text-xl font-semibold text-gray-900 mb-3">核心优势</h2>
        <ul class="space-y-3">
            <li class="flex items-start gap-3 p-4 bg-white rounded-lg border border-gray-100"><i class="fa fa-shield-alt text-brand-600 mt-0.5"></i><div><strong class="text-gray-900">纯净体验</strong><p class="text-gray-500 text-sm mt-1">无弹窗、无广告、无强制下载器、无恶意跳转，专注下载本身</p></div></li>
            <li class="flex items-start gap-3 p-4 bg-white rounded-lg border border-gray-100"><i class="fa fa-bolt text-brand-600 mt-0.5"></i><div><strong class="text-gray-900">极速下载</strong><p class="text-gray-500 text-sm mt-1">JWT 签名直链，5 分钟有效，支持多线程下载工具（IDM/FDM/迅雷）</p></div></li>
            <li class="flex items-start gap-3 p-4 bg-white rounded-lg border border-gray-100"><i class="fa fa-check-circle text-trust-600 mt-0.5"></i><div><strong class="text-gray-900">链接体检</strong><p class="text-gray-500 text-sm mt-1">每日自动检测链接健康度，失效自动隐藏，显示 🟢正常/🟡需码/🟠限速/🔴失效</p></div></li>
            <li class="flex items-start gap-3 p-4 bg-white rounded-lg border border-gray-100"><i class="fa fa-tags text-brand-600 mt-0.5"></i><div><strong class="text-gray-900">多维筛选</strong><p class="text-gray-500 text-sm mt-1">支持按分类、格式、大小、来源、时间多维组合筛选，精准定位所需书籍</p></div></li>
        </ul>
    </section>
    
    <section class="mb-8">
        <h2 class="text-xl font-semibold text-gray-900 mb-3">数据来源</h2>
        <ul class="list-disc list-inside space-y-2 text-gray-600">
            <li>本站数据来源于公开的 WordPress REST API 服务</li>
            <li>所有书籍信息（标题、作者、分类、标签、格式、大小、下载链接、提取码）均由远程 API 提供</li>
            <li>本站不制作、不存储任何电子书文件，仅提供索引和下载跳转服务</li>
            <li>下载链接指向第三方网盘（如城通网盘等），文件版权归原著作权人所有</li>
        </ul>
    </section>
    
    <section class="mb-8">
        <h2 class="text-xl font-semibold text-gray-900 mb-3">免责声明</h2>
        <ul class="list-disc list-inside space-y-2 text-gray-600">
            <li>本站提供的所有资源仅供个人学习、研究使用，请在下载后 24 小时内删除</li>
            <li>请勿将下载的资源用于商业用途，否则后果自负</li>
            <li>本站不保证所有下载链接的有效性、安全性和完整性</li>
            <li>因使用本站资源造成的任何损失，本站概不负责</li>
            <li>如有版权争议，请通过 <a href="<?= \App\Config::url('/contact/') ?>" class="text-brand-600 hover:underline">联系我们</a> 页面提交 DMCA 下架申请</li>
        </ul>
    </section>
    
    <section class="mb-8">
        <h2 class="text-xl font-semibold text-gray-900 mb-3">技术栈</h2>
        <ul class="list-disc list-inside space-y-2 text-gray-600">
            <li>后端：PHP 8.0+ (原生 MVC 架构，无框架依赖，兼容共享虚拟主机)</li>
            <li>数据库：MySQL 5.7+ / MariaDB 10.3+</li>
            <li>缓存：文件缓存 + 内存缓存 (无需 Redis)</li>
            <li>前端：Tailwind CSS (CDN) + Alpine.js (CDN) + Font Awesome</li>
            <li>认证：JWT (HS256，纯 PHP 实现)</li>
            <li>部署：Apache + PHP-FPM</li>
        </ul>
    </section>
    
    <section>
        <h2 class="text-xl font-semibold text-gray-900 mb-3">联系我们</h2>
        <p>如有建议、合作或版权问题，请访问 <a href="<?= \App\Config::url('/contact/') ?>" class="text-brand-600 hover:underline">联系我们</a> 页面。</p>
    </section>
</article>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>