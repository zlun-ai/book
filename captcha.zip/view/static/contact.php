<?php
/** @var array $data */
require_once __DIR__ . '/../partials/header.php';
?>

<article class="max-w-3xl mx-auto">
    <header class="mb-8">
        <h1 class="text-3xl font-bold text-gray-900 mb-2">联系我们</h1>
        <p class="text-gray-600">有问题、建议或合作意向？我们很乐意听到您的声音。</p>
    </header>
    
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        <!-- Contact Form -->
        <section class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-8">
            <h2 class="text-xl font-semibold text-gray-900 mb-6">发送消息</h2>
            
            <form action="<?= \App\Config::url('/contact/') ?>" method="post" id="contact-form" class="space-y-5" novalidate>
                <input type="hidden" name="action" value="send_message">
                <input type="hidden" name="csrf_token" value="<?= bin2hex(random_bytes(16)) ?>">
                
                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700 mb-1">姓名 <span class="text-red-500">*</span></label>
                    <input type="text" id="name" name="name" required autocomplete="name"
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                           placeholder="张三">
                </div>
                
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">邮箱 <span class="text-red-500">*</span></label>
                    <input type="email" id="email" name="email" required autocomplete="email"
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                           placeholder="zhangsan@example.com">
                </div>
                
                <div>
                    <label for="subject" class="block text-sm font-medium text-gray-700 mb-1">主题 <span class="text-red-500">*</span></label>
                    <select id="subject" name="subject" required
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 bg-white">
                        <option value="">请选择主题</option>
                        <option value="general">一般咨询</option>
                        <option value="bug">报告 Bug</option>
                        <option value="feature">功能建议</option>
                        <option value="dmca">版权投诉 (DMCA)</option>
                        <option value="cooperation">商务合作</option>
                        <option value="other">其他</option>
                    </select>
                </div>
                
                <div>
                    <label for="message" class="block text-sm font-medium text-gray-700 mb-1">内容 <span class="text-red-500">*</span></label>
                    <textarea id="message" name="message" required rows="6"
                              class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 resize-none"
                              placeholder="请详细描述您的问题或建议..."></textarea>
                </div>
                
                <!-- Simple honeypot for spam protection -->
                <div class="hidden" aria-hidden="true">
                    <label for="website">网站</label>
                    <input type="text" id="website" name="website" tabindex="-1" autocomplete="off">
                </div>
                
                <button type="submit" 
                        class="w-full py-3 bg-primary-600 text-white font-semibold rounded-lg hover:bg-primary-700 transition-colors focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
                        id="submit-btn">
                    <i class="fa fa-paper-plane mr-2"></i>发送消息
                </button>
                
                <p class="text-xs text-gray-500 text-center">我们会在 1-3 个工作日内回复您的邮件</p>
            </form>
            
            <!-- Form Status Messages -->
            <div id="form-status" class="hidden mt-4 p-4 rounded-lg"></div>
        </section>
        
        <!-- Contact Info -->
        <section class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-8">
            <h2 class="text-xl font-semibold text-gray-900 mb-6">联系方式</h2>
            
            <div class="space-y-6">
                <div class="flex items-start gap-4">
                    <div class="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <i class="fa fa-envelope text-primary-600 text-xl" aria-hidden="true"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold text-gray-900">电子邮件</h3>
                        <ul class="mt-1 space-y-1 text-gray-600">
                            <li><a href="mailto:contact@yunlio.com" class="hover:text-primary-600">contact@yunlio.com</a> <span class="text-xs text-gray-400">(一般咨询)</span></li>
                            <li><a href="mailto:dmca@yunlio.com" class="hover:text-primary-600">dmca@yunlio.com</a> <span class="text-xs text-gray-400">(版权投诉)</span></li>
                            <li><a href="mailto:business@yunlio.com" class="hover:text-primary-600">business@yunlio.com</a> <span class="text-xs text-gray-400">(商务合作)</span></li>
                        </ul>
                    </div>
                </div>
                
                <div class="flex items-start gap-4">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <i class="fa fa-telegram text-green-600 text-xl" aria-hidden="true"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold text-gray-900">Telegram</h3>
                        <p class="mt-1 text-gray-600">关注频道获取最新资源更新</p>
                        <a href="https://t.me/yunlio" target="_blank" rel="noopener noreferrer" class="mt-2 inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                            <i class="fa-brands fa-telegram"></i> @yunlio
                        </a>
                    </div>
                </div>
                
                <div class="flex items-start gap-4">
                    <div class="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <i class="fa fa-github text-gray-600 text-xl" aria-hidden="true"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold text-gray-900">GitHub</h3>
                        <p class="mt-1 text-gray-600">开源项目、问题反馈、贡献代码</p>
                        <a href="https://github.com/yunlio/yunlio" target="_blank" rel="noopener noreferrer" class="mt-2 inline-flex items-center gap-2 px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-900 transition-colors">
                            <i class="fa-brands fa-github"></i> github.com/yunlio
                        </a>
                    </div>
                </div>
            </div>
        </section>
    </div>
    
    <!-- FAQ -->
    <section class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-8">
        <h2 class="text-xl font-semibold text-gray-900 mb-6">常见问题 (FAQ)</h2>
        
        <dl class="space-y-4 divide-y divide-gray-100">
            <div class="py-4">
                <dt class="font-semibold text-gray-900 flex items-center gap-2 cursor-pointer">
                    <i class="fa fa-chevron-down text-gray-400 transition-transform"></i>
                    下载链接打不开/失效了怎么办？
                </dt>
                <dd class="mt-2 text-gray-600 pl-6 hidden">
                    请尝试刷新页面重新获取下载链接（链接有效期 5 分钟）。如果仍然无法下载，可能是网盘限流或文件已被删除，请通过联系表单反馈给我们，我们会尽快核实补档。
                </dd>
            </div>
            
            <div class="py-4">
                <dt class="font-semibold text-gray-900 flex items-center gap-2 cursor-pointer">
                    <i class="fa fa-chevron-down text-gray-400 transition-transform"></i>
                    提取码在哪里？复制不了怎么办？
                </dt>
                <dd class="mt-2 text-gray-600 pl-6 hidden">
                    提取码显示在详情页下载按钮下方，点击「复制」按钮即可一键复制。如果复制失败，请手动选中代码框内的内容复制（提取码通常为 4 位字母数字）。
                </dd>
            </div>
            
            <div class="py-4">
                <dt class="font-semibold text-gray-900 flex items-center gap-2 cursor-pointer">
                    <i class="fa fa-chevron-down text-gray-400 transition-transform"></i>
                    EPUB/MOBI/PDF 哪个格式适合我？
                </dt>
                <dd class="mt-2 text-gray-600 pl-6 hidden">
                    <ul class="list-disc list-inside space-y-1">
                        <li><strong>EPUB</strong>：通用性最强，适合手机、平板、电脑阅读，支持调整字体大小、排版</li>
                        <li><strong>MOBI/AZW3</strong>：适合 Kindle 设备阅读，AZW3 支持更多排版特性</li>
                        <li><strong>PDF</strong>：固定排版，适合打印或需要保持原版面的书籍（如教材、画册）</li>
                        <li><strong>TXT</strong>：纯文本，体积最小，适合极简阅读或文本处理</li>
                    </ul>
                </dd>
            </div>
            
            <div class="py-4">
                <dt class="font-semibold text-gray-900 flex items-center gap-2 cursor-pointer">
                    <i class="fa fa-chevron-down text-gray-400 transition-transform"></i>
                    为什么搜不到某本书？
                </dt>
                <dd class="mt-2 text-gray-600 pl-6 hidden">
                    本站数据来源于第三方 API，收录范围有限。建议尝试：1) 使用更简短的关键词；2) 尝试作者名、ISBN 搜索；3) 浏览分类/标签页面；4) 通过联系表单提荐购，我们会定期更新数据源。
                </dd>
            </div>
            
            <div class="py-4">
                <dt class="font-semibold text-gray-900 flex items-center gap-2 cursor-pointer">
                    <i class="fa fa-chevron-down text-gray-400 transition-transform"></i>
                    网站有广告/病毒/强制下载器吗？
                </dt>
                <dd class="mt-2 text-gray-600 pl-6 hidden">
                    绝对没有。本站无任何广告、无弹窗、无强制下载器、无捆绑软件、无恶意跳转。下载链接直达第三方网盘，中转页仅用于统计和显示提取码。
                </dd>
            </div>
        </dl>
    </section>
</article>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // FAQ Accordion
    document.querySelectorAll('dl dt').forEach(dt => {
        dt.addEventListener('click', () => {
            const dd = dt.nextElementSibling;
            const icon = dt.querySelector('i');
            const isOpen = !dd.classList.contains('hidden');
            
            // Close all others
            document.querySelectorAll('dl dd').forEach(otherDd => {
                if (otherDd !== dd) {
                    otherDd.classList.add('hidden');
                    otherDd.previousElementSibling.querySelector('i').classList.remove('rotate-180');
                }
            });
            
            dd.classList.toggle('hidden');
            icon.classList.toggle('rotate-180');
        });
    });
    
    // Contact Form Submit
    const form = document.getElementById('contact-form');
    const statusDiv = document.getElementById('form-status');
    const submitBtn = document.getElementById('submit-btn');
    
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Honeypot check
            if (form.website.value) {
                return; // Spam bot detected
            }
            
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fa fa-spinner fa-spin mr-2"></i>发送中...';
            statusDiv.classList.add('hidden');
            
            const formData = new FormData(form);
            
            try {
                const response = await fetch(form.action, {
                    method: 'POST',
                    body: formData,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });
                
                const result = await response.json();
                
                if (result.code === 200) {
                    statusDiv.className = 'mt-4 p-4 rounded-lg bg-green-50 border border-green-200 text-green-800';
                    statusDiv.innerHTML = '<i class="fa fa-check-circle mr-2"></i>' + (result.message || '发送成功，我们会尽快回复您！');
                    form.reset();
                } else {
                    statusDiv.className = 'mt-4 p-4 rounded-lg bg-red-50 border border-red-200 text-red-800';
                    statusDiv.innerHTML = '<i class="fa fa-exclamation-circle mr-2"></i>' + (result.message || '发送失败，请稍后重试');
                }
            } catch (err) {
                statusDiv.className = 'mt-4 p-4 rounded-lg bg-red-50 border border-red-200 text-red-800';
                statusDiv.innerHTML = '<i class="fa fa-exclamation-circle mr-2"></i>网络错误，请检查连接后重试';
            }
            
            statusDiv.classList.remove('hidden');
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fa fa-paper-plane mr-2"></i>发送消息';
        });
    }
});
</script>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>