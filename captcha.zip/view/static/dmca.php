<?php
/** @var array $data */
require_once __DIR__ . '/../partials/header.php';
?>

<article class="max-w-3xl mx-auto prose prose-gray">
    <h1 class="text-2xl font-bold text-gray-900 mb-6">版权声明 (DMCA)</h1>
    
    <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-5 mb-8">
        <h2 class="text-lg font-semibold text-yellow-800 mb-2 flex items-center gap-2"><i class="fa fa-exclamation-triangle"></i> 重要提醒</h2>
        <p class="text-yellow-700">本站不存储任何电子书文件，仅提供第三方网盘链接索引。如您发现本站索引的内容侵犯了您的合法权益，请按照以下流程提交下架申请。</p>
    </div>
    
    <section class="mb-8">
        <h2 class="text-xl font-semibold text-gray-900 mb-3">DMCA 下架流程</h2>
        <p class="text-gray-600 mb-4">根据《数字千年版权法案》(DMCA) 及相关法律法规，若您认为本站索引的内容侵犯了您的著作权，请向我们发送书面通知，包含以下信息：</p>
        
        <ol class="list-decimal list-inside space-y-4 text-gray-600">
            <li><strong>权利人身份证明</strong>：身份证/护照复印件（个人）或营业执照/组织机构代码证（企业）</li>
            <li><strong>权属证明</strong>：著作权登记证书、出版合同、授权书等能证明您享有该作品著作权的材料</li>
            <li><strong>侵权内容定位</strong>：本站页面完整 URL（如 <code class="bg-gray-100 px-1 rounded">https://yunlio.com/book/xxx.html</code>）、书名、作者、ISBN 等</li>
            <li><strong>侵权事实描述</strong>：具体说明侵权的内容、方式、范围</li>
            <li><strong>联系方式</strong>：真实姓名、电话、邮箱、通讯地址</li>
            <li><strong>法律声明</strong>：在通知中加入以下声明：
                <blockquote class="border-l-4 border-brand-500 pl-4 my-3 italic text-gray-700 bg-gray-50 p-3 rounded-r">
                    "我确信上述投诉信息真实准确，本人为著作权人或依法授权代理人。如因本通知不实造成损失，由本人承担全部法律责任。"
                </blockquote>
            </li>
            <li><strong>签名/盖章</strong>：个人签名或单位公章</li>
        </ol>
    </section>
    
    <section class="mb-8">
        <h2 class="text-xl font-semibold text-gray-900 mb-3">提交方式</h2>
        <p class="text-gray-600 mb-3">请将上述材料扫描件/照片发送至：</p>
        <div class="bg-gray-100 rounded-xl p-4 font-mono text-lg">
            <div class="mb-2"><strong>邮箱：</strong> <a href="mailto:dmca@yunlio.com" class="text-brand-600">dmca@yunlio.com</a></div>
            <div><strong>主题：</strong> [DMCA下架申请] 书名/链接</div>
        </div>
    </section>
    
    <section class="mb-8">
        <h2 class="text-xl font-semibold text-gray-900 mb-3">处理时效</h2>
        <ul class="list-disc list-inside space-y-2 text-gray-600">
            <li>收到完整材料后 <strong>3 个工作日内</strong> 完成初审</li>
            <li>初审通过后 <strong>24 小时内</strong> 移除相关索引页面和下载链接</li>
            <li>通过邮件告知处理结果</li>
        </ul>
    </section>
    
    <section class="mb-8">
        <h2 class="text-xl font-semibold text-gray-900 mb-3">反通知流程</h2>
        <p class="text-gray-600 mb-3">如果您认为内容被错误移除，可提交反通知：</p>
        <ul class="list-disc list-inside space-y-2 text-gray-600">
            <li>提供身份证明、联系方式</li>
            <li>说明内容被错误移除的理由</li>
            <li>同意接受相关法院管辖</li>
            <li>签署声明："我确信内容因错误或误认被移除，如因反通知不实造成损失，由本人承担全部法律责任。"</li>
        </ul>
        <p class="mt-3 text-gray-600">收到有效反通知后，我们将在 <strong>10 个工作日内</strong> 恢复内容，除非权利人提起诉讼。</p>
    </section>
    
    <section class="mb-8">
        <h2 class="text-xl font-semibold text-gray-900 mb-3">常见问题</h2>
        <dl class="space-y-4 text-gray-600">
            <dt class="font-semibold text-gray-900">Q: 为什么不直接删除文件？</dt>
            <dd class="ml-4">A: 本站不存储任何文件，文件托管在第三方网盘。我们只能移除本站的索引页面和下载跳转链接。如需删除源文件，请直接联系网盘服务商。</dd>
            <dt class="font-semibold text-gray-900">Q: 提交申请后多久生效？</dt>
            <dd class="ml-4">A: 完整材料提交后 3 个工作日内审核，通过后 24 小时内生效。</dd>
            <dt class="font-semibold text-gray-900">Q: 可以代理提交吗？</dt>
            <dd class="ml-4">A: 可以，需提供授权委托书原件扫描件。</dd>
        </dl>
    </section>
</article>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>