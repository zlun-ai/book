<?php
/** @var array $data */
require_once __DIR__ . '/partials/header.php';
?>

<div class="flex flex-col lg:flex-row gap-6">
    <aside class="lg:w-56 flex-shrink-0 hidden lg:block">
        <div class="bg-white rounded-xl border border-gray-200 p-4 sticky top-24">
        </div>
    </aside>
    
    <main class="flex-1 min-w-0">
        <header class="mb-6" itemscope itemtype="https://schema.org/CollectionPage">
            <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-4">
                <div>
                    <div class="flex items-center gap-2 mb-3"><span class="px-3 py-1 bg-brand-100 text-brand-700 rounded-full font-medium text-sm"><i class="fa fa-tag mr-1.5"></i>#<?= htmlspecialchars($data['tag']) ?></span><span class="text-gray-500 text-sm">共 <?= number_format($data['total']) ?> 本</span></div>
                    <h1 class="text-xl md:text-2xl font-bold text-gray-900 mb-2" itemprop="name">标签：<?= htmlspecialchars($data['tag']) ?></h1>
                    <p class="text-gray-600 text-sm mb-4" itemprop="description"><?= htmlspecialchars($data['pageDescription']) ?></p>
                </div>
                <!-- 排序 - 右上角 -->
                <div class="flex items-center gap-2 lg:ml-auto">
                    <label for="d-filter-sort" class="hidden lg:block text-sm text-gray-500 whitespace-nowrap">排序：</label>
                    <select id="d-filter-sort" name="sort" class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 text-sm w-36 lg:w-auto">
                        <option value="new" <?= ($data['sort'] ?? 'new') === 'new' ? 'selected' : '' ?>>最新入库</option>
                        <option value="hot" <?= ($data['sort'] ?? '') === 'hot' ? 'selected' : '' ?>>热门下载</option>
                    </select>
                </div>
            </div>
            
            <?php if (!empty($data['relatedTags'])): ?>
            <div class="flex flex-wrap gap-2 mb-4" aria-label="相关标签"><span class="text-sm text-gray-500 self-center mr-1">相关：</span><?php foreach (array_slice($data['relatedTags'], 0, 10) as $rt): ?><a href="<?= \App\Config::url('/tag/' . urlencode($rt['name']) . '/') ?>" class="px-2.5 py-1 bg-gray-100 text-gray-600 text-sm rounded-lg hover:bg-brand-100 hover:text-brand-700 transition">#<?= htmlspecialchars($rt['name']) ?></a><?php endforeach; ?></div>
            <?php endif; ?>
            
            <!-- 移动端排序下拉 -->
            <div class="lg:hidden bg-white rounded-xl border border-gray-200 p-3 mb-4">
                <label for="m-filter-sort" class="sr-only">排序</label>
                <select id="m-filter-sort" name="sort" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 text-sm">
                    <option value="new" <?= ($data['sort'] ?? 'new') === 'new' ? 'selected' : '' ?>>最新入库</option>
                    <option value="hot" <?= ($data['sort'] ?? '') === 'hot' ? 'selected' : '' ?>>热门下载</option>
                </select>
            </div>
        </header>
        
        <script>document.querySelectorAll('#m-filter-sort, #d-filter-sort').forEach(sel => { sel.addEventListener('change', () => { const params = new URLSearchParams(window.location.search); if (sel.value === 'new') params.delete('sort'); else params.set('sort', 'hot'); params.set('page', '1'); window.location.search = params.toString(); }); });</script>
        
        <?php if (!empty($data['books'])): ?>
        <section aria-labelledby="books-heading">
            <h2 id="books-heading" class="sr-only"><?= htmlspecialchars($data['tag']) ?> 标签下的书籍</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 mb-6" role="list" itemscope itemtype="https://schema.org/ItemList">
                <?php foreach ($data['books'] as $i => $book): ?><div itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><meta itemprop="position" content="<?= ($data['currentPage'] - 1) * $data['perPage'] + $i + 1 ?>"><?php $book['category_url']=$book['category']?\App\Config::url("/category/".urlencode($book['category'])."/"):'';$book['relative_time']=$book['relative_time']??'';$book['iso_date']=$book['iso_date']??'';require_once __DIR__.'/partials/book-card.php';?></div><?php endforeach; ?>
            </div>
            <?php $baseUrl = \App\Config::url("/tag/" . urlencode($data['tag']) . "/"); $queryParams = array_merge(['total' => $data['total']], $_GET); require_once __DIR__ . '/partials/pagination.php'; ?>
        </section>
        <?php else: ?>
        <section class="text-center py-12"><div class="bg-white rounded-xl p-8 shadow-sm border border-gray-200 max-w-md mx-auto"><i class="fa fa-tag text-5xl text-gray-300 mb-3"></i><h2 class="text-xl font-semibold text-gray-900 mb-1">暂无书籍</h2><p class="text-gray-500 mb-5">标签「<?= htmlspecialchars($data['tag']) ?>」暂无电子书</p><a href="<?= \App\Config::url('/') ?>" class="btn-primary inline-flex"><i class="fa fa-arrow-left mr-2"></i>返回首页</a></div></section>
        <?php endif; ?>
    </main>
</div>

<?php require_once __DIR__ . '/partials/footer.php'; ?>