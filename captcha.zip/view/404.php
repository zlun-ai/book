<?php
require_once __DIR__ . '/partials/header.php';
?>

<main class="min-h-[60vh] flex items-center justify-center">
    <div class="text-center px-4">
        <div class="mb-8">
            <svg class="mx-auto w-32 h-32 text-gray-200" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
                <circle cx="12" cy="12" r="10"/>
                <path d="M12 8v4M12 16h.01"/>
            </svg>
        </div>
        
        <h1 class="text-6xl font-bold text-gray-900 mb-4">404</h1>
        <h2 class="text-2xl text-gray-600 mb-6">页面未找到</h2>
        <p class="text-gray-500 mb-8 max-w-md mx-auto">
            抱歉，您访问的页面不存在或已被移除。可能是链接错误，或者页面已迁移到新地址。
        </p>
        
        <div class="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="<?= \App\Config::url('/') ?>" class="px-6 py-3 bg-primary-600 text-white font-semibold rounded-lg hover:bg-primary-700 transition-colors">
                <i class="fa fa-home mr-2"></i>返回首页
            </a>
            <a href="<?= \App\Config::url('/search/') ?>" class="px-6 py-3 bg-gray-100 text-gray-700 font-semibold rounded-lg hover:bg-gray-200 transition-colors">
                <i class="fa fa-search mr-2"></i>搜索电子书
            </a>
        </div>
        
        <div class="mt-12">
            <p class="text-gray-500 mb-4">热门分类：</p>
            <div class="flex flex-wrap justify-center gap-2">
                <?php 
                // 获取热门分类
                $bookService = new \App\Service\BookService();
                $categories = $bookService->getCategories();
                foreach (array_slice($categories, 0, 8) as $cat): 
                ?>
                <a href="<?= \App\Config::url('/category/' . urlencode($cat['name']) . '/') ?>" 
                   class="px-3 py-1 bg-gray-100 text-gray-600 rounded-lg hover:bg-primary-100 hover:text-primary-700 transition-colors text-sm">
                    <?= htmlspecialchars($cat['name']) ?>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/partials/footer.php'; ?>