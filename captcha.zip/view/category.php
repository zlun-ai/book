<?php
/** @var array $data */
require_once __DIR__ . '/partials/header.php';
?>

<div class="flex flex-col lg:flex-row gap-6">
    <!-- 侧边栏筛选 -->
    <aside class="lg:w-56 flex-shrink-0 hidden lg:block">
        <div class="bg-white rounded-xl border border-gray-200 p-4 sticky top-24 space-y-6">
            <nav aria-label="分类导航">
                <h3 class="font-semibold text-gray-900 mb-3 flex items-center gap-2"><i class="fa fa-folder text-brand-600"></i> 全部分类</h3>
                <ul class="space-y-1">
                    <?php foreach (array_slice($data['categories'] ?? [], 0, 15) as $cat): ?>
                    <?php if ($cat['name'] === '其他类型') continue; ?>
                    <li><a href="<?= \App\Config::url('/category/' . urlencode($cat['name']) . '/') ?>" class="flex items-center justify-between px-3 py-2.5 text-sm text-gray-600 hover:text-brand-600 hover:bg-brand-50 rounded-lg transition <?= $cat['name'] === $data['category'] ? 'bg-brand-50 text-brand-600 font-medium' : '' ?>"><span><?= htmlspecialchars($cat['name']) ?></span><span class="text-gray-400 text-xs"><?= number_format($cat['count']) ?></span></a></li>
                    <?php endforeach; ?>
                </ul>
            </nav>
        </div>
    </aside>
    
    <!-- 主内容 -->
    <main class="flex-1 min-w-0">
        <!-- 页面头部 + 移动端排序下拉 -->
        <header class="mb-6" itemscope itemtype="https://schema.org/CollectionPage">
            <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-4">
                <div>
                    <h1 class="text-xl md:text-2xl font-bold text-gray-900 mb-1" itemprop="name"><?= htmlspecialchars($data['category']) ?> <span class="text-gray-500 font-normal text-lg">(<?= number_format($data['total']) ?> 本)</span></h1>
                    <p class="text-gray-600 text-sm" itemprop="description"><?= htmlspecialchars($data['pageDescription']) ?></p>
                </div>
                <!-- 排序 - 右上角 -->
                <div class="flex items-center gap-2 lg:ml-auto">
                    <label for="d-filter-sort" class="hidden lg:block text-sm text-gray-500 whitespace-nowrap">排序：</label>
                    <select id="d-filter-sort" name="sort" class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 text-sm w-36 lg:w-auto">
                        <option value="new" <?= ($data['filters']['sort'] ?? 'new') === 'new' ? 'selected' : '' ?>>最新入库</option>
                        <option value="hot" <?= ($data['filters']['sort'] ?? '') === 'hot' ? 'selected' : '' ?>>热门下载</option>
                        <option value="size_desc" <?= ($data['filters']['sort'] ?? '') === 'size_desc' ? 'selected' : '' ?>>大小降序</option>
                        <option value="size_asc" <?= ($data['filters']['sort'] ?? '') === 'size_asc' ? 'selected' : '' ?>>大小升序</option>
                    </select>
                </div>
            </div>
            
            <!-- 移动端排序下拉 -->
            <div class="lg:hidden bg-white rounded-xl border border-gray-200 p-3 mb-4">
                <label for="m-filter-sort" class="sr-only">排序</label>
                <select id="m-filter-sort" name="sort" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 text-sm">
                    <option value="new" <?= ($data['filters']['sort'] ?? 'new') === 'new' ? 'selected' : '' ?>>最新入库</option>
                    <option value="hot" <?= ($data['filters']['sort'] ?? '') === 'hot' ? 'selected' : '' ?>>热门下载</option>
                    <option value="size_desc" <?= ($data['filters']['sort'] ?? '') === 'size_desc' ? 'selected' : '' ?>>大小降序</option>
                    <option value="size_asc" <?= ($data['filters']['sort'] ?? '') === 'size_asc' ? 'selected' : '' ?>>大小升序</option>
                </select>
            </div>
        </header>
        
        <script>
            document.querySelectorAll('#m-filter-sort, #d-filter-sort, [data-sort]').forEach(el => {
                if (el.tagName === 'SELECT') {
                    el.addEventListener('change', () => {
                        const params = new URLSearchParams(window.location.search);
                        if (el.value === 'new') params.delete('sort'); else params.set('sort', el.value);
                        params.set('page', '1');
                        window.location.search = params.toString();
                    });
                } else if (el.dataset.sort) {
                    el.addEventListener('click', (e) => {
                        e.preventDefault();
                        const params = new URLSearchParams(window.location.search);
                        if (el.dataset.sort === 'new') params.delete('sort'); else params.set('sort', el.dataset.sort);
                        params.set('page', '1');
                        window.location.search = params.toString();
                    });
                }
            });
        </script>
        
        <!-- 书籍列表 -->
        <?php if (!empty($data['books'])): ?>
        <section aria-labelledby="books-heading">
            <h2 id="books-heading" class="sr-only"><?= htmlspecialchars($data['category']) ?> 书籍列表</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 mb-6" role="list" itemscope itemtype="https://schema.org/ItemList">
                <?php foreach ($data['books'] as $i => $book): ?>
                <div itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><meta itemprop="position" content="<?= ($data['currentPage'] - 1) * $data['perPage'] + $i + 1 ?>"><?php 
                    $book['category_url'] = $book['category'] ? \App\Config::url("/category/" . urlencode($book['category']) . "/") : '';
                    $book['relative_time'] = $book['relative_time'] ?? '';
                    $book['iso_date'] = $book['iso_date'] ?? '';
                    include __DIR__ . '/partials/book-card.php'; 
                ?></div>
                <?php endforeach; ?>
            </div>
            
            <?php $baseUrl = \App\Config::url("/category/" . urlencode($data['category']) . "/"); $queryParams = array_merge(['total' => $data['total']], $_GET); require_once __DIR__ . '/partials/pagination.php'; ?>
        </section>
        <?php else: ?>
        <section class="text-center py-12"><div class="bg-white rounded-xl p-8 shadow-sm border border-gray-200 max-w-md mx-auto"><i class="fa fa-book-open text-5xl text-gray-300 mb-3"></i><h2 class="text-xl font-semibold text-gray-900 mb-1">暂无书籍</h2><p class="text-gray-500 mb-5">该分类暂无电子书</p><a href="<?= \App\Config::url('/') ?>" class="btn-primary inline-flex"><i class="fa fa-arrow-left mr-2"></i>返回首页</a></div></section>
        <?php endif; ?>
    </main>
</div>

<?php require_once __DIR__ . '/partials/footer.php'; ?>