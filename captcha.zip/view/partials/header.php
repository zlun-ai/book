<?php
/** @var array $data */
$siteName = $data['siteName'] ?? 'YunLio';
$pageTitle = $data['pageTitle'] ?? $siteName;
$pageDescription = $data['pageDescription'] ?? '';
$canonicalUrl = $data['canonicalUrl'] ?? '';
$ogImage = $data['ogImage'] ?? '';
$structuredData = $data['structuredData'] ?? '';
$stats = $data['stats'] ?? [];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="format-detection" content="telephone=no, email=no, address=no">
    
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <meta name="description" content="<?= htmlspecialchars($pageDescription) ?>">
    <meta name="keywords" content="电子书下载,epub下载,mobi下载,pdf下载,txt下载,azw3下载,免费电子书,Kindle电子书,编程书籍,小说下载">
    <meta name="theme-color" content="#1e3a8a">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-transform">
    
    <?php if ($canonicalUrl): ?>
    <link rel="canonical" href="<?= htmlspecialchars($canonicalUrl) ?>">
    <?php endif; ?>
    
    <!-- Open Graph -->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="<?= htmlspecialchars($siteName) ?>">
    <meta property="og:title" content="<?= htmlspecialchars($pageTitle) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($pageDescription) ?>">
    <?php if ($canonicalUrl): ?>
    <meta property="og:url" content="<?= htmlspecialchars($canonicalUrl) ?>">
    <?php endif; ?>
    <?php if ($ogImage): ?>
    <meta property="og:image" content="<?= htmlspecialchars($ogImage) ?>">
    <?php endif; ?>
    
    <!-- 微信分享优化 -->
    <meta name="weixin:title" content="<?= htmlspecialchars($pageTitle) ?>">
    <meta name="weixin:description" content="<?= htmlspecialchars($pageDescription) ?>">
    <?php if ($ogImage): ?>
    <meta name="weixin:image" content="<?= htmlspecialchars($ogImage) ?>">
    <?php endif; ?>
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="<?= \App\Config::asset('images/favicon.svg') ?>">
    <link rel="apple-touch-icon" href="<?= \App\Config::asset('images/logo.png') ?>">
    <link rel="manifest" href="<?= \App\Config::url('/manifest.json') ?>">
    
    <!-- DNS Prefetch & Preconnect -->
    <link rel="dns-prefetch" href="//cdn.tailwindcss.com">
    <link rel="dns-prefetch" href="//cdn.jsdelivr.net">
    <link rel="preconnect" href="https://cdn.tailwindcss.com" crossorigin>
    <link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            50: '#eff6ff',
                            100: '#dbeafe',
                            200: '#bfdbfe',
                            300: '#93c5fd',
                            400: '#60a5fa',
                            500: '#3b82f6',
                            600: '#2563eb',
                            700: '#1d4ed8',
                            800: '#1e40af',
                            900: '#1e3a8a',
                        },
                        trust: {
                            50: '#f0fdf4',
                            100: '#dcfce7',
                            500: '#22c55e',
                            600: '#16a34a',
                            700: '#15803d',
                        }
                    },
                    fontFamily: {
                        sans: ['MiSans', 'HarmonyOS_Sans', 'PingFang SC', 'Microsoft YaHei', 'system-ui', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.1/css/all.min.css">
    
    <!-- 中文字体预加载 -->
    <link rel="preload" as="style" href="https://cdn.jsdelivr.net/npm/@fontsource-variable/mi-sans@latest/latin.css" onload="this.rel='stylesheet'">
    
    <!-- Structured Data -->
    <?php if ($structuredData): ?>
    <script type="application/ld+json"><?= $structuredData ?></script>
    <?php endif; ?>
    
    <!-- Critical CSS Inline - 首屏关键样式 -->
    <style>
        *,*::before,*::after{box-sizing:border-box}
        html{font-size:16px;-webkit-text-size-adjust:100%}
        body{margin:0;font-family:"MiSans","HarmonyOS_Sans","PingFang SC","Microsoft YaHei",system-ui,sans-serif;line-height:1.6;color:#1f2937;background:#fafafa;min-height:100vh}
        a{color:inherit;text-decoration:none}
        img{max-width:100%;height:auto;display:block}
        button{font-family:inherit;cursor:pointer;border:none;background:none}
        input,select,textarea{font-family:inherit;font-size:inherit}
        .sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
        
        /* 核心组件样式 */
        .btn-primary{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:12px 24px;background:linear-gradient(135deg,#2563eb 0%,#1d4ed8 100%);color:#fff;font-weight:600;font-size:14px;border-radius:8px;transition:all .2s;box-shadow:0 4px 14px rgba(37,99,235,.25)}
        .btn-primary:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(37,99,235,.35)}
        .btn-primary:active{transform:translateY(0)}
        .btn-primary:disabled{opacity:.6;cursor:not-allowed;transform:none}
        .btn-secondary{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:10px 20px;background:#fff;color:#2563eb;font-weight:500;font-size:14px;border:1px solid #2563eb;border-radius:8px;transition:all .2s}
        .btn-secondary:hover{background:#eff6ff}
        
        .tag{display:inline-flex;align-items:center;padding:2px 8px;font-size:12px;border-radius:9999px;font-weight:500}
        .tag-format{background:#eff6ff;color:#1d4ed8}
        .tag-format.epub{background:#ede9fe;color:#6d28d9}
        .tag-format.mobi{background:#fef3c7;color:#b45309}
        .tag-format.pdf{background:#fee2e2;color:#dc2626}
        .tag-format.txt{background:#f1f5f9;color:#334155}
        .tag-format.azw3{background:#ecfdf5;color:#059669}
        .tag-source{background:#f1f5f9;color:#475569}
        .tag-category{background:#dcfce7;color:#166534}
        
        .health-badge{display:inline-flex;align-items:center;gap:4px;padding:3px 10px;font-size:11px;font-weight:600;border-radius:9999px}
        .health-healthy{background:#dcfce7;color:#166534}
        .health-warning{background:#fef3c7;color:#b45309}
        .health-danger{background:#fee2e2;color:#b91c1c}
        
        .book-card{background:#fff;border:1px solid #e5e7eb;border-radius:12px;overflow:hidden;transition:all .25s ease}
        .book-card:hover{transform:translateY(-4px);box-shadow:0 12px 32px rgba(0,0,0,.08);border-color:#fdba74}
        
        .trust-badge{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;background:#f0fdf4;color:#166534;font-size:11px;font-weight:600;border-radius:6px}
        
        /* 滚动条 */
        ::-webkit-scrollbar{width:6px;height:6px}
        ::-webkit-scrollbar-track{background:#f1f5f9}
        ::-webkit-scrollbar-thumb{background:#d1d5db;border-radius:3px}
        ::-webkit-scrollbar-thumb:hover{background:#9ca3af}
        
        /* 骨架屏 */
        @keyframes shimmer{0%{background-position:-200% 0}100%{background-position:200% 0}}
        .skeleton{background:linear-gradient(90deg,#f0f0f0 25%,#e5e5e5 50%,#f0f0f0 75%);background-size:200% 100%;animation:shimmer 1.5s infinite;border-radius:4px}
        
        /* 焦点态 */
        :focus-visible{outline:2px solid #2563eb;outline-offset:2px}
        
        /* 平滑滚动 */
        html{scroll-behavior:smooth}
    </style>
</head>
<body class="flex flex-col min-h-screen">
    <!-- Skip Link -->
    <a href="#main-content" class="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 z-50 px-4 py-2 bg-brand-600 text-white rounded-lg font-medium">跳转到主内容</a>
    
    <!-- Header -->
    <header class="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex items-center justify-between h-14 md:h-16">
                <!-- Logo -->
                <a href="<?= \App\Config::url('/') ?>" class="flex items-center gap-2.5 flex-shrink-0" aria-label="<?= htmlspecialchars($siteName) ?> - 首页">
                    <div class="w-9 h-9 bg-gradient-to-br from-brand-600 to-brand-800 rounded-lg flex items-center justify-center">
                        <svg class="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 17H20"/><path d="M12.5 17V5"/><path d="M12.5 5H19"/></svg>
                    </div>
                    <span class="text-lg font-bold text-gray-900 hidden sm:block"><?= htmlspecialchars($siteName) ?></span>
                </a>
                
                <!-- 搜索框 - 核心入口 -->
                <form action="<?= \App\Config::url('/search/') ?>" method="get" role="search" class="flex-1 max-w-2xl mx-6 md:mx-8 relative" x-data="{ suggestions: [], show: false, query: '', highlighted: -1 }">
                    <label for="header-search" class="sr-only">搜索电子书</label>
                    <input 
                        type="search" 
                        id="header-search"
                        name="q" 
                        placeholder="搜书名、作者、ISBN、标签..." 
                        value="<?= htmlspecialchars($_GET['q'] ?? '') ?>"
                        class="w-full pl-11 pr-4 py-2.5 bg-gray-100 border-0 rounded-xl text-sm placeholder-gray-400 focus:bg-white focus:ring-2 focus:ring-brand-500 focus:outline-none transition-all"
                        autocomplete="off"
                        aria-label="搜索电子书"
                        x-model="query"
                        @focus="show = suggestions.length > 0"
                        @keydown.down.prevent="highlighted = Math.min((highlighted || -1) + 1, suggestions.length - 1)"
                        @keydown.up.prevent="highlighted = Math.max((highlighted || 0) - 1, 0)"
                        @keydown.enter.prevent="highlighted !== undefined && suggestions[highlighted] && (query = suggestions[highlighted], $refs.form.submit())"
                        @click.outside="show = false"
                        x-ref="form"
                    >
                    <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400"><i class="fa fa-search"></i></div>
                    <button type="submit" class="sr-only">搜索</button>
                    
                    <!-- 智能建议下拉 -->
                    <div 
                        x-show="show && suggestions.length > 0" 
                        x-transition:enter="transition ease-out duration-100"
                        x-transition:enter-start="transform opacity-0 scale-95 -translate-y-1"
                        x-transition:enter-end="transform opacity-100 scale-100 -translate-y-0"
                        x-transition:leave="transition ease-in duration-75"
                        class="absolute z-50 mt-2 w-full bg-white border border-gray-200 rounded-xl shadow-lg overflow-hidden"
                        role="listbox"
                    >
                        <template x-for="(suggestion, index) in suggestions" :key="suggestion">
                            <button type="button" @click="query = suggestion; $refs.form.submit()" :class="{ 'bg-brand-50': index === highlighted }" class="w-full px-4 py-2.5 text-left text-sm text-gray-700 hover:bg-brand-50 focus:bg-brand-50 focus:outline-none flex items-center gap-2" role="option">
                                <i class="fa fa-search text-gray-400"></i>
                                <span x-text="suggestion"></span>
                            </button>
                        </template>
                    </div>
                </form>
                
                <!-- 右侧操作 -->
                <div class="flex items-center gap-2">
                    <button class="md:hidden p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg" aria-label="菜单" @click="mobileMenuOpen = !mobileMenuOpen"><i class="fa fa-bars text-xl"></i></button>
                </div>
            </div>
        </div>
        
        <!-- 移动端搜索 -->
        <div class="md:hidden px-4 pb-3 border-b border-gray-100">
            <form action="<?= \App\Config::url('/search/') ?>" method="get" role="search" class="relative">
                <label for="mobile-search" class="sr-only">搜索电子书</label>
                <input type="search" id="mobile-search" name="q" placeholder="搜书名、作者、ISBN..." value="<?= htmlspecialchars($_GET['q'] ?? '') ?>" class="w-full pl-11 pr-4 py-2.5 bg-gray-100 border-0 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-brand-500 focus:outline-none placeholder-gray-400" autocomplete="off">
                <div class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400"><i class="fa fa-search"></i></div>
            </form>
        </div>
        
        <!-- 移动端菜单 -->
        <div x-show="mobileMenuOpen" x-transition class="md:hidden px-4 py-3 border-b border-gray-100 bg-white">
            <nav class="flex flex-col gap-1">
                <a href="<?= \App\Config::url('/about/') ?>" class="px-3 py-2.5 text-gray-600 hover:text-brand-600 hover:bg-gray-50 rounded-lg transition">关于我们</a>
                <a href="<?= \App\Config::url('/dmca/') ?>" class="px-3 py-2.5 text-gray-600 hover:text-brand-600 hover:bg-gray-50 rounded-lg transition">版权声明</a>
                <a href="<?= \App\Config::url('/contact/') ?>" class="px-3 py-2.5 text-gray-600 hover:text-brand-600 hover:bg-gray-50 rounded-lg transition">联系我们</a>
                <hr class="my-2">
                <?php if (!empty($data['categories'])): ?>
                <div class="px-3 py-2 font-medium text-gray-500 uppercase tracking-wider text-xs">分类导航</div>
                <?php foreach (array_slice($data['categories'], 0, 10) as $cat): ?>
                    <a href="<?= \App\Config::url('/category/' . urlencode($cat['name']) . '/') ?>" class="px-3 py-2.5 text-sm text-gray-600 hover:text-brand-600 hover:bg-gray-50 rounded-lg transition flex items-center justify-between"><?= htmlspecialchars($cat['name']) ?><span class="text-brand-400 text-xs"><?= $cat['count'] ?></span></a>
                <?php endforeach; ?>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    
    <!-- 主内容 -->
    <main id="main-content" class="flex-1 max-w-7xl mx-auto w-full px-4 py-6">
        <?php if (!empty($data['breadcrumbs'])): ?>
        <nav aria-label="面包屑" class="mb-4" itemscope itemtype="https://schema.org/BreadcrumbList">
            <ol class="flex items-center gap-1.5 text-sm text-gray-500 flex-wrap" role="list">
                <?php foreach ($data['breadcrumbs'] as $i => $crumb): ?>
                <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                    <?php if ($crumb['url']): ?><a itemprop="item" href="<?= htmlspecialchars($crumb['url']) ?>" class="hover:text-brand-600 transition" itemprop="name"><?= htmlspecialchars($crumb['name']) ?></a><?php else: ?><span itemprop="name" class="text-gray-900 font-medium"><?= htmlspecialchars($crumb['name']) ?></span><?php endif; ?>
                    <meta itemprop="position" content="<?= $i + 1 ?>"><?php if ($i < count($data['breadcrumbs']) - 1): ?><i class="fa fa-chevron-right text-xs text-gray-400"></i><?php endif; ?>
                </li><?php endforeach; ?>
            </ol>
        </nav><?php endif; ?>