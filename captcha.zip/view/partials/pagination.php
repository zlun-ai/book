<?php
$currentPage = $currentPage ?? 1;
$lastPage = $lastPage ?? 1;
$baseUrl = $baseUrl ?? '';
$queryParams = $queryParams ?? [];

if ($lastPage <= 1) return;

function buildUrl(int $page): string {
    global $baseUrl, $queryParams;
    $params = array_merge($queryParams, ['page' => $page]);
    return $baseUrl . '?' . http_build_query($params);
}
?>
<nav class="pagination flex flex-wrap items-center justify-center gap-1.5 mt-8" aria-label="分页导航" role="navigation">
    <!-- First -->
    <?php if ($currentPage > 1): ?>
    <a href="<?= buildUrl(1) ?>" class="px-3 py-2 text-sm bg-white border border-gray-300 rounded-lg hover:bg-brand-50 hover:border-brand-500 hover:text-brand-700 transition" aria-label="第一页" title="第一页"><i class="fa fa-angle-double-left"></i></a>
    <?php else: ?>
    <span class="px-3 py-2 text-sm bg-gray-100 border border-gray-200 rounded-lg text-gray-400 cursor-not-allowed" aria-disabled="true"><i class="fa fa-angle-double-left"></i></span>
    <?php endif; ?>
    
    <!-- Prev -->
    <?php if ($currentPage > 1): ?>
    <a href="<?= buildUrl($currentPage - 1) ?>" class="px-3 py-2 text-sm bg-white border border-gray-300 rounded-lg hover:bg-brand-50 hover:border-brand-500 hover:text-brand-700 transition" aria-label="上一页" rel="prev" title="上一页"><i class="fa fa-angle-left"></i></a>
    <?php else: ?>
    <span class="px-3 py-2 text-sm bg-gray-100 border border-gray-200 rounded-lg text-gray-400 cursor-not-allowed" aria-disabled="true"><i class="fa fa-angle-left"></i></span>
    <?php endif; ?>
    
    <!-- Numbers -->
    <?php
    $start = max(1, $currentPage - 2);
    $end = min($lastPage, $currentPage + 2);
    if ($currentPage <= 3) $end = min(5, $lastPage);
    if ($currentPage >= $lastPage - 2) $start = max(1, $lastPage - 4);
    if ($start > 1): ?>
    <a href="<?= buildUrl(1) ?>" class="px-4 py-2 text-sm bg-white border border-gray-300 rounded-lg hover:bg-brand-50 hover:border-brand-500 hover:text-brand-700 transition" aria-label="第 1 页">1</a>
    <?php if ($start > 2): ?>
    <span class="px-3 py-2 text-sm text-gray-400">...</span>
    <?php endif; ?>
    <?php endif; ?>
    
    <?php for ($i = $start; $i <= $end; $i++): ?>
    <?php if ($i === $currentPage): ?>
    <span class="px-4 py-2 text-sm bg-brand-600 text-white rounded-lg font-medium" aria-current="page" aria-label="当前第 <?= $i ?> 页"><?= $i ?></span>
    <?php else: ?>
    <a href="<?= buildUrl($i) ?>" class="px-4 py-2 text-sm bg-white border border-gray-300 rounded-lg hover:bg-brand-50 hover:border-brand-500 hover:text-brand-700 transition" aria-label="第 <?= $i ?> 页"><?= $i ?></a>
    <?php endif; ?>
    <?php endfor; ?>
    
    <?php if ($end < $lastPage): ?>
    <?php if ($end < $lastPage - 1): ?>
    <span class="px-3 py-2 text-sm text-gray-400">...</span>
    <?php endif; ?>
    <a href="<?= buildUrl($lastPage) ?>" class="px-4 py-2 text-sm bg-white border border-gray-300 rounded-lg hover:bg-brand-50 hover:border-brand-500 hover:text-brand-700 transition" aria-label="第 <?= $lastPage ?> 页"><?= $lastPage ?></a>
    <?php endif; ?>
    
    <!-- Next -->
    <?php if ($currentPage < $lastPage): ?>
    <a href="<?= buildUrl($currentPage + 1) ?>" class="px-3 py-2 text-sm bg-white border border-gray-300 rounded-lg hover:bg-brand-50 hover:border-brand-500 hover:text-brand-700 transition" aria-label="下一页" rel="next" title="下一页"><i class="fa fa-angle-right"></i></a>
    <?php else: ?>
    <span class="px-3 py-2 text-sm bg-gray-100 border border-gray-200 rounded-lg text-gray-400 cursor-not-allowed" aria-disabled="true"><i class="fa fa-angle-right"></i></span>
    <?php endif; ?>
    
    <!-- Last -->
    <?php if ($currentPage < $lastPage): ?>
    <a href="<?= buildUrl($lastPage) ?>" class="px-3 py-2 text-sm bg-white border border-gray-300 rounded-lg hover:bg-brand-50 hover:border-brand-500 hover:text-brand-700 transition" aria-label="最后一页" title="最后一页"><i class="fa fa-angle-double-right"></i></a>
    <?php else: ?>
    <span class="px-3 py-2 text-sm bg-gray-100 border border-gray-200 rounded-lg text-gray-400 cursor-not-allowed" aria-disabled="true"><i class="fa fa-angle-double-right"></i></span>
    <?php endif; ?>
    
    <span class="px-3 py-2 text-sm text-gray-500 hidden sm:block" aria-live="polite">第 <?= $currentPage ?> / <?= $lastPage ?> 页，共 <?= $queryParams['total'] ?? 0 ?> 条</span>
</nav>

<?php
// Build JSON-LD for pagination
$ldItems = [];
for ($i = 1; $i <= min(5, $lastPage); $i++) {
    $ldItems[] = '{"@type":"ListItem","position":' . $i . ',"url":"' . buildUrl($i) . '"}';
}
$ldJson = '{"@context":"https://schema.org","@type":"ItemList","itemListElement":[' . implode(',', $ldItems) . ']}';
?>
<script type="application/ld+json"><?= $ldJson ?></script>
<?php