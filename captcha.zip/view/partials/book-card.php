<?php
/** @var array $book */
/** @var bool $showCategory */
/** @var bool $showTags */
/** @var bool $showSource */
/** @var bool $compact */
$showCategory = $showCategory ?? true;
$showTags = $showTags ?? true;
$showSource = $showSource ?? true;
$compact = $compact ?? false;

$format = strtolower($book['format'] ?? '');
$formatClass = 'tag-format ' . $format;

// 健康状态：仅非 unknown 时显示
$healthStatus = $book['health_status'] ?? 'unknown';
$healthText = match($healthStatus) {
    'healthy' => '🟢 正常',
    'need_password' => '🟡 需提取码',
    'rate_limited' => '🟠 限速',
    'dead' => '🔴 失效',
    default => '',
};

// 格式专属渐变配色
$formatGradients = [
    'epub'  => 'from-blue-500 via-blue-600 to-blue-700',
    'pdf'   => 'from-red-500 via-red-600 to-red-700',
    'mobi'  => 'from-amber-500 via-amber-600 to-amber-700',
    'azw3'  => 'from-orange-500 via-orange-600 to-orange-700',
    'txt'   => 'from-gray-500 via-gray-600 to-gray-700',
    'azw'   => 'from-orange-500 via-orange-600 to-orange-700',
    'chm'   => 'from-purple-500 via-purple-600 to-purple-700',
    'doc'   => 'from-indigo-500 via-indigo-600 to-indigo-700',
    'djvu'  => 'from-teal-500 via-teal-600 to-teal-700',
    'fb2'   => 'from-pink-500 via-pink-600 to-pink-700',
    'rtf'   => 'from-green-500 via-green-600 to-green-700',
];
$gradient = $formatGradients[$format] ?? 'from-gray-500 via-gray-600 to-gray-700';

$downloadUrl = \App\Config::url("/api/download/{$book['slug']}");
$detailUrl = \App\Config::url("/book/{$book['slug']}.html");
$catUrl = $book['category'] ? \App\Config::url("/category/" . urlencode($book['category']) . "/") : '#';

// 处理标签：支持字符串(逗号分隔)或数组
$rawTags = $book['tags'] ?? [];
if (is_string($rawTags)) {
    $tags = array_filter(array_map('trim', preg_split('/[,，]/', $rawTags)));
} else {
    $tags = is_array($rawTags) ? $rawTags : [];
    // 如果数组只有一个元素且包含逗号，进一步分割
    if (count($tags) === 1 && is_string($tags[0]) && preg_match('/[,，]/', $tags[0])) {
        $tags = array_filter(array_map('trim', preg_split('/[,，]/', $tags[0])));
    }
}
$tagUrls = array_map(fn($t) => \App\Config::url("/tag/" . urlencode($t) . "/"), $tags);
?>
<article class="book-card bg-white border border-gray-200 rounded-xl overflow-hidden flex flex-col h-full" itemscope itemtype="https://schema.org/Book" itemid="<?= htmlspecialchars($detailUrl) ?>">
    <a href="<?= htmlspecialchars($detailUrl) ?>" class="book-link block" itemprop="url" aria-label="查看《<?= htmlspecialchars($book['title']) ?>》详情">
        <!-- 书脊/封面区：格式渐变背景 + 关键信息 -->
        <div class="relative aspect-[3/4] bg-gradient-to-br <?= $gradient ?> overflow-hidden flex flex-col">
            <!-- 顶部：格式 + 健康状态 -->
            <div class="absolute top-2 right-2 flex flex-col gap-1.5">
                <span class="tag tag-format <?= $formatClass ?>" itemprop="bookFormat"><?= strtoupper($book['format'] ?? '') ?></span>
                <?php if (!empty($healthText)): ?>
                <span class="health-badge health-<?= $healthStatus ?>" title="<?= $healthText ?>">
                    <?= $healthText ?>
                </span>
                <?php endif; ?>
            </div>
            
            <!-- 底部信息栏：格式、大小、分类、来源、健康状态整合 -->
            <div class="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <!-- 左侧：格式 + 大小 -->
                <div class="flex items-center gap-2 flex-wrap">
                    <span class="tag tag-format <?= $formatClass ?> text-xs font-semibold"><?= strtoupper($book['format'] ?? '') ?></span>
                    <span class="px-2 py-1 bg-white/90 backdrop-blur-sm text-xs font-medium text-gray-800 rounded"><i class="fa fa-file mr-1"></i><?= htmlspecialchars($book['size']) ?></span>
                </div>
                
                <!-- 右侧：分类 + 来源 + 健康状态 -->
                <div class="flex items-center gap-2 flex-wrap">
                    <?php if ($showCategory && !empty($book['category'])): ?>
                    <a href="<?= htmlspecialchars($catUrl) ?>" class="tag tag-category text-xs whitespace-nowrap" itemprop="genre"><?= htmlspecialchars($book['category']) ?></a>
                    <?php endif; ?>
                    <?php if ($showSource && !empty($book['source'])): ?>
                    <span class="tag tag-source text-xs" itemprop="publisher" itemscope itemtype="https://schema.org/Organization"><span itemprop="name"><?= htmlspecialchars($book['source']) ?></span></span>
                    <?php endif; ?>
                    <?php if (!empty($healthText)): ?>
                    <span class="health-badge health-<?= $healthStatus ?>" title="<?= $healthText ?>">
                        <?= $healthText ?>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- 内容区 -->
        <div class="p-3 sm:p-4 flex flex-col flex-1 min-h-0">
            <h3 class="font-semibold text-gray-900 line-clamp-2 mb-2" itemprop="name"><a href="<?= htmlspecialchars($detailUrl) ?>" class="hover:text-brand-600 transition-colors">《<?= htmlspecialchars($book['title']) ?>》</a></h3>
            
            <?php if ($showTags && !empty($tags)): ?>
            <div class="flex flex-wrap gap-1 mb-2" itemprop="keywords">
                <?php foreach (array_slice($tags, 0, 3) as $i => $tag): ?>
                <a href="<?= htmlspecialchars($tagUrls[$i] ?? '#') ?>" class="tag tag-format bg-white/90 text-gray-700 hover:bg-white hover:text-brand-700 text-xs whitespace-nowrap" title="标签：<?= htmlspecialchars($tag) ?>"><?= htmlspecialchars($tag) ?></a>
                <?php endforeach; ?>
                <?php if (count($tags) > 3): ?><span class="tag bg-white/90 text-gray-400 text-xs">+<?= count($tags) - 3 ?></span><?php endif; ?>
            </div>
            <?php endif; ?>
            
            <div class="flex items-center gap-3 mt-auto pt-2 border-t border-white/20 text-xs text-white/80">
                <span itemprop="fileSize" content="<?= htmlspecialchars($book['size']) ?>" class="flex items-center gap-1"><i class="fa fa-file"></i><?= htmlspecialchars($book['size']) ?></span>
                <?php if (!empty($book['date'])): ?><time itemprop="datePublished" datetime="<?= htmlspecialchars($book['iso_date'] ?? '') ?>" class="flex items-center gap-1"><i class="fa fa-clock"></i><?= htmlspecialchars($book['relative_time'] ?? $book['date']) ?></time><?php endif; ?>
            </div>
        </div>
    </a>
</article>