</main>

<!-- Footer -->
<footer class="bg-gray-950 text-gray-400 border-t border-gray-800 mt-auto">
    <div class="max-w-7xl mx-auto px-4 py-10 lg:py-14">
        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 lg:gap-12">
            <!-- Brand -->
            <div class="col-span-2 lg:col-span-2">
                <a href="<?= \App\Config::url('/') ?>" class="flex items-center gap-2.5 mb-5" aria-label="<?= htmlspecialchars($siteName ?? 'YunLio') ?>">
                    <div class="w-10 h-10 bg-gradient-to-br from-brand-500 to-brand-700 rounded-lg flex items-center justify-center"><svg class="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 17H20"/><path d="M12.5 17V5"/><path d="M12.5 5H19"/></svg></div>
                    <span class="text-xl font-bold text-white"><?= htmlspecialchars($siteName ?? 'YunLio') ?></span>
                </a>
                <p class="text-gray-500 text-sm max-w-xs mb-6 leading-relaxed"><?= htmlspecialchars($siteDesc ?? '专注电子书免费下载，支持EPUB/MOBI/PDF/TXT/AZW3/CHM全格式') ?></p>
                <div class="flex flex-wrap gap-3 text-sm">
                    <a href="<?= \App\Config::url('/about/') ?>" class="text-gray-500 hover:text-white transition">关于我们</a>
                    <a href="<?= \App\Config::url('/dmca/') ?>" class="text-gray-500 hover:text-white transition">版权声明</a>
                    <a href="<?= \App\Config::url('/contact/') ?>" class="text-gray-500 hover:text-white transition">联系我们</a>
                    <a href="<?= \App\Config::url('/sitemap.xml') ?>" class="text-gray-500 hover:text-white transition" target="_blank" rel="noopener">网站地图</a>
                </div>
            </div>
            
            <!-- Categories -->
            <div>
                <h4 class="text-white font-semibold mb-4">分类导航</h4>
                <ul class="space-y-2.5" role="list">
                    <?php if (!empty($data['categories'])): ?>
                    <?php foreach (array_slice($data['categories'], 0, 8) as $cat): ?>
                    <li><a href="<?= \App\Config::url('/category/' . urlencode($cat['name']) . '/') ?>" class="flex items-center justify-between text-gray-400 hover:text-white text-sm transition group"><span><?= htmlspecialchars($cat['name']) ?></span><span class="text-gray-600 group-hover:text-brand-400 transition text-xs"><?= number_format($cat['count']) ?></span></a></li>
                    <?php endforeach; ?>
                    <?php else: ?><li><a href="#" class="text-gray-500 text-sm">暂无分类</a></li><?php endif; ?>
                </ul>
            </div>
            
            <!-- Hot Tags -->
            <div>
                <h4 class="text-white font-semibold mb-4">热门标签</h4>
                <div class="flex flex-wrap gap-2" role="list">
                    <?php if (!empty($data['tags'])): ?>
                    <?php foreach (array_slice($data['tags'], 0, 12) as $tag): ?>
                    <a href="<?= \App\Config::url('/tag/' . urlencode($tag['name']) . '/') ?>" class="px-3 py-1.5 bg-gray-800 text-gray-300 text-xs rounded-lg hover:bg-brand-900/50 hover:text-white hover:border-brand-800 border border-gray-700 transition" role="listitem"><?= htmlspecialchars($tag['name']) ?></a>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <hr class="border-gray-800 my-8">
        
        <div class="flex flex-col md:flex-row items-center justify-between gap-4">
            <p class="text-gray-500 text-sm">&copy; <?= date('Y') ?> <?= htmlspecialchars($siteName ?? 'YunLio') ?>. 本站不存储文件，资源版权归原作者所有。若侵权请<a href="<?= \App\Config::url('/dmca/') ?>" class="text-brand-400 hover:underline">联系删除</a>。</p>
            <div class="flex items-center gap-4">
                <a href="<?= \App\Config::url('/sitemap.xml') ?>" target="_blank" rel="noopener" class="text-gray-500 hover:text-white text-sm transition">Sitemap</a>
                <a href="<?= \App\Config::url('/robots.txt') ?>" target="_blank" rel="noopener" class="text-gray-500 hover:text-white text-sm transition">Robots.txt</a>
            </div>
        </div>
    </div>
</footer>

<!-- Back to Top -->
<button id="back-to-top" class="fixed bottom-6 right-6 w-11 h-11 bg-brand-600 text-white rounded-full shadow-lg opacity-0 invisible transition-all duration-300 hover:bg-brand-700 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:ring-offset-2 focus:ring-offset-gray-950" aria-label="回到顶部" @click="window.scrollTo({top:0,behavior:'smooth'})"><i class="fa fa-chevron-up text-xl"></i></button>

<!-- Alpine.js -->
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.13.3/dist/cdn.min.js"></script>

<script>
    // Back to top
    const backToTop = document.getElementById('back-to-top');
    let ticking = false;
    window.addEventListener('scroll', () => {
        if (!ticking) {
            requestAnimationFrame(() => {
                if (window.scrollY > 300) { backToTop.classList.remove('opacity-0','invisible'); backToTop.classList.add('opacity-100','visible'); }
                else { backToTop.classList.add('opacity-0','invisible'); backToTop.classList.remove('opacity-100','visible'); }
                ticking = false;
            });
            ticking = true;
        }
    }, { passive: true });
    
    // Copy to clipboard
    document.addEventListener('click', async (e) => {
        const btn = e.target.closest('[data-clipboard-target]');
        if (btn) {
            const target = document.querySelector(btn.getAttribute('data-clipboard-target'));
            if (target) {
                try {
                    await navigator.clipboard.writeText(target.textContent.trim());
                    const original = btn.innerHTML;
                    btn.innerHTML = '<i class="fa fa-check mr-1"></i>已复制';
                    btn.classList.add('text-trust-600','bg-trust-50');
                    setTimeout(() => { btn.innerHTML = original; btn.classList.remove('text-trust-600','bg-trust-50'); }, 2000);
                } catch (err) { console.error('复制失败:', err); }
            }
        }
    });
    
    // SW Registration
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js').catch(() => {}); });
    }
    
    // Download button loading state
    document.addEventListener('click', (e) => {
        const btn = e.target.closest('.btn-download');
        if (btn && !btn.disabled) {
            const original = btn.innerHTML;
            btn.innerHTML = '<i class="fa fa-spinner fa-spin mr-2"></i>准备中...';
            btn.disabled = true;
            setTimeout(() => { btn.innerHTML = original; btn.disabled = false; }, 3000);
        }
    });
</script>
</body>
</html>