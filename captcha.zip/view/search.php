<?php
/** @var array $data */
require_once __DIR__ . '/partials/header.php';
?>

<!-- 搜索头部 -->
<header class="mb-6">
    <h1 class="text-xl md:text-2xl font-bold text-gray-900 mb-2"><?= $data['keyword'] ? '搜索「' . htmlspecialchars($data['keyword']) . '」' : '电子书搜索' ?></h1>
    <?php if ($data['keyword'] && $data['result']): ?><p class="text-gray-600 text-sm mb-3">找到约 <strong class="text-brand-600"><?= number_format($data['result']->total) ?></strong> 个结果</p><?php elseif ($data['keyword']): ?><p class="text-gray-600 text-sm mb-3">未找到相关结果</p><?php endif; ?>
    
    <form action="<?= \App\Config::url('/search/') ?>" method="get" role="search" class="mb-4">
        <div class="flex gap-2"><label for="search-input" class="sr-only">搜索关键词</label><input type="search" id="search-input" name="q" value="<?= htmlspecialchars($data['keyword']) ?>" placeholder="书名、作者、标签、ISBN..." class="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 text-lg" autocomplete="off" required><button type="submit" class="px-6 py-3 bg-brand-600 text-white font-semibold rounded-lg hover:bg-brand-700 transition flex items-center gap-2"><i class="fa fa-search"></i> 搜索</button></div>
    </form>
    
    <?php if ($data['correctedKeyword']): ?><div class="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg"><p class="text-yellow-800"><i class="fa fa-lightbulb mr-2"></i>您是否想搜索：<a href="<?= \App\Config::url('/search/?q=' . urlencode($data['correctedKeyword'])) ?>" class="font-semibold text-yellow-700 underline hover:text-yellow-900"><?= htmlspecialchars($data['correctedKeyword']) ?></a></p></div><?php endif; ?>
    
    <!-- 仅保留排序筛选 -->
    <?php if ($data['keyword'] && $data['result']): ?>
    <div class="flex items-center gap-3 text-sm">
        <label for="filter-sort" class="text-gray-500 whitespace-nowrap">排序：</label>
        <select id="filter-sort" name="sort" class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 bg-white" onchange="this.form.submit()">
            <option value="new" <?= ($data['filters']['sort'] ?? 'new') === 'new' ? 'selected' : '' ?>>最新入库</option>
            <option value="hot" <?= ($data['filters']['sort'] ?? '') === 'hot' ? 'selected' : '' ?>>热门下载</option>
        </select>
        <noscript><button type="submit" class="text-brand-600 hover:underline">筛选</button></noscript>
    </div>
    <?php endif; ?>
</header>

<?php if (!$data['keyword'] && !empty($data['hotTags'])): ?>
<section class="mb-6 lg:hidden"><h2 class="text-lg font-semibold text-gray-900 mb-3">热门搜索</h2><div class="flex flex-wrap gap-2"><?php foreach ($data['hotTags'] as $tag): ?><a href="<?= \App\Config::url('/tag/' . urlencode($tag['name']) . '/') ?>" class="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-lg hover:bg-brand-100 hover:text-brand-700 transition text-sm"><?= htmlspecialchars($tag['name']) ?><span class="text-gray-400 ml-1">(<?= $tag['count'] ?>)</span></a><?php endforeach; ?></div></section>
<?php endif; ?>

<?php if ($data['keyword'] && $data['result'] && !empty($data['result']->items)): ?>
<section aria-labelledby="results-heading">
    <h2 id="results-heading" class="sr-only">搜索结果</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 mb-6" role="list" itemscope itemtype="https://schema.org/ItemList">
        <?php foreach ($data['result']->items as $i => $book): ?><div itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><meta itemprop="position" content="<?= ($data['result']->page - 1) * $data['result']->perPage + $i + 1 ?>"><?php $book['category_url']=$book['category']?\App\Config::url("/category/".urlencode($book['category'])."/"):'';$book['relative_time']=$book['relative_time']??'';$book['iso_date']=$book['iso_date']??'';require_once __DIR__.'/partials/book-card.php';?></div><?php endforeach; ?>
    </div>
    <?php $baseUrl = \App\Config::url('/search/'); $queryParams = array_merge(['total' => $data['result']->total], $_GET); require_once __DIR__ . '/partials/pagination.php'; ?>
</section>

<?php if (!empty($data['result']->suggestions)): ?>
<section class="mb-6"><h2 class="text-lg font-semibold text-gray-900 mb-3">相关搜索建议</h2><div class="flex flex-wrap gap-2"><?php foreach ($data['result']->suggestions as $s): ?><a href="<?= \App\Config::url('/search/?q=' . urlencode($s)) ?>" class="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-lg hover:bg-brand-100 hover:text-brand-700 transition text-sm"><?= htmlspecialchars($s) ?></a><?php endforeach; ?></div></section>
<?php endif; ?>

<?php elseif ($data['keyword']): ?>
<section class="text-center py-12"><div class="bg-white rounded-xl p-8 shadow-sm border border-gray-200 max-w-md mx-auto"><i class="fa fa-search-minus text-5xl text-gray-300 mb-3"></i><h2 class="text-xl font-semibold text-gray-900 mb-1">未找到结果</h2><p class="text-gray-500 mb-5">搜索「<?= htmlspecialchars($data['keyword']) ?>」无匹配</p><ul class="text-sm text-gray-600 space-y-1 text-left max-w-xs mx-auto"><li>• 检查拼写</li><li>• 尝试更短关键词</li><li>• 尝试作者名/ISBN</li><li>• 浏览 <a href="<?= \App\Config::url('/') ?>" class="text-brand-600 hover:underline">分类</a></li></ul></div></section>
<?php endif; ?>

<?php require_once __DIR__ . '/partials/footer.php'; ?>