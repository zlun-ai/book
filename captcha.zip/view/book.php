<?php
/** @var array $data */
require_once __DIR__ . '/partials/header.php';
?>

<article class="max-w-7xl mx-auto" itemscope itemtype="https://schema.org/Book" itemid="<?= htmlspecialchars($data['canonicalUrl']) ?>">
    <meta itemprop="url" content="<?= htmlspecialchars($data['canonicalUrl']) ?>">
    
    <!-- 顶部信息 -->
    <header class="mb-6">
        <div class="flex items-center gap-2 text-sm text-brand-600 font-medium mb-2"><i class="fa fa-book"></i> 电子书详情</div>
        <h1 class="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-3" itemprop="name">《<?= htmlspecialchars($data['book']['title']) ?>》</h1>
        
        <div class="flex flex-wrap items-center gap-2.5 mb-3" itemprop="genre">
            <?php if (!empty($data['book']['category'])): ?><a href="<?= htmlspecialchars($data['book']['category_url']) ?>" class="tag tag-category"><?= htmlspecialchars($data['book']['category']) ?></a><?php endif; ?>
            <span class="tag tag-format <?= strtolower($data['book']['format']) ?>" itemprop="bookFormat"><?= strtoupper($data['book']['format']) ?></span>
            <span class="flex items-center gap-1" itemprop="fileSize" content="<?= htmlspecialchars($data['book']['size']) ?>"><i class="fa fa-file text-gray-400"></i><?= htmlspecialchars($data['book']['size']) ?></span>
            <?php if (!empty($data['book']['source'])): ?><span class="tag tag-source" itemprop="publisher" itemscope itemtype="https://schema.org/Organization"><span itemprop="name"><?= htmlspecialchars($data['book']['source']) ?></span></span><?php endif; ?>
            <?php if (!empty($data['book']['date'])): ?><time itemprop="datePublished" datetime="<?= htmlspecialchars($data['book']['iso_date']) ?>" class="flex items-center gap-1 text-gray-500 text-sm"><i class="fa fa-clock"></i><?= htmlspecialchars($data['book']['relative_time']) ?></time><?php endif; ?>
        </div>
        
        <?php if (!empty($data['book']['tags'])): ?>
        <div class="flex flex-wrap gap-1.5 mb-3" itemprop="keywords"><?php foreach ($data['book']['tags'] as $tag): ?><a href="<?= \App\Config::url('/tag/' . urlencode($tag) . '/') ?>" class="tag tag-format bg-gray-100 text-gray-600 hover:bg-brand-100 hover:text-brand-700 text-xs"><?= htmlspecialchars($tag) ?></a><?php endforeach; ?></div>
        <?php endif; ?>
        
        <?php if (!empty($data['book']['health_status']) && $data['book']['health_status'] !== 'unknown'): ?>
        <div class="health-badge <?= 'health-' . $data['book']['health_status'] ?> inline-flex mb-2"><?= $data['book']['health_text'] ?? '' ?></div>
        <?php endif; ?>
        
        <?php if (!empty($data['book']['last_checked'])): ?>
        <div class="text-xs text-gray-500 mb-4 flex items-center gap-1"><i class="fa fa-clock"></i> 最后验证：<?= date('Y-m-d H:i', strtotime($data['book']['last_checked'])) ?></div>
        <?php endif; ?>
    </header>
    
    <div class="grid lg:grid-cols-3 gap-6">
        <!-- 主内容区 -->
        <div class="lg:col-span-2 space-y-6">
            
            <!-- 下载区 - 核心转化区块，sticky -->
            <section class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 md:p-6 sticky top-24" aria-labelledby="dl-heading" itemprop="offers" itemscope itemtype="https://schema.org/Offer" style="z-index: 100;">
                <meta itemprop="price" content="0"><meta itemprop="priceCurrency" content="CNY"><meta itemprop="availability" content="https://schema.org/InStock"><link itemprop="url" href="<?= \App\Config::url("/api/download/{$data['book']['slug']}") ?>">
                
                <h2 id="dl-heading" class="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2"><i class="fa fa-download text-brand-600"></i> 下载选项</h2>
                
                <div class="space-y-3">
                    <!-- 主下载源 -->
                    <div class="p-4 bg-gray-50 rounded-lg border border-gray-200">
                        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                            <div class="flex items-center gap-3">
                                <div class="w-11 h-11 bg-brand-100 rounded-lg flex items-center justify-center flex-shrink-0"><i class="fa fa-cloud-download-alt text-brand-600 text-xl"></i></div>
                                <div><div class="font-medium text-gray-900">主下载源 (<?= htmlspecialchars($data['book']['source']) ?>)</div><div class="text-sm text-gray-500"><?= strtoupper($data['book']['format']) ?> · <?= htmlspecialchars($data['book']['size']) ?></div></div>
                            </div>
                            
                            <div class="flex flex-col sm:flex-row items-start sm:items-center gap-2 w-full sm:w-auto">
                                <a href="<?= \App\Config::url("/api/download/{$data['book']['slug']}") ?>" class="btn-primary w-full sm:w-auto py-3 text-base" target="_blank" rel="noopener noreferrer" data-track="download_detail" aria-label="下载《<?= htmlspecialchars($data['book']['title']) ?>\""><i class="fa fa-download mr-2"></i>立即下载</a>
                                
                                <?php if (!empty($data['book']['extract_code'])): ?>
                                <div class="flex items-center gap-2 w-full sm:w-auto">
                                    <label class="text-sm text-gray-600 whitespace-nowrap">提取码：</label>
                                    <code id="psw-<?= $data['book']['slug'] ?>" class="px-4 py-2 bg-white border border-gray-300 rounded-lg font-mono text-lg letter-wider text-gray-900 select-all"><?= htmlspecialchars($data['book']['extract_code']) ?></code>
                                    <button class="btn-secondary px-4 py-2" data-clipboard-target="#psw-<?= $data['book']['slug'] ?>" aria-label="复制提取码"><i class="fa fa-copy"></i></button>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 备用源（如果有多个源） -->
                    <?php if (!empty($data['book']['mirrors'])): ?>
                    <div class="border-t border-gray-200 pt-3">
                        <h4 class="text-sm font-medium text-gray-900 mb-3">备用下载源</h4>
                        <div class="space-y-2">
                            <?php foreach ($data['book']['mirrors'] as $mirror): ?>
                            <div class="p-3 bg-gray-50 rounded-lg border border-gray-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                                <div class="flex items-center gap-3 flex-1">
                                    <span class="tag tag-source"><?= htmlspecialchars($mirror['source']) ?></span>
                                    <span class="text-sm text-gray-500"><?= strtoupper($mirror['format'] ?? $data['book']['format']) ?> · <?= htmlspecialchars($mirror['size'] ?? $data['book']['size']) ?></span>
                                </div>
                                <a href="<?= htmlspecialchars($mirror['url']) ?>" class="btn-secondary px-4 py-2 text-sm" target="_blank" rel="noopener noreferrer">备用下载</a>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="mt-4 p-3 bg-brand-50 rounded-lg border border-brand-100">
                    <h4 class="text-sm font-medium text-brand-800 mb-2 flex items-center gap-1"><i class="fa fa-info-circle"></i> 下载说明</h4>
                    <ul class="text-xs text-brand-700 space-y-1">
                        <li>• 建议使用 <strong>IDM / FDM / 迅雷 / Motrix</strong> 等多线程下载工具大幅提速</li>
                        <li>• EPUB 推荐：<a href="https://neat-reader.app/" target="_blank" class="underline">Neat Reader</a> / 微信读书 / Calibre / Apple Books</li>
                        <li>• MOBI/AZW3 适配 Kindle，可通过 <strong>Send to Kindle</strong> / 邮件推送 / USB 传输</li>
                        <li>• 如需提取码，请在下载页复制并在网盘页面输入</li>
                        <li>• 链接有效期 5 分钟，过期请刷新页面重新获取</li>
                    </ul>
                </div>
            </section>
            
            <!-- 元数据完整展示 -->
            <section class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 md:p-6" itemprop="description">
                <h2 class="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2"><i class="fa fa-info-circle text-brand-600"></i> 图书详细信息</h2>
                
                <dl class="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                    <?php if (!empty($data['book']['author'])): ?>
                    <div class="bg-gray-50 rounded-lg p-3"><dt class="text-gray-500 text-xs uppercase tracking-wider">作者</dt><dd class="font-medium text-gray-900 mt-1"><?= htmlspecialchars($data['book']['author']) ?></dd></div>
                    <?php endif; ?>
                    <?php if (!empty($data['book']['publisher'])): ?>
                    <div class="bg-gray-50 rounded-lg p-3"><dt class="text-gray-500 text-xs uppercase tracking-wider">出版社</dt><dd class="font-medium text-gray-900 mt-1"><?= htmlspecialchars($data['book']['publisher']) ?></dd></div>
                    <?php endif; ?>
                    <?php if (!empty($data['book']['isbn'])): ?>
                    <div class="bg-gray-50 rounded-lg p-3"><dt class="text-gray-500 text-xs uppercase tracking-wider">ISBN</dt><dd class="font-medium text-gray-900 mt-1 font-mono"><?= htmlspecialchars($data['book']['isbn']) ?></dd></div>
                    <?php endif; ?>
                    <?php if (!empty($data['book']['pub_year'])): ?>
                    <div class="bg-gray-50 rounded-lg p-3"><dt class="text-gray-500 text-xs uppercase tracking-wider">出版年份</dt><dd class="font-medium text-gray-900 mt-1"><?= htmlspecialchars($data['book']['pub_year']) ?></dd></div>
                    <?php endif; ?>
                    <?php if (!empty($data['book']['pages'])): ?>
                    <div class="bg-gray-50 rounded-lg p-3"><dt class="text-gray-500 text-xs uppercase tracking-wider">页数</dt><dd class="font-medium text-gray-900 mt-1"><?= htmlspecialchars($data['book']['pages']) ?> 页</dd></div>
                    <?php endif; ?>
                    <?php if (!empty($data['book']['language'])): ?>
                    <div class="bg-gray-50 rounded-lg p-3"><dt class="text-gray-500 text-xs uppercase tracking-wider">语言</dt><dd class="font-medium text-gray-900 mt-1"><?= htmlspecialchars($data['book']['language']) ?></dd></div>
                    <?php endif; ?>
                    <?php if (!empty($data['book']['translator'])): ?>
                    <div class="bg-gray-50 rounded-lg p-3"><dt class="text-gray-500 text-xs uppercase tracking-wider">译者</dt><dd class="font-medium text-gray-900 mt-1"><?= htmlspecialchars($data['book']['translator']) ?></dd></div>
                    <?php endif; ?>
                    <?php if (!empty($data['book']['douban_rating'])): ?>
                    <div class="bg-gray-50 rounded-lg p-3"><dt class="text-gray-500 text-xs uppercase tracking-wider">豆瓣评分</dt><dd class="font-medium text-brand-600 mt-1"><?= htmlspecialchars($data['book']['douban_rating']) ?> / 10.0</dd></div>
                    <?php endif; ?>
                </dl>
            </section>
            
            <!-- 内容简介 -->
            <?php if (!empty($data['book']['excerpt'])): ?>
            <section class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 md:p-6" itemprop="description">
                <h2 class="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2"><i class="fa fa-align-left text-brand-600"></i> 内容简介</h2>
                <div class="prose prose-gray max-w-none whitespace-pre-line leading-relaxed"><?= nl2br(htmlspecialchars($data['book']['excerpt'])) ?></div>
            </section>
            <?php endif; ?>
            
            <!-- 目录预览 -->
            <?php if (!empty($data['book']['toc'])): ?>
            <section class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 md:p-6">
                <h2 class="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2"><i class="fa fa-list-ol text-brand-600"></i> 目录预览</h2>
                <div class="prose prose-gray max-w-none line-clamp-10"><?= nl2br(htmlspecialchars($data['book']['toc'])) ?></div>
                <button class="mt-3 text-sm text-brand-600 hover:underline">展开完整目录</button>
            </section>
            <?php endif; ?>
            
            <!-- 推荐阅读器 -->
            <section class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 md:p-6">
                <h2 class="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2"><i class="fa fa-tablet-alt text-brand-600"></i> 推荐阅读器</h2>
                <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
                    <a href="https://neat-reader.app/" target="_blank" rel="noopener" class="p-3 bg-brand-50 rounded-lg border border-brand-100 hover:border-brand-300 hover:bg-brand-100 transition text-center"><i class="fa fa-desktop text-brand-600 text-2xl mb-2"></i><div class="font-medium text-gray-900">Neat Reader</div><div class="text-xs text-gray-500">跨平台 · EPUB/PDF</div></a>
                    <a href="https://weread.qq.com/" target="_blank" rel="noopener" class="p-3 bg-green-50 rounded-lg border border-green-100 hover:border-green-300 hover:bg-green-100 transition text-center"><i class="fa fa-mobile-alt text-green-600 text-2xl mb-2"></i><div class="font-medium text-gray-900">微信读书</div><div class="text-xs text-gray-500">云同步 · 听书</div></a>
                    <a href="https://calibre-ebook.com/" target="_blank" rel="noopener" class="p-3 bg-purple-50 rounded-lg border border-purple-100 hover:border-purple-300 hover:bg-purple-100 transition text-center"><i class="fa fa-cogs text-purple-600 text-2xl mb-2"></i><div class="font-medium text-gray-900">Calibre</div><div class="text-xs text-gray-500">管理 · 转换 · 推送</div></a>
                    <a href="https://www.amazon.com/sendtokindle" target="_blank" rel="noopener" class="p-3 bg-orange-50 rounded-lg border border-orange-100 hover:border-orange-300 hover:bg-orange-100 transition text-center"><i class="fa fa-file-text text-orange-600 text-2xl mb-2"></i><div class="font-medium text-gray-900">Send to Kindle</div><div class="text-xs text-gray-500">官方推送工具</div></a>
                    <a href="https://github.com/koreader/koreader" target="_blank" rel="noopener" class="p-3 bg-gray-100 rounded-lg border border-gray-200 hover:border-gray-300 transition text-center"><i class="fa fa-github text-gray-600 text-2xl mb-2"></i><div class="font-medium text-gray-900">KOReader</div><div class="text-xs text-gray-500">开源 · 电子墨水屏</div></a>
                    <a href="https://github.com/jichuang/glegereader" target="_blank" rel="noopener" class="p-3 bg-gray-100 rounded-lg border border-gray-200 hover:border-gray-300 transition text-center"><i class="fa fa-book-reader text-gray-600 text-2xl mb-2"></i><div class="font-medium text-gray-900">Legereader</div><div class="text-xs text-gray-500">轻量 · 阅读体验佳</div></a>
                </div>
            </section>
            
            <!-- 分享 -->
            <section class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 md:p-6">
                <h2 class="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2"><i class="fa fa-share-alt text-brand-600"></i> 分享本书</h2>
                <div class="flex flex-wrap gap-3">
                    <button onclick="shareToWeibo()" class="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition text-sm flex items-center gap-2"><i class="fa fa-weibo"></i> 微博</button>
                    <button onclick="shareToQQ()" class="px-4 py-2 bg-brand-600 text-white rounded-lg hover:bg-brand-700 transition text-sm flex items-center gap-2"><i class="fa fa-qq"></i> QQ</button>
                    <button onclick="copyLink()" class="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition text-sm flex items-center gap-2"><i class="fa fa-link"></i> 复制链接</button>
                    <button onclick="generatePoster()" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition text-sm flex items-center gap-2"><i class="fa fa-image"></i> 生成海报</button>
                </div>
            </section>
        </div>
        
        <!-- 侧边栏：相关推荐 + 信任信号 -->
        <div class="lg:col-span-1 space-y-6">
            
            <!-- 信任信号卡片 -->
            <section class="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
                <h3 class="font-semibold text-gray-900 mb-4 flex items-center gap-2"><i class="fa fa-shield-alt text-trust-600"></i> 可信下载</h3>
                <div class="space-y-3 text-sm">
                    <div class="flex items-center gap-2 p-3 bg-trust-50 rounded-lg"><i class="fa fa-check-circle text-trust-600"></i><div><strong class="text-trust-700">链接已验证</strong><div class="text-trust-600"><?= !empty($data['book']['last_checked']) ? '最后检查：' . date('Y-m-d H:i', strtotime($data['book']['last_checked'])) : '暂无记录' ?></div></div></div>
                    <div class="flex items-center gap-2 p-3 bg-brand-50 rounded-lg"><i class="fa fa-download text-brand-600"></i><div><strong class="text-brand-700">下载量</strong><div class="text-brand-600"><?= number_format($data['book']['download_count'] ?? 0) ?> 次下载</div></div></div>
                    <div class="flex items-center gap-2 p-3 bg-gray-50 rounded-lg"><i class="fa fa-clock text-gray-500"></i><div><strong class="text-gray-700">入库时间</strong><div class="text-gray-600"><?= !empty($data['book']['date']) ? $data['book']['relative_time'] : '未知' ?></div></div></div>
                </div>
            </section>
            
            <!-- 相关推荐 -->
            <?php if (!empty($data['relatedBooks'])): ?>
            <section aria-labelledby="rel-heading">
                <h2 id="rel-heading" class="text-lg font-semibold text-gray-900 mb-4">猜你喜欢</h2>
                <div class="space-y-3" role="list" itemscope itemtype="https://schema.org/ItemList">
                    <?php foreach ($data['relatedBooks'] as $i => $book): ?>
                    <div itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem" class="bg-white rounded-lg border border-gray-200 p-3 hover:border-brand-200 transition">
                        <meta itemprop="position" content="<?= $i + 1 ?>">
                        <a href="<?= \App\Config::url("/book/{$book['slug']}.html") ?>" class="flex items-start gap-3" itemprop="url">
                            <img src="<?= !empty($book['format']) ? \App\Config::asset("images/{$book['format']}.jpg") : \App\Config::asset('images/default.jpg') ?>" alt="" class="w-14 h-18 object-cover rounded flex-shrink-0" loading="lazy" onerror="this.src='<?= \App\Config::asset('images/default.jpg') ?>';this.onerror=null;">
                            <div class="flex-1 min-w-0">
                                <h4 class="font-medium text-gray-900 line-clamp-1 mb-1" itemprop="name">《<?= htmlspecialchars($book['title']) ?>》</h4>
                                <div class="flex items-center gap-2 text-xs text-gray-500">
                                    <span class="tag tag-format <?= strtolower($book['format']) ?>"><?= strtoupper($book['format']) ?></span>
                                    <span><?= htmlspecialchars($book['size']) ?></span>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
                <a href="<?= \App\Config::url('/search/?q=' . urlencode($data['book']['title'])) ?>" class="block mt-3 text-center text-sm text-brand-600 hover:text-brand-700 font-medium">查看更多相关书籍 <i class="fa fa-arrow-right ml-1"></i></a>
            </section>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- 分享功能脚本 -->
    <script>
        function copyLink() {
            navigator.clipboard.writeText(window.location.href).then(() => {
                alert('链接已复制到剪贴板');
            });
        }
        function shareToWeibo() {
            const title = encodeURIComponent('《<?= addslashes($data['book']['title']) ?>》 - 免费电子书下载');
            const url = encodeURIComponent(window.location.href);
            window.open('http://service.weibo.com/share/share.php?title=' + title + '&url=' + url, '_blank', 'width=600,height=400');
        }
        function shareToQQ() {
            const title = encodeURIComponent('《<?= addslashes($data['book']['title']) ?>》 - 免费电子书下载');
            const url = encodeURIComponent(window.location.href);
            window.open('http://connect.qq.com/widget/shareqq/index.html?title=' + title + '&url=' + url, '_blank', 'width=600,height=400');
        }
        function generatePoster() {
            alert('海报生成功能开发中...');
        }
    </script>

</article>

<!-- Structured Data -->
<?php if (!empty($data['structuredData'])): ?><script type="application/ld+json"><?= $data['structuredData'] ?></script><?php endif; ?>

<?php require_once __DIR__ . '/partials/footer.php'; ?>