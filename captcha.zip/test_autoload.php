<?php
require_once 'src/Autoloader.php';
$c = new \App\Config();
echo "OK\n";
echo "Config loaded: " . (\App\Config::app('name') ?? 'null') . "\n";