<?php 

/**
 * API Request Caching
 *
 *  Use server-side caching to store API request's as JSON at a set 
 *  interval, rather than each pageload.
 * 
 * @arg Argument description and usage info
 */
class Cache{
	public static  $dir = "./cache";
	public static  $file_dir = $dir."/data";
	public static $cache_map_file = $dir."/cache_map.json";
	public static $cache_file_num = 1000;
	public static $cache_map = array();
	
	public static function init() {
        // 如果缓存路径不存在，则新建
		if( !file_exists(self::$cache_file) ){
			mkdir(self::$cache_file);
		}
        if( !file_exists(self::$file_dir) ){
			mkdir(self::$file_dir);
		}
        if(file_exists(self::$cache_map_file)){
            $json = file_get_contents(self::$cache_map_file); // 读取文件
            self::$cache_map = json_decode($json, true);        // 转换为关联数组
		}
        date_default_timezone_set('UTC');
    }
    public static function is_cached($key){
        //$key = md5($request_url);
        if (array_key_exists($key, self::$cache_map) && self::cache_file_exists($key)) {
            return true;
        }
        return false;
    }
    public static function cache_file_exists($key){
        $fx = self::$file_dir."/".$key.".json";
        if( !file_exists($fx){
			return false;
		}
        return true;
    }
    public static function update_cache_time($key){
        $t = time();
        self::$cache_map[$key] = $t;
    }
    public static function remove_cache($key, $remove_cache_file = true){
        if(is_cached($key)){
            unset(self::$cache_map[$key]);
        }
        if($remove_cache_file){
            self::remove_cache_file($key);
        }

    }
    public static function remove_cache_file($key){
        $fx = self::$file_dir."/".$key.".json";
        if(file_exists($fx){
			unlink($fx);
		}
    }
    public static function add_cache_file($key, $content){
        if(array_key_exists($key, self::$cache_map)){
            $fx = self::$file_dir."/".$key.".json";
            file_put_contents($fx, $content, LOCK_EX);
        }
    }

    public static function delete_caches($num = 10){
        $slice = array_slice(self::$cache_map, 0, $num, true);
        #
        foreach ($slice as  $k => $v) {
           self::remove_cache($k);
        }
    }

    // 增加缓存
	public function add_cache($requst_url, $content){
	    //增加，先判断是否存在
	    $key = md5($request_url);
	    if(is_cached($key)){ // 缓存存在
	        self::remove_cache($key, false);
	        self::update_cache_time($key);
	        return True;
	    }
        // 如果故存在
        //  判断是否超过了缓存数量
        if(count(self::$cache_map)> self::$cache_file_num){
            //删除
            self::delete_caches();
        }
        if(count(self::$cache_map) < self::$cache_file_num){
            #add
            self::update_cache_time($key);
            ## file
            self::add_cache_file($key, $content);
        }
	}
    public static function get_cache_content($request_url){
        $key = md5($request_url);
	    if(self::is_cached($key)){ // 缓存存在
	        $fx = self::$file_dir."/".$key.".json";
	        $json = file_get_contents($fx);
	        return json_decode($json, true));;
	    }
        //
        self::remove_cache_file($key);
        return array();
    }

}
?>