<?php
include "../config.php";
include "../fun.php";

$all_cats = get_all_cats();

?>
<?php
$q = get_param("q");
$safe_q = get_safe_search($q);
if($safe_q == ""){
	header("Location: ".HOME_URL);
	exit;
}else{
//get_search($q);
$title = $safe_q."搜索结果";
?>
<?php
include "../template/link-search-demo.html";
}
?>