<?php
require_once __DIR__ . '/src/Autoloader.php';
\App\Config::load(__DIR__ . '/config/app.php');

$pdo = \App\Database::getInstance();
$row = $pdo->query('SHOW TABLE STATUS LIKE "download_logs"')->fetch();
echo 'Engine: ' . $row['Engine'] . PHP_EOL;
echo 'Rows: ' . $row['Rows'] . PHP_EOL;