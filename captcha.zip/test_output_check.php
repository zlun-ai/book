<?php
require_once __DIR__ . '/src/Autoloader.php';
\App\Config::load(__DIR__ . '/config/app.php');
\App\Cache::configure(\App\Config::cache());

// Simulate a request
$_SERVER['REQUEST_METHOD'] = 'GET';
$_SERVER['REQUEST_URI'] = '/';
$_SERVER['QUERY_STRING'] = '';
$_SERVER['SCRIPT_NAME'] = '/index.php';
$_SERVER['SCRIPT_FILENAME'] = __DIR__ . '/public/index.php';

// Capture output
ob_start();
include __DIR__ . '/public/index.php';
$output = ob_get_clean();

// Check for BOM
if (substr($output, 0, 3) === "\xEF\xBB\xBF") {
    echo "WARNING: BOM detected at start of output!\n";
}

// Check for UTF-8 validity
if (!mb_check_encoding($output, 'UTF-8')) {
    echo "WARNING: Output is not valid UTF-8!\n";
}

// Find the title in the output
$pos = strpos($output, '发现好书');
if ($pos !== false) {
    echo "Found main title at position $pos\n";
    echo "Context: " . substr($output, max(0, $pos-100), 200) . "\n\n";
}

// Check book card titles
$pos = strpos($output, '气候变迁');
if ($pos !== false) {
    echo "Found book title at position $pos\n";
    echo "Context: " . substr($output, max(0, $pos-100), 300) . "\n\n";
}

// Check for any non-UTF8 sequences
$nonUtf8 = preg_match('/[^\x00-\x7F\xC2-\xDF][\x80-\xBF]|\xE0[\xA0-\xBF][\x80-\xBF]|\xED[\x80-\x9F][\x80-\xBF]|\xF0[\x90-\xBF][\x80-\xBF][\x80-\xBF]/', $output);
if (!$nonUtf8 && preg_match('/[\x80-\xFF]/', $output)) {
    echo "WARNING: Possible non-UTF8 sequences found\n";
}

// Check for any output before <!DOCTYPE
$doctypePos = strpos($output, '<!DOCTYPE');
if ($doctypePos !== false && $doctypePos > 0) {
    echo "WARNING: Output before DOCTYPE (position: $doctypePos)\n";
    echo "Prefix: '" . substr($output, 0, $doctypePos) . "'\n";
}

echo "Done.\n";