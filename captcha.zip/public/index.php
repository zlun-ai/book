<?php

/**
 * 统一入口文件
 * 所有请求通过此文件路由分发
 */

// 设置错误报告
error_reporting(E_ALL);
ini_set('display_errors', '1');

// 定义常量
define('BASE_PATH', __DIR__ . '/..');
define('PUBLIC_PATH', __DIR__);

// 加载自动加载器
require_once BASE_PATH . '/src/Autoloader.php';

// 加载配置
\App\Config::load(BASE_PATH . '/config/app.php');

// 配置缓存
\App\Cache::configure(\App\Config::cache());

// 配置数据库（已在 Config::load 中自动配置）

// 设置时区
date_default_timezone_set(\App\Config::app('timezone', 'Asia/Shanghai'));

// 引入路由配置
$router = require BASE_PATH . '/config/routes.php';

// 获取请求方法和 URI
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);

// 移除基础路径（如果部署在子目录 /01-book-link/）
$basePath = '/01-book-link';
if (str_starts_with($uri, $basePath)) {
    $uri = substr($uri, strlen($basePath));
}
$uri = $uri ?: '/';

// 应用安全头
\App\Middleware\SecurityHeadersMiddleware::applyHeaders();

// 应用缓存控制
$cacheMiddleware = new \App\Middleware\CacheControlMiddleware();
$params = [];
$cacheMiddleware->handle($params);

// 执行路由分发
try {
    $response = $router->dispatch($method, $uri);
    
    // 如果返回的是 Response 对象，发送它
    if ($response instanceof \App\Http\Response) {
        $response->send();
    } elseif ($response !== null) {
        // 如果返回其他内容，直接输出
        echo $response;
    }
} catch (\Throwable $e) {
    // 错误处理
    http_response_code(500);
    
    if (\App\Config::app('debug')) {
        echo '<h1>500 Internal Server Error</h1>';
        echo '<pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
        echo '<pre>' . htmlspecialchars($e->getTraceAsString()) . '</pre>';
    } else {
        echo '<h1>500 Internal Server Error</h1>';
        echo '<p>服务器内部错误，请稍后再试。</p>';
    }
    
    error_log('Unhandled exception: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
}