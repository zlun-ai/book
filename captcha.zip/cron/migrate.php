<?php

/**
 * 数据库迁移脚本
 * 运行一次即可：php cron/migrate.php
 */

require_once __DIR__ . '/../src/Autoloader.php';
\App\Config::load(__DIR__ . '/../config/app.php');
\App\Database::configure(\App\Config::all());

use App\Database;

echo "开始数据库迁移...\n";

$migrations = [
    // 1. 为 all_links 表添加 link_status 和 last_checked 字段
    "ALTER TABLE `all_links` 
        ADD COLUMN IF NOT EXISTS `link_status` TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT '链接状态：1正常 2需密码 3限速 4失效' AFTER `file_src`,
        ADD COLUMN IF NOT EXISTS `last_checked` DATETIME NULL COMMENT '最后检查时间' AFTER `link_status`",
    
    // 2. 创建下载日志表
    "CREATE TABLE IF NOT EXISTS `download_logs` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `book_slug` VARCHAR(64) NOT NULL COMMENT '书籍 slug',
        `mirror` VARCHAR(32) DEFAULT 'default' COMMENT '镜像源',
        `ip_hash` CHAR(64) NOT NULL COMMENT 'IP 哈希',
        `user_agent` VARCHAR(512) DEFAULT '' COMMENT 'User Agent',
        `status` ENUM('success','failed','expired','dead_link') NOT NULL DEFAULT 'success' COMMENT '下载状态',
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        INDEX `idx_book_date` (`book_slug`, `created_at`),
        INDEX `idx_date` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='下载日志表'",
    
    // 3. 创建链接健康检查表
    "CREATE TABLE IF NOT EXISTS `link_health` (
        `book_slug` VARCHAR(64) NOT NULL COMMENT '书籍 slug',
        `mirror` VARCHAR(32) NOT NULL DEFAULT 'default' COMMENT '镜像源',
        `status` ENUM('healthy','need_password','rate_limited','dead') NOT NULL DEFAULT 'healthy' COMMENT '健康状态',
        `http_code` SMALLINT UNSIGNED DEFAULT 0 COMMENT 'HTTP 状态码',
        `response_time_ms` INT UNSIGNED DEFAULT 0 COMMENT '响应时间(毫秒)',
        `last_checked` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`book_slug`, `mirror`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='链接健康检查表'",
    
    // 4. 为 all_links 添加全文索引（如果不存在）
    // 注意：MySQL 5.6+ 支持中文全文索引需要 ngram 解析器
    // "ALTER TABLE `all_links` ADD FULLTEXT INDEX `ft_search` (`file_name`, `link_words`, `file_category`, `file_tag`) WITH PARSER ngram",
];

$success = 0;
$failed = 0;

foreach ($migrations as $index => $sql) {
    echo "执行迁移 #" . ($index + 1) . "... ";
    try {
        $result = Database::execute($sql);
        if ($result !== false) {
            echo "成功\n";
            $success++;
        } else {
            echo "失败 (可能已存在)\n";
            $failed++;
        }
    } catch (\Throwable $e) {
        echo "异常: " . $e->getMessage() . "\n";
        $failed++;
    }
}

echo "\n迁移完成: 成功 $success, 失败/跳过 $failed\n";

// 验证表结构
echo "\n验证表结构:\n";
$tables = ['all_links', 'download_logs', 'link_health'];
foreach ($tables as $table) {
    $result = Database::query("SHOW COLUMNS FROM `$table`");
    echo "  $table: " . count($result) . " 列\n";
}