<?php

/**
 * 链接健康检查 Cron 脚本
 * 建议每天运行一次：0 3 * * * /usr/bin/php /path/to/01-book-link/cron/check_links.php
 */

// 设置无限执行时间
set_time_limit(0);
ini_set('memory_limit', '256M');

// 加载自动加载器
require_once __DIR__ . '/../src/Autoloader.php';

// 加载配置
\App\Config::load(__DIR__ . '/../config/app.php');

// 配置缓存
\App\Cache::configure(\App\Config::cache()->all());

// 配置数据库
\App\Database::configure(\App\Config::all());

use App\Service\DownloadService;
use App\LogRepository;
use App\Database;

echo "[" . date('Y-m-d H:i:s') . "] 开始链接健康检查...\n";

$downloadService = new DownloadService();
$logRepo = new LogRepository();

// 获取待检查链接
$links = $logRepo->getLinksToCheck(200); // 每次最多检查 200 个

if (empty($links)) {
    echo "[" . date('Y-m-d H:i:s') . "] 没有需要检查的链接\n";
    exit(0);
}

echo "[" . date('Y-m-d H:i:s') . "] 待检查链接数: " . count($links) . "\n";

$stats = [
    'total' => 0,
    'healthy' => 0,
    'need_password' => 0,
    'rate_limited' => 0,
    'dead' => 0,
    'errors' => 0,
];

foreach ($links as $index => $link) {
    $slug = $link['link_slug'];
    $url = $link['link_url'];
    $source = $link['file_src'] ?? 'default';
    
    if (empty($url)) {
        echo "  [{$slug}] 无下载链接，标记为 dead\n";
        $logRepo->updateLinkHealth($slug, $source, 'dead', 0, 0);
        $stats['dead']++;
        $stats['total']++;
        continue;
    }
    
    echo "  [{$slug}] 检查中... (" . ($index + 1) . "/" . count($links) . ")\n";
    
    try {
        $result = $downloadService->checkLinkHealth($slug);
        
        $stats['total']++;
        $stats[$result['status']] = ($stats[$result['status']] ?? 0) + 1;
        
        $statusIcon = match($result['status']) {
            'healthy' => '✓',
            'need_password' => '⚠',
            'rate_limited' => '⚡',
            'dead' => '✗',
            default => '?',
        };
        
        echo "    {$statusIcon} {$result['status']} (HTTP {$result['http_code']}, {$result['response_time']}ms)\n";
        
        // 如果链接失效，可选择发送通知邮件
        if ($result['status'] === 'dead') {
            // sendAdminAlert($slug, $url); // 可选：实现邮件通知
        }
    } catch (\Throwable $e) {
        echo "    ✗ 错误: " . $e->getMessage() . "\n";
        $stats['errors']++;
        $stats['total']++;
        
        // 出错不修改状态，下次重试
    }
    
    // 避免请求过快被封 IP
    if ($index < count($links) - 1) {
        usleep(200000); // 200ms
    }
}

// 清理过期缓存
$cleaned = \App\Cache::gc(86400 * 7); // 清理 7 天前的缓存
echo "[" . date('Y-m-d H:i:s') . "] 清理过期缓存: {$cleaned} 个文件\n";

// 统计汇总
echo "\n=== 检查完成 ===\n";
echo "总计: {$stats['total']}\n";
echo "正常: {$stats['healthy']}\n";
echo "需密码: {$stats['need_password']}\n";
echo "限速: {$stats['rate_limited']}\n";
echo "失效: {$stats['dead']}\n";
echo "错误: {$stats['errors']}\n";

$healthyRate = $stats['total'] > 0 ? round($stats['healthy'] / $stats['total'] * 100, 1) : 0;
echo "健康率: {$healthyRate}%\n";

echo "[" . date('Y-m-d H:i:s') . "] 链接健康检查结束\n";

// 可选：记录到日志文件
$logFile = __DIR__ . '/../storage/logs/link_check_' . date('Y-m') . '.log';
$logDir = dirname($logFile);
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}
$logEntry = sprintf(
    "[%s] 总计:%d 正常:%d 需密码:%d 限速:%d 失效:%d 错误:%d 健康率:%.1f%%\n",
    date('Y-m-d H:i:s'),
    $stats['total'],
    $stats['healthy'],
    $stats['need_password'],
    $stats['rate_limited'],
    $stats['dead'],
    $stats['errors'],
    $healthyRate
);
@file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);