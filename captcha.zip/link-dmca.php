<?php
include "config.php";
include "fun.php";
?>
<?php
$all_cats = get_all_cats();
?>
<?php
?>
<?php
include "template/link-page-dmca.html";

?>