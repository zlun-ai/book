<?php
require_once __DIR__ . '/src/Autoloader.php';
\App\Config::load(__DIR__ . '/config/app.php');
\App\Cache::configure(\App\Config::cache());

\App\Cache::flush();

echo "Cache cleared." . PHP_EOL;

// Check date ranges in database
$db = \App\Database::getInstance();

// Check current date
echo "Current date: " . date('Y-m-d H:i:s') . PHP_EOL;

// Check date ranges
$stmt = $db->query("SELECT 
    COUNT(*) as total,
    MIN(file_time) as min_date,
    MAX(file_time) as max_date
FROM all_links");
$row = $stmt->fetch();
echo "Total books: {$row['total']}, Min date: {$row['min_date']}, Max date: {$row['max_date']}" . PHP_EOL;

// Check last 24 hours
$stmt = $db->query("SELECT COUNT(*) as c FROM all_links WHERE file_time >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
echo "24h count: " . $stmt->fetch()['c'] . PHP_EOL;

// Check last 7 days
$stmt = $db->query("SELECT COUNT(*) as c FROM all_links WHERE file_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
echo "7 days count: " . $stmt->fetch()['c'] . PHP_EOL;

// Check last 30 days
$stmt = $db->query("SELECT COUNT(*) as c FROM all_links WHERE file_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
echo "30 days count: " . $stmt->fetch()['c'] . PHP_EOL;

// Check if file_time is in the future or has issues
$stmt = $db->query("SELECT file_time, link_id FROM all_links WHERE file_time > NOW() LIMIT 5");
$rows = $stmt->fetchAll();
echo "Future dates:" . PHP_EOL;
foreach ($rows as $row) {
    echo "ID: {$row['link_id']}, file_time: {$row['file_time']}" . PHP_EOL;
}

// Check last 10 entries
$stmt = $db->query("SELECT link_id, file_time FROM all_links ORDER BY link_id DESC LIMIT 20");
$rows = $stmt->fetchAll();
echo "Latest 20 entries:" . PHP_EOL;
foreach ($rows as $row) {
    echo "ID: {$row['link_id']}, file_time: {$row['file_time']}" . PHP_EOL;
}