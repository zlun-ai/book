<?php
require_once __DIR__ . '/src/Autoloader.php';
\App\Config::load(__DIR__ . '/config/app.php');
\App\Cache::configure(\App\Config::cache());

// Clear all cache
\App\Cache::flush();

echo "Cache cleared." . PHP_EOL;