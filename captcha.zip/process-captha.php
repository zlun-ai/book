<?php
session_start();
include "config.php";
include "fun.php";
include_once "cookie.php";
?>
<?php
$code = get_param("code");
$slug = get_param("slug");
if(strtoupper($_SESSION["captcha"]) == strtoupper($code)){
$cookie = new CookieManager(
    '/', 
    '127.0.0.1',  //example.com
    true,   // Secure - 仅HTTPS
    true,   // HttpOnly - 防止XSS
    'Strict' // SameSite - 防止CSRF
);

	if ($cookie->exists($slug)){
		$ux = $cookie->get($slug);
		$url = custom_decode($ux);
		echo '获取下载地址成功：<a href="'.$url.'"  target="_blank">点击下载！</a>';
	}else{
		echo "验证码超时，请刷新页面重试！";
	}
}else{
	echo "验证码验证失败，请重新输入！";
}
?>