<?php
require_once __DIR__ . '/src/Autoloader.php';
\App\Config::load(__DIR__ . '/config/app.php');

$pdo = \App\Database::getInstance();
$rows = $pdo->query('DESCRIBE all_links')->fetchAll();
foreach($rows as $r) {
    echo $r['Field'] . ' - ' . $r['Type'] . PHP_EOL;
}