<?php

namespace App;

class Config
{
    private static array $config = [];
    private static bool $loaded = false;

    public static function load(string $path = null): void
    {
        if (self::$loaded) {
            return;
        }

        $path = $path ?? __DIR__ . '/../../config/app.php';
        if (!file_exists($path)) {
            throw new \RuntimeException('Config file not found: ' . $path);
        }

        self::$config = require $path;
        self::$loaded = true;

        // 配置数据库
        if (isset(self::$config['database'])) {
            \App\Database::configure(self::$config);
        }
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        if (!self::$loaded) {
            self::load();
        }

        $keys = explode('.', $key);
        $value = self::$config;

        foreach ($keys as $k) {
            if (!is_array($value) || !array_key_exists($k, $value)) {
                return $default;
            }
            $value = $value[$k];
        }

        return $value;
    }

    public static function all(): array
    {
        if (!self::$loaded) {
            self::load();
        }
        return self::$config;
    }

    // 便捷方法
    public static function app(string $key = null, mixed $default = null): mixed
    {
        return $key ? self::get('app.' . $key, $default) : self::get('app', $default);
    }

    public static function db(string $key = null, mixed $default = null): mixed
    {
        return $key ? self::get('database.' . $key, $default) : self::get('database', $default);
    }

    public static function jwt(string $key = null, mixed $default = null): mixed
    {
        return $key ? self::get('jwt.' . $key, $default) : self::get('jwt', $default);
    }

    public static function cache(string $key = null, mixed $default = null): mixed
    {
        return $key ? self::get('cache.' . $key, $default) : self::get('cache', $default);
    }

    public static function pagination(string $key = null, mixed $default = null): mixed
    {
        return $key ? self::get('pagination.' . $key, $default) : self::get('pagination', $default);
    }

    public static function search(string $key = null, mixed $default = null): mixed
    {
        return $key ? self::get('search.' . $key, $default) : self::get('search', $default);
    }

    public static function download(string $key = null, mixed $default = null): mixed
    {
        return $key ? self::get('download.' . $key, $default) : self::get('download', $default);
    }

    public static function linkHealth(string $key = null, mixed $default = null): mixed
    {
        return $key ? self::get('link_health.' . $key, $default) : self::get('link_health', $default);
    }

    public static function security(string $key = null, mixed $default = null): mixed
    {
        return $key ? self::get('security.' . $key, $default) : self::get('security', $default);
    }

    public static function wpApi(string $key = null, mixed $default = null): mixed
    {
        return $key ? self::get('wp_api.' . $key, $default) : self::get('wp_api', $default);
    }

    public static function url(string $path = ''): string
    {
        $base = rtrim(self::app('url'), '/');
        $path = ltrim($path, '/');
        return $base . ($path ? '/' . $path : '');
    }

    public static function asset(string $path): string
    {
        return self::url('assets/' . ltrim($path, '/'));
    }
}