<?php

namespace App\DTO;

class BookDTO
{
    public string $slug = '';
    public string $title = '';
    public string $category = '';
    public string $format = '';
    public string $size = '';
    public string $downloadUrl = '';
    public string $extractCode = '';
    public string $source = '';
    public string $date = '';
    public string $excerpt = '';
    public array $tags = [];
    public int $downloadCount = 0;
    public string $healthStatus = 'unknown';
    public ?string $lastChecked = null;
    
    // 扩展字段（用于详情页丰富展示）
    public string $author = '';
    public string $publisher = '';
    public string $isbn = '';
    public string $pubYear = '';
    public string $pages = '';
    public string $language = '';
    public string $translator = '';
    public string $doubanRating = '';
    public string $toc = '';
    public array $mirrors = [];

    public static function fromArray(array $data): self
    {
        $dto = new self();
        $dto->slug = $data['link_slug'] ?? $data['slug'] ?? '';
        $dto->title = $data['file_name'] ?? $data['title'] ?? '';
        $dto->category = $data['file_category'] ?? $data['category'] ?? '';
        $dto->format = strtolower($data['file_type'] ?? $data['format'] ?? '');
        $dto->size = $data['file_size'] ?? $data['size'] ?? '';
        $dto->downloadUrl = $data['link_url'] ?? $data['download_url'] ?? '';
        $dto->extractCode = $data['link_psw'] ?? $data['extract_code'] ?? '';
        $dto->source = $data['file_src'] ?? $data['source'] ?? '';
        $dto->date = $data['file_time'] ?? $data['date'] ?? '';
        $dto->excerpt = $data['link_words'] ?? $data['excerpt'] ?? '';
        $dto->tags = $dto->parseTags($data['file_tag'] ?? $data['tags'] ?? '');
        $dto->downloadCount = (int)($data['download_count'] ?? $data['link_download'] ?? 0);
        $dto->healthStatus = $data['health_status'] ?? 'unknown';
        $dto->lastChecked = $data['last_checked'] ?? null;
        
        // 扩展字段
        $dto->author = $data['author'] ?? $data['file_author'] ?? '';
        $dto->publisher = $data['publisher'] ?? $data['file_publisher'] ?? '';
        $dto->isbn = $data['isbn'] ?? $data['file_isbn'] ?? '';
        $dto->pubYear = $data['pub_year'] ?? $data['file_pub_year'] ?? '';
        $dto->pages = $data['pages'] ?? $data['file_pages'] ?? '';
        $dto->language = $data['language'] ?? $data['file_language'] ?? '';
        $dto->translator = $data['translator'] ?? $data['file_translator'] ?? '';
        $dto->doubanRating = $data['douban_rating'] ?? $data['file_douban_rating'] ?? '';
        $dto->toc = $data['toc'] ?? $data['file_toc'] ?? '';
        
        // 多源镜像
        if (!empty($data['mirrors']) && is_array($data['mirrors'])) {
            $dto->mirrors = $data['mirrors'];
        } elseif (!empty($data['mirror_url'])) {
            $dto->mirrors = [[
                'source' => $data['mirror_source'] ?? '',
                'format' => $data['mirror_format'] ?? '',
                'size' => $data['mirror_size'] ?? '',
                'url' => $data['mirror_url'] ?? '',
            ]];
        }
        
        return $dto;
    }

    public static function fromWPObject(object $obj): self
    {
        $dto = new self();
        $dto->slug = $obj->post_slug ?? '';
        $dto->title = $obj->post_title ?? '';
        $dto->category = $obj->post_category ?? '';
        $dto->format = strtolower($obj->post_format ?? '');
        $dto->size = $obj->post_filesize ?? '';
        $dto->downloadUrl = $obj->post_link ?? '';
        $dto->extractCode = $obj->post_psw ?? '';
        $dto->source = $obj->post_src ?? '';
        $dto->date = $obj->post_date ?? '';
        $dto->excerpt = $obj->post_excerpt ?? '';
        $dto->tags = $dto->parseTags($obj->post_tag ?? '');
        return $dto;
    }

    private function parseTags(string $tags): array
    {
        if (empty($tags)) {
            return [];
        }
        return array_filter(array_map('trim', explode(',', $tags)));
    }

    public function toArray(): array
    {
        return [
            'slug' => $this->slug,
            'title' => $this->title,
            'category' => $this->category,
            'format' => $this->format,
            'size' => $this->size,
            'download_url' => $this->downloadUrl,
            'extract_code' => $this->extractCode,
            'source' => $this->source,
            'date' => $this->date,
            'excerpt' => $this->excerpt,
            'tags' => $this->tags,
            'download_count' => $this->downloadCount,
            'health_status' => $this->healthStatus,
            'last_checked' => $this->lastChecked,
            'category_url' => $this->getCategoryUrl(),
            'format_url' => $this->getFormatUrl(),
            'canonical_url' => $this->getCanonicalUrl(),
            'relative_time' => $this->getRelativeTime(),
            'iso_date' => $this->getIsoDate(),
            // 扩展字段
            'author' => $this->author,
            'publisher' => $this->publisher,
            'isbn' => $this->isbn,
            'pub_year' => $this->pubYear,
            'pages' => $this->pages,
            'language' => $this->language,
            'translator' => $this->translator,
            'douban_rating' => $this->doubanRating,
            'toc' => $this->toc,
            'mirrors' => $this->mirrors,
        ];
    }

    public function getRelativeTime(): string
    {
        if (empty($this->date)) {
            return '';
        }
        
        $timestamp = strtotime($this->date);
        if ($timestamp === false) {
            return $this->date;
        }
        
        $diff = time() - $timestamp;
        
        if ($diff < 60) {
            return '刚刚';
        } elseif ($diff < 3600) {
            return floor($diff / 60) . '分钟前';
        } elseif ($diff < 86400) {
            return floor($diff / 3600) . '小时前';
        } elseif ($diff < 604800) {
            return floor($diff / 86400) . '天前';
        } elseif ($diff < 2592000) {
            return floor($diff / 604800) . '周前';
        } else {
            return date('Y-m-d', $timestamp);
        }
    }

    public function getIsoDate(): string
    {
        if (empty($this->date)) {
            return date('c');
        }
        $timestamp = strtotime($this->date);
        return $timestamp ? date('c', $timestamp) : date('c');
    }

    public function getFormatDisplay(): string
    {
        return strtoupper($this->format);
    }

    public function getSizeDisplay(): string
    {
        if (empty($this->size)) {
            return '未知';
        }
        return $this->size;
    }

    public function hasExtractCode(): bool
    {
        return !empty($this->extractCode);
    }

    public function getHealthClass(): string
    {
        return match($this->healthStatus) {
            'healthy' => 'healthy',
            'need_password' => 'warning',
            'rate_limited' => 'warning',
            'dead' => 'danger',
            default => 'unknown',
        };
    }

    public function getHealthText(): string
    {
        return match($this->healthStatus) {
            'healthy' => '🟢 链接正常',
            'need_password' => '🟡 需提取码',
            'rate_limited' => '🟠 限速/需客户端',
            'dead' => '🔴 链接失效',
            default => '⚪ 未检测',
        };
    }

    public function getCanonicalUrl(): string
    {
        return \App\Config::url("/book/{$this->slug}.html");
    }

    public function getCategoryUrl(): string
    {
        if (empty($this->category)) {
            return '';
        }
        return \App\Config::url('/category/' . urlencode($this->category) . '/');
    }

    public function getTagUrls(): array
    {
        return array_map(fn($tag) => \App\Config::url('/tag/' . urlencode($tag) . '/'), $this->tags);
    }

    public function getFormatUrl(): string
    {
        if (empty($this->format)) {
            return '';
        }
        return \App\Config::url('/format/' . $this->format . '/');
    }

    public function getStructuredData(): array
    {
        return [
            '@context' => 'https://schema.org',
            '@type' => 'Book',
            '@id' => $this->getCanonicalUrl(),
            'name' => "《{$this->title}》",
            'bookFormat' => $this->getFormatDisplay(),
            'fileSize' => $this->getSizeDisplay(),
            'datePublished' => $this->getIsoDate(),
            'description' => $this->excerpt ? mb_substr($this->excerpt, 0, 200) . '...' : '',
            'keywords' => $this->tags,
            'genre' => $this->category,
            'publisher' => [
                '@type' => 'Organization',
                'name' => $this->source,
            ],
            'offers' => [
                '@type' => 'Offer',
                'price' => '0',
                'priceCurrency' => 'CNY',
                'availability' => 'https://schema.org/InStock',
                'url' => $this->getCanonicalUrl(),
                'description' => $this->source . ' 下载' . ($this->extractCode ? "，提取码: {$this->extractCode}" : ''),
            ],
            'isFamilyFriendly' => true,
            'inLanguage' => 'zh-CN',
        ];
    }
}