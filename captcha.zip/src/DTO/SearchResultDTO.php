<?php

namespace App\DTO;

class SearchResultDTO
{
    public array $items = [];
    public int $total = 0;
    public int $page = 1;
    public int $perPage = 20;
    public int $lastPage = 1;
    public string $query = '';
    public array $suggestions = [];
    public array $facets = [];

    public static function fromArray(array $data): self
    {
        $dto = new self();
        $dto->items = array_map(fn($item) => BookDTO::fromArray($item), $data['items'] ?? []);
        $dto->total = (int)($data['total'] ?? 0);
        $dto->page = (int)($data['page'] ?? 1);
        $dto->perPage = (int)($data['per_page'] ?? 20);
        $dto->lastPage = (int)ceil($dto->total / $dto->perPage);
        $dto->query = $data['query'] ?? '';
        $dto->suggestions = $data['suggestions'] ?? [];
        $dto->facets = $data['facets'] ?? [];
        return $dto;
    }

    public function toArray(): array
    {
        return [
            'items' => array_map(fn($item) => $item->toArray(), $this->items),
            'total' => $this->total,
            'page' => $this->page,
            'per_page' => $this->perPage,
            'last_page' => $this->lastPage,
            'query' => $this->query,
            'suggestions' => $this->suggestions,
            'facets' => $this->facets,
        ];
    }

    public function getPaginationLinks(): array
    {
        $baseUrl = \App\Config::url('/search/') . '?q=' . urlencode($this->query) . '&per_page=' . $this->perPage;
        
        return [
            'first' => $this->page > 1 ? $baseUrl . '&page=1' : null,
            'prev' => $this->page > 1 ? $baseUrl . '&page=' . ($this->page - 1) : null,
            'next' => $this->page < $this->lastPage ? $baseUrl . '&page=' . ($this->page + 1) : null,
            'last' => $this->page < $this->lastPage ? $baseUrl . '&page=' . $this->lastPage : null,
        ];
    }
}