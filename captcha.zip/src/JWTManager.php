<?php

namespace App;

class JWT
{
    /**
     * 编码 JWT
     */
    public static function encode(array $payload, string $key, string $algo = 'HS256'): string
    {
        $header = ['typ' => 'JWT', 'alg' => $algo];
        
        $base64Header = self::base64UrlEncode(json_encode($header));
        $base64Payload = self::base64UrlEncode(json_encode($payload));
        
        $signature = self::sign("$base64Header.$base64Payload", $key, $algo);
        $base64Signature = self::base64UrlEncode($signature);
        
        return "$base64Header.$base64Payload.$base64Signature";
    }

    /**
     * 解码 JWT（不验证签名）
     */
    public static function decode(string $token, string $key, string $algo = 'HS256'): array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            throw new \InvalidArgumentException('Invalid token format');
        }

        [$base64Header, $base64Payload, $base64Signature] = $parts;
        
        // 验证签名
        $expectedSignature = self::sign("$base64Header.$base64Payload", $key, $algo);
        $providedSignature = self::base64UrlDecode($base64Signature);
        
        if (!hash_equals($expectedSignature, $providedSignature)) {
            throw new \InvalidArgumentException('Invalid signature');
        }

        $payload = json_decode(self::base64UrlDecode($base64Payload), true);
        if ($payload === null) {
            throw new \InvalidArgumentException('Invalid payload');
        }

        return $payload;
    }

    /**
     * 验证并解码（带过期检查）
     */
    public static function validate(string $token, string $key, array $constraints = []): array
    {
        $payload = self::decode($token, $key);
        
        $now = time();
        
        // 检查过期时间
        if (isset($payload['exp']) && $payload['exp'] < $now) {
            throw new \InvalidArgumentException('Token expired');
        }
        
        // 检查生效时间
        if (isset($payload['nbf']) && $payload['nbf'] > $now) {
            throw new \InvalidArgumentException('Token not yet valid');
        }
        
        // 检查签发者
        if (!empty($constraints['issuer']) && ($payload['iss'] ?? '') !== $constraints['issuer']) {
            throw new \InvalidArgumentException('Invalid issuer');
        }
        
        // 检查受众
        if (!empty($constraints['audience']) && ($payload['aud'] ?? '') !== $constraints['audience']) {
            throw new \InvalidArgumentException('Invalid audience');
        }
        
        // 检查 IP 绑定
        if (!empty($constraints['bind_ip']) && !empty($payload['ip'])) {
            $currentIpHash = hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . $key);
            if (!hash_equals($payload['ip'], $currentIpHash)) {
                throw new \InvalidArgumentException('IP mismatch');
            }
        }
        
        // 检查自定义约束
        foreach ($constraints as $k => $v) {
            if (in_array($k, ['issuer', 'audience', 'bind_ip'])) continue;
            if (!isset($payload[$k]) || $payload[$k] !== $v) {
                throw new \InvalidArgumentException("Constraint failed: {$k}");
            }
        }
        
        return $payload;
    }

    private static function sign(string $data, string $key, string $algo): string
    {
        $algoMap = [
            'HS256' => 'sha256',
            'HS384' => 'sha384',
            'HS512' => 'sha512',
        ];
        
        $hashAlgo = $algoMap[$algo] ?? 'sha256';
        return hash_hmac($hashAlgo, $data, $key, true);
    }

    private static function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private static function base64UrlDecode(string $data): string
    {
        $remainder = strlen($data) % 4;
        if ($remainder) {
            $data .= str_repeat('=', 4 - $remainder);
        }
        return base64_decode(strtr($data, '-_', '+/'));
    }
}

class JWTManager
{
    private string $secret;
    private string $algorithm;
    private int $ttl;
    private string $issuer;
    private string $audience;

    public function __construct(array $config = [])
    {
        $this->secret = $config['secret'] ?? \App\Config::jwt('secret');
        $this->algorithm = $config['algorithm'] ?? \App\Config::jwt('algorithm', 'HS256');
        $this->ttl = $config['ttl'] ?? \App\Config::jwt('ttl', 300);
        $this->issuer = $config['issuer'] ?? \App\Config::jwt('issuer', 'yunlio.com');
        $this->audience = $config['audience'] ?? \App\Config::jwt('audience', 'yunlio-users');
    }

    public function encode(array $payload): string
    {
        $now = time();
        $payload = array_merge([
            'iss' => $this->issuer,
            'aud' => $this->audience,
            'iat' => $now,
            'nbf' => $now,
            'exp' => $now + $this->ttl,
            'jti' => bin2hex(random_bytes(16)),
        ], $payload);

        return JWT::encode($payload, $this->secret, $this->algorithm);
    }

    public function decode(string $token): array
    {
        return JWT::decode($token, $this->secret, $this->algorithm);
    }

    public function validate(string $token, array $constraints = []): array
    {
        return JWT::validate($token, $this->secret, $constraints);
    }

    public static function createDownloadToken(string $slug, string $url, array $options = []): string
    {
        $manager = new self();
        $payload = [
            'slug' => $slug,
            'url' => $url,
            'type' => 'download',
        ];

        if (!empty($options['mirror'])) {
            $payload['mirror'] = $options['mirror'];
        }

        if (\App\Config::download('bind_ip', true)) {
            $payload['ip'] = hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . \App\Config::jwt('secret'));
        }

        if (!empty($options['ttl'])) {
            $manager = new self(array_merge(\App\Config::jwt(), ['ttl' => $options['ttl']]));
        }

        return $manager->encode($payload);
    }

    public static function validateDownloadToken(string $token): array
    {
        $manager = new self();
        $payload = $manager->validate($token, [
            'type' => 'download',
            'bind_ip' => \App\Config::download('bind_ip', true),
        ]);

        if (!isset($payload['slug'], $payload['url'])) {
            throw new \InvalidArgumentException('Invalid download token payload');
        }

        return $payload;
    }
}