<?php

/**
 * 简易 PSR-4 自动加载器（替代 Composer）
 */
class Autoloader
{
    private static array $prefixes = [];
    private static bool $registered = false;

    public static function register(): void
    {
        if (self::$registered) {
            return;
        }
        
        spl_autoload_register([self::class, 'load']);
        self::$registered = true;
    }

    public static function addNamespace(string $prefix, string $baseDir): void
    {
        $prefix = trim($prefix, '\\') . '\\';
        $baseDir = rtrim($baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
        
        if (!isset(self::$prefixes[$prefix])) {
            self::$prefixes[$prefix] = [];
        }
        self::$prefixes[$prefix][] = $baseDir;
    }

    public static function load(string $class): bool
    {
        foreach (self::$prefixes as $prefix => $dirs) {
            if (str_starts_with($class, $prefix)) {
                $relativeClass = substr($class, strlen($prefix));
                $fileName = str_replace('\\', DIRECTORY_SEPARATOR, $relativeClass) . '.php';
                
                foreach ($dirs as $dir) {
                    $file = $dir . $fileName;
                    if (file_exists($file)) {
                        require $file;
                        return true;
                    }
                }
            }
        }
        return false;
    }
}

// 注册自动加载器
Autoloader::register();

// 注册命名空间
$baseDir = __DIR__; // src/ 目录
Autoloader::addNamespace('App', $baseDir);
Autoloader::addNamespace('App\\Controller', $baseDir . '/Controller');
Autoloader::addNamespace('App\\Service', $baseDir . '/Service');
Autoloader::addNamespace('App\\Repository', $baseDir . '/Repository');
Autoloader::addNamespace('App\\DTO', $baseDir . '/DTO');
Autoloader::addNamespace('App\\Middleware', $baseDir . '/Middleware');
Autoloader::addNamespace('App\\Router', $baseDir . '/Router');
Autoloader::addNamespace('App\\Http', $baseDir . '/Http');
Autoloader::addNamespace('App\\View', $baseDir . '/View');