<?php

namespace App;

use PDO;
use PDOException;

class Database
{
    private static ?PDO $instance = null;
    private static array $config = [];

    public static function configure(array $config): void
    {
        self::$config = $config;
        self::$instance = null;
    }

    public static function getInstance(): PDO
    {
        if (self::$instance === null) {
            $cfg = self::$config['database'] ?? [];
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=%s',
                $cfg['host'] ?? '127.0.0.1',
                $cfg['port'] ?? 3306,
                $cfg['database'] ?? '',
                $cfg['charset'] ?? 'utf8mb4'
            );

            try {
                self::$instance = new PDO(
                    $dsn,
                    $cfg['username'] ?? '',
                    $cfg['password'] ?? '',
                    $cfg['options'] ?? [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false,
                    ]
                );
            } catch (PDOException $e) {
                if (($cfg['debug'] ?? false) || isset($_SERVER['SERVER_NAME']) && $_SERVER['SERVER_NAME'] === 'localhost') {
                    die('数据库连接失败: ' . $e->getMessage());
                }
                error_log('Database connection failed: ' . $e->getMessage());
                die('服务暂时不可用，请稍后再试');
            }
        }
        return self::$instance;
    }

    public static function query(string $sql, array $params = []): array
    {
        try {
            $stmt = self::getInstance()->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log('Query error: ' . $e->getMessage() . ' - SQL: ' . $sql);
            return [];
        }
    }

    public static function queryOne(string $sql, array $params = []): ?array
    {
        $results = self::query($sql, $params);
        return $results ? $results[0] : null;
    }

    public static function execute(string $sql, array $params = []): int|bool
    {
        try {
            $stmt = self::getInstance()->prepare($sql);
            $stmt->execute($params);
            return $stmt->rowCount();
        } catch (PDOException $e) {
            error_log('Execute error: ' . $e->getMessage() . ' - SQL: ' . $sql);
            return false;
        }
    }

    public static function lastInsertId(): string
    {
        return self::getInstance()->lastInsertId();
    }

    public static function beginTransaction(): bool
    {
        return self::getInstance()->beginTransaction();
    }

    public static function commit(): bool
    {
        return self::getInstance()->commit();
    }

    public static function rollBack(): bool
    {
        return self::getInstance()->rollBack();
    }

    public static function close(): void
    {
        self::$instance = null;
    }
}