<?php

namespace App\Service;

use App\Repository\BookRepository;
use App\Cache;
use App\Config;
use App\DTO\SearchResultDTO;

class SearchService
{
    private BookRepository $bookRepo;

    public function __construct()
    {
        $this->bookRepo = new BookRepository();
    }

    public function search(string $keyword, int $page = 1, int $perPage = 20, array $filters = []): SearchResultDTO
    {
        $keyword = $this->sanitizeKeyword($keyword);
        
        if (mb_strlen($keyword) < Config::search('min_query_length', 2)) {
            return new SearchResultDTO();
        }

        $cacheKey = "search:" . md5($keyword . ':' . json_encode($filters) . ":{$page}:{$perPage}");
        
        return Cache::remember($cacheKey, Config::cache('short_ttl', 60), function() use ($keyword, $page, $perPage, $filters) {
            $items = $this->bookRepo->search($keyword, $page, $perPage, $filters);
            $total = $this->bookRepo->countSearch($keyword, $filters);
            
            $dto = new SearchResultDTO();
            $dto->items = $items;
            $dto->total = $total;
            $dto->page = $page;
            $dto->perPage = $perPage;
            $dto->lastPage = (int)ceil($total / $perPage);
            $dto->query = $keyword;
            $dto->suggestions = $this->getSuggestions($keyword);
            $dto->facets = $this->getFacets($keyword, $filters);
            
            return $dto;
        });
    }

    public function getSuggestions(string $keyword, int $limit = 10): array
    {
        $keyword = $this->sanitizeKeyword($keyword);
        if (mb_strlen($keyword) < 2) {
            return [];
        }

        $cacheKey = "suggest:" . md5($keyword);
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), function() use ($keyword, $limit) {
            // 从标题、标签、分类中获取建议
            $suggestions = [];
            
            // 标题前缀匹配
            $titleSuggestions = $this->getTitleSuggestions($keyword, $limit);
            $suggestions = array_merge($suggestions, $titleSuggestions);
            
            // 标签匹配
            $tagSuggestions = $this->getTagSuggestions($keyword, $limit);
            $suggestions = array_merge($suggestions, $tagSuggestions);
            
            // 去重并限制数量
            $suggestions = array_unique($suggestions);
            return array_slice($suggestions, 0, $limit);
        });
    }

    private function getTitleSuggestions(string $keyword, int $limit): array
    {
        $sql = "SELECT file_name FROM all_links WHERE file_name LIKE ? LIMIT ?";
        $rows = \App\Database::query($sql, ["{$keyword}%", $limit]);
        return array_column($rows, 'file_name');
    }

    private function getTagSuggestions(string $keyword, int $limit): array
    {
        $sql = "SELECT DISTINCT file_tag FROM all_links WHERE file_tag LIKE ? LIMIT ?";
        $rows = \App\Database::query($sql, ["%{$keyword}%", $limit]);
        
        $tags = [];
        foreach ($rows as $row) {
            $tagList = array_filter(array_map('trim', explode(',', str_replace('，', ',', $row['file_tag'] ?? ''))));
            foreach ($tagList as $tag) {
                if (!empty($tag) && stripos($tag, $keyword) !== false) {
                    $tags[] = $tag;
                }
            }
        }
        return array_unique($tags);
    }

    private function getFacets(string $keyword, array $filters): array
    {
        // 获取分面统计（分类、格式、来源分布）
        $facets = [
            'categories' => [],
            'formats' => [],
            'sources' => [],
        ];
        
        // 这里简化处理，实际可以单独查询
        return $facets;
    }

    private function sanitizeKeyword(string $keyword): string
    {
        $keyword = trim($keyword);
        // 移除特殊字符，保留中文、英文、数字、空格
        $keyword = preg_replace('/[^\p{L}\p{N}\s\-_]/u', ' ', $keyword);
        // 合并多个空格
        $keyword = preg_replace('/\s+/', ' ', $keyword);
        return trim($keyword);
    }

    public function correctSpelling(string $keyword): ?string
    {
        // 简单的拼写纠错：基于编辑距离和拼音
        // 这里可以集成更复杂的纠错库
        return null;
    }
}