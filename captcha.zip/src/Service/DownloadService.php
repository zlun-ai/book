<?php

namespace App\Service;

use App\Repository\BookRepository;
use App\Repository\LogRepository;
use App\JWTManager;
use App\Config;

class DownloadService
{
    private BookRepository $bookRepo;
    private LogRepository $logRepo;

    public function __construct()
    {
        $this->bookRepo = new BookRepository();
        $this->logRepo = new LogRepository();
    }

    public function generateDownloadToken(string $slug): ?array
    {
        $book = $this->bookRepo->findBySlug($slug);
        if (!$book) {
            return null;
        }

        if (empty($book->downloadUrl)) {
            return null;
        }

        $token = JWTManager::createDownloadToken(
            $slug,
            $book->downloadUrl,
            ['mirror' => $book->source ?: 'default']
        );

        $downloadUrl = Config::url("/api/download/{$slug}?token={$token}");

        return [
            'slug' => $slug,
            'title' => $book->title,
            'format' => $book->format,
            'size' => $book->size,
            'source' => $book->source,
            'extract_code' => $book->extractCode,
            'download_url' => $downloadUrl,
            'direct_url' => $book->downloadUrl,
            'health_status' => $book->healthStatus,
            'health_text' => $book->getHealthText(),
        ];
    }

    public function validateAndRedirect(string $token): ?string
    {
        try {
            $payload = JWTManager::validateDownloadToken($token);
            
            $slug = $payload['slug'] ?? '';
            $url = $payload['url'] ?? '';
            $mirror = $payload['mirror'] ?? 'default';
            
            if (empty($slug) || empty($url)) {
                return null;
            }

            // 验证 slug 是否存在
            $book = $this->bookRepo->findBySlug($slug);
            if (!$book) {
                return null;
            }

            // 记录下载日志
            if (Config::download('log_downloads', true)) {
                $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
                $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
                $this->logRepo->logDownload($slug, $mirror, $ip, $ua);
            }

            return $url;
        } catch (\Exception $e) {
            error_log('Download token validation failed: ' . $e->getMessage());
            return null;
        }
    }

    public function checkLinkHealth(string $slug): array
    {
        $book = $this->bookRepo->findBySlug($slug);
        if (!$book || empty($book->downloadUrl)) {
            return [
                'status' => 'dead',
                'http_code' => 0,
                'response_time' => 0,
                'message' => 'No download URL',
            ];
        }

        $result = $this->httpHead($book->downloadUrl);
        
        $status = match(true) {
            in_array($result['code'], Config::linkHealth('healthy_codes', [200, 206])) => 'healthy',
            in_array($result['code'], Config::linkHealth('need_password_codes', [401, 403])) => 'need_password',
            in_array($result['code'], Config::linkHealth('rate_limit_codes', [429])) => 'rate_limited',
            default => 'dead',
        };

        // 更新健康状态
        $this->logRepo->updateLinkHealth(
            $slug,
            $book->source ?: 'default',
            $status,
            $result['code'],
            $result['response_time']
        );

        return [
            'status' => $status,
            'http_code' => $result['code'],
            'response_time' => $result['response_time'],
            'message' => $this->getStatusMessage($status),
        ];
    }

    private function httpHead(string $url): array
    {
        $timeout = Config::linkHealth('check_timeout', 10);
        $maxRedirects = Config::linkHealth('max_redirects', 3);
        
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_NOBODY => true,
            CURLOPT_HEADER => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => $maxRedirects,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; YunLio Bot/1.0)',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);

        $start = microtime(true);
        curl_exec($ch);
        $responseTime = (int)((microtime(true) - $start) * 1000);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return [
                'code' => 0,
                'response_time' => $responseTime,
                'error' => $error,
            ];
        }

        return [
            'code' => $httpCode,
            'response_time' => $responseTime,
        ];
    }

    private function getStatusMessage(string $status): string
    {
        return match($status) {
            'healthy' => '链接正常，可直接下载',
            'need_password' => '需要提取码或登录',
            'rate_limited' => '下载受限，建议使用客户端',
            'dead' => '链接已失效',
            default => '状态未知',
        };
    }

    public function batchCheckLinks(int $limit = 50): array
    {
        $links = $this->logRepo->getLinksToCheck($limit);
        $results = [];

        foreach ($links as $link) {
            $result = $this->checkLinkHealth($link['link_slug']);
            $results[] = array_merge($link, $result);
            
            // 避免请求过快
            usleep(100000); // 100ms
        }

        return $results;
    }
}