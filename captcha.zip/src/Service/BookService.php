<?php

namespace App\Service;

use App\Repository\BookRepository;
use App\Repository\LogRepository;
use App\Cache;
use App\Config;
use App\DTO\BookDTO;

class BookService
{
    private BookRepository $bookRepo;
    private LogRepository $logRepo;

    public function __construct()
    {
        $this->bookRepo = new BookRepository();
        $this->logRepo = new LogRepository();
    }

    public function getBook(string $slug): ?BookDTO
    {
        $cacheKey = "book:{$slug}";
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), fn() => $this->bookRepo->findBySlug($slug));
    }

    public function getBooksByCategory(string $category, int $page = 1, int $perPage = 20, string $sort = 'new'): array
    {
        $cacheKey = "category:{$category}:page:{$page}:per:{$perPage}:sort:{$sort}";
        return Cache::remember($cacheKey, Config::cache('default_ttl', 300), function() use ($category, $page, $perPage, $sort) {
            return $this->bookRepo->findByCategory($category, $page, $perPage, $sort);
        });
    }

    public function countBooksByCategory(string $category): int
    {
        $cacheKey = "category:{$category}:count";
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), function() use ($category) {
            return $this->bookRepo->countByCategory($category);
        });
    }

    public function getBooksByTag(string $tag, int $page = 1, int $perPage = 20, string $sort = 'new'): array
    {
        $cacheKey = "tag:{$tag}:page:{$page}:per:{$perPage}:sort:{$sort}";
        return Cache::remember($cacheKey, Config::cache('default_ttl', 300), function() use ($tag, $page, $perPage, $sort) {
            return $this->bookRepo->findByTag($tag, $page, $perPage, $sort);
        });
    }

    public function countBooksByTag(string $tag): int
    {
        $cacheKey = "tag:{$tag}:count";
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), function() use ($tag) {
            return $this->bookRepo->countByTag($tag);
        });
    }

    public function getBooksByFormat(string $format, int $page = 1, int $perPage = 20, string $sort = 'new'): array
    {
        $cacheKey = "format:{$format}:page:{$page}:per:{$perPage}:sort:{$sort}";
        return Cache::remember($cacheKey, Config::cache('default_ttl', 300), function() use ($format, $page, $perPage, $sort) {
            return $this->bookRepo->findByFormat($format, $page, $perPage, $sort);
        });
    }

    public function countBooksByFormat(string $format): int
    {
        $cacheKey = "format:{$format}:count";
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), function() use ($format) {
            return $this->bookRepo->countByFormat($format);
        });
    }

    public function getBooksBySource(string $source, int $page = 1, int $perPage = 20): array
    {
        $cacheKey = "source:{$source}:page:{$page}:per:{$perPage}";
        return Cache::remember($cacheKey, Config::cache('default_ttl', 300), function() use ($source, $page, $perPage) {
            return $this->bookRepo->findBySource($source, $page, $perPage);
        });
    }

    public function countBooksBySource(string $source): int
    {
        $cacheKey = "source:{$source}:count";
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), function() use ($source) {
            return $this->bookRepo->countBySource($source);
        });
    }

    public function getLatest(int $limit = 10, int $offset = 0): array
    {
        $cacheKey = "books:latest:{$limit}:offset:{$offset}";
        return Cache::remember($cacheKey, Config::cache('default_ttl', 300), function() use ($limit, $offset) {
            return $this->bookRepo->getLatest($limit, $offset);
        });
    }

    public function countLatest(): int
    {
        $cacheKey = 'books:latest:count';
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), function() {
            return $this->bookRepo->countLatest();
        });
    }

    public function getHot(int $limit = 10, int $days = 30): array
    {
        $cacheKey = "books:hot:{$limit}:days:{$days}";
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), function() use ($limit, $days) {
            return $this->bookRepo->getHot($limit, $days);
        });
    }

    public function getPopular24h(int $limit = 20): array
    {
        $cacheKey = "books:popular:24h:{$limit}";
        return Cache::remember($cacheKey, Config::cache('default_ttl', 300), function() use ($limit) {
            return $this->bookRepo->getPopular24h($limit);
        });
    }

    public function getPopularWeek(int $limit = 20): array
    {
        $cacheKey = "books:popular:week:{$limit}";
        return Cache::remember($cacheKey, Config::cache('default_ttl', 300), function() use ($limit) {
            return $this->bookRepo->getPopularWeek($limit);
        });
    }

    public function getPopularMonth(int $limit = 20): array
    {
        $cacheKey = "books:popular:month:{$limit}";
        return Cache::remember($cacheKey, Config::cache('default_ttl', 300), function() use ($limit) {
            return $this->bookRepo->getPopularMonth($limit);
        });
    }

    public function getRelated(string $slug, int $limit = 6): array
    {
        $cacheKey = "book:{$slug}:related:{$limit}";
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), function() use ($slug, $limit) {
            return $this->bookRepo->getRelated($slug, $limit);
        });
    }

    public function getCategories(): array
    {
        $cacheKey = 'categories:all';
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), function() {
            return $this->bookRepo->getCategories();
        });
    }

    public function getTags(int $limit = 50): array
    {
        $cacheKey = "tags:hot:{$limit}";
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), function() use ($limit) {
            return $this->bookRepo->getTags($limit);
        });
    }

    public function getFormats(): array
    {
        $cacheKey = 'formats:all';
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), function() {
            return $this->bookRepo->getFormats();
        });
    }

    public function getSources(): array
    {
        $cacheKey = 'sources:all';
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), function() {
            return $this->bookRepo->getSources();
        });
    }

    public function getStats(): array
    {
        $cacheKey = 'stats:overview';
        return Cache::remember($cacheKey, Config::cache('long_ttl', 3600), function() {
            $stats = $this->bookRepo->getStats();
            $stats['total_downloads_30d'] = $this->logRepo->getTotalDownloads(30);
            return $stats;
        });
    }

    public function recordDownload(string $slug, string $mirror = 'default'): void
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $this->logRepo->logDownload($slug, $mirror, $ip, $ua);
        
        // 更新 all_links 表的下载次数和最后下载时间
        $sql = "UPDATE all_links SET link_download = link_download + 1, last_download_time = NOW() WHERE link_slug = ?";
        \App\Database::execute($sql, [$slug]);
        
        // 使相关缓存失效
        Cache::delete("book:{$slug}");
        Cache::delete("stats:overview");
    }
}