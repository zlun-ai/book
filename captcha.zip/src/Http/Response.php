<?php

namespace App\Http;

class Response
{
    private int $statusCode = 200;
    private array $headers = [];
    private mixed $content = null;
    private bool $sent = false;

    public static function make(mixed $content = null, int $statusCode = 200, array $headers = []): self
    {
        $response = new self();
        $response->content = $content;
        $response->statusCode = $statusCode;
        $response->headers = $headers;
        return $response;
    }

    public static function json(mixed $data, int $statusCode = 200, array $headers = []): self
    {
        $headers = array_merge([
            'Content-Type' => 'application/json; charset=utf-8',
        ], $headers);
        
        return self::make(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $statusCode, $headers);
    }

    public static function success(mixed $data = null, string $message = 'ok', int $statusCode = 200): self
    {
        return self::json([
            'code' => $statusCode,
            'message' => $message,
            'data' => $data,
        ], $statusCode);
    }

    public static function error(string $message = 'Error', int $statusCode = 400, mixed $data = null): self
    {
        return self::json([
            'code' => $statusCode,
            'message' => $message,
            'data' => $data,
        ], $statusCode);
    }

    public static function paginated(array $items, int $page, int $perPage, int $total, string $message = 'ok'): self
    {
        $lastPage = (int) ceil($total / $perPage);
        
        return self::json([
            'code' => 200,
            'message' => $message,
            'data' => $items,
            'meta' => [
                'current_page' => $page,
                'per_page' => $perPage,
                'total' => $total,
                'last_page' => $lastPage,
                'from' => $total > 0 ? ($page - 1) * $perPage + 1 : 0,
                'to' => min($page * $perPage, $total),
            ],
            'links' => [
                'first' => $page > 1 ? "?page=1&per_page={$perPage}" : null,
                'prev' => $page > 1 ? "?page=" . ($page - 1) . "&per_page={$perPage}" : null,
                'next' => $page < $lastPage ? "?page=" . ($page + 1) . "&per_page={$perPage}" : null,
                'last' => $page < $lastPage ? "?page={$lastPage}&per_page={$perPage}" : null,
            ],
        ]);
    }

    public static function view(string $view, array $data = [], int $statusCode = 200): self
    {
        ob_start();
        extract($data);
        include __DIR__ . "/../../view/{$view}.php";
        $content = ob_get_clean();
        
        return self::make($content, $statusCode, [
            'Content-Type' => 'text/html; charset=utf-8',
        ]);
    }

    public static function redirect(string $url, int $statusCode = 302): self
    {
        return self::make('', $statusCode, [
            'Location' => $url,
            'Content-Type' => 'text/html; charset=utf-8',
        ]);
    }

    public static function download(string $url, int $statusCode = 302): self
    {
        return self::redirect($url, $statusCode);
    }

    public function withStatus(int $statusCode): self
    {
        $this->statusCode = $statusCode;
        return $this;
    }

    public function withHeader(string $key, string $value): self
    {
        $this->headers[$key] = $value;
        return $this;
    }

    public function withHeaders(array $headers): self
    {
        $this->headers = array_merge($this->headers, $headers);
        return $this;
    }

    public function send(): void
    {
        if ($this->sent) {
            return;
        }

        http_response_code($this->statusCode);
        
        foreach ($this->headers as $key => $value) {
            header("{$key}: {$value}");
        }
        
        echo $this->content;
        $this->sent = true;
    }

    public function getStatusCode(): int
    {
        return $this->statusCode;
    }

    public function getHeaders(): array
    {
        return $this->headers;
    }

    public function getContent(): mixed
    {
        return $this->content;
    }
}