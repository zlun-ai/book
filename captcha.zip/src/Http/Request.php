<?php

namespace App\Http;

class Request
{
    private array $query;
    private array $body;
    private array $headers;
    private array $server;
    private array $files;
    private string $method;
    private string $uri;
    private string $ip;

    public function __construct()
    {
        $this->query = $_GET;
        $this->server = $_SERVER;
        $this->files = $_FILES;
        $this->method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $this->uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $this->headers = $this->parseHeaders();
        $this->body = $this->parseBody();
        $this->ip = $this->detectIp();
    }

    private function parseHeaders(): array
    {
        $headers = [];
        foreach ($_SERVER as $key => $value) {
            if (str_starts_with($key, 'HTTP_')) {
                $header = str_replace('_', '-', substr($key, 5));
                $headers[strtolower($header)] = $value;
            } elseif (in_array($key, ['CONTENT_TYPE', 'CONTENT_LENGTH'])) {
                $headers[strtolower(str_replace('_', '-', $key))] = $value;
            }
        }
        return $headers;
    }

    private function parseBody(): array
    {
        $contentType = $this->headers['content-type'] ?? '';
        
        if (str_contains($contentType, 'application/json')) {
            $input = file_get_contents('php://input');
            $data = json_decode($input, true);
            return is_array($data) ? $data : [];
        }
        
        if (str_contains($contentType, 'application/x-www-form-urlencoded')) {
            return $_POST;
        }
        
        if (str_contains($contentType, 'multipart/form-data')) {
            return $_POST;
        }
        
        return [];
    }

    private function detectIp(): string
    {
        $headers = [
            'http_x_forwarded_for',
            'http_x_real_ip',
            'http_client_ip',
        ];
        
        foreach ($headers as $header) {
            if (!empty($this->server[$header])) {
                $ips = explode(',', $this->server[$header]);
                return trim($ips[0]);
            }
        }
        
        return $this->server['REMOTE_ADDR'] ?? '127.0.0.1';
    }

    public function getMethod(): string
    {
        return $this->method;
    }

    public function getUri(): string
    {
        return $this->uri;
    }

    public function getIp(): string
    {
        return $this->ip;
    }

    public function query(string $key, mixed $default = null): mixed
    {
        return $this->query[$key] ?? $default;
    }

    public function allQuery(): array
    {
        return $this->query;
    }

    public function input(string $key, mixed $default = null): mixed
    {
        return $this->body[$key] ?? $this->query[$key] ?? $default;
    }

    public function all(): array
    {
        return array_merge($this->query, $this->body);
    }

    public function header(string $key, mixed $default = null): mixed
    {
        return $this->headers[strtolower($key)] ?? $default;
    }

    public function headers(): array
    {
        return $this->headers;
    }

    public function bearerToken(): ?string
    {
        $auth = $this->header('authorization');
        if ($auth && str_starts_with($auth, 'Bearer ')) {
            return substr($auth, 7);
        }
        return null;
    }

    public function file(string $key): ?array
    {
        return $this->files[$key] ?? null;
    }

    public function hasFile(string $key): bool
    {
        return isset($this->files[$key]) && $this->files[$key]['error'] === UPLOAD_ERR_OK;
    }

    public function isAjax(): bool
    {
        return $this->header('x-requested-with') === 'XMLHttpRequest';
    }

    public function isJson(): bool
    {
        return str_contains($this->header('content-type', ''), 'application/json');
    }

    public function wantsJson(): bool
    {
        return $this->isAjax() || $this->isJson() || str_contains($this->header('accept', ''), 'application/json');
    }

    public function segment(int $index, mixed $default = null): mixed
    {
        $segments = array_filter(explode('/', trim($this->uri, '/')));
        $segments = array_values($segments);
        return $segments[$index - 1] ?? $default;
    }

    public function path(): string
    {
        return $this->uri;
    }

    public function fullUrl(): string
    {
        return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') 
            . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    }

    public function ajax(): bool
    {
        return $this->isAjax();
    }
}