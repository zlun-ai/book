<?php

namespace App\Repository;

use App\Database;
use App\DTO\BookDTO;

class BookRepository
{
    private string $table = 'all_links';

    public function findBySlug(string $slug): ?BookDTO
    {
        $sql = "SELECT * FROM {$this->table} WHERE link_slug = ? ORDER BY link_id DESC LIMIT 1";
        $row = Database::queryOne($sql, [$slug]);
        return $row ? BookDTO::fromArray($row) : null;
    }

    public function findBySlugMultiple(string $slug): array
    {
        $sql = "SELECT * FROM {$this->table} WHERE link_slug = ? ORDER BY link_id DESC LIMIT 10";
        $rows = Database::query($sql, [$slug]);
        return array_map(fn($row) => BookDTO::fromArray($row), $rows);
    }

    public function findByCategory(string $category, int $page = 1, int $perPage = 20, string $sort = 'new'): array
    {
        $offset = ($page - 1) * $perPage;
        
        $orderBy = match($sort) {
            'hot' => 'link_id DESC', // 简化：用ID代替下载量
            'size_asc' => 'CAST(REPLACE(file_size, "MB", "") AS DECIMAL) ASC',
            'size_desc' => 'CAST(REPLACE(file_size, "MB", "") AS DECIMAL) DESC',
            default => 'link_id DESC',
        };

        $sql = "SELECT * FROM {$this->table} WHERE file_category = ? ORDER BY {$orderBy} LIMIT ?, ?";
        $rows = Database::query($sql, [$category, $offset, $perPage]);
        return array_map(fn($row) => BookDTO::fromArray($row), $rows);
    }

    public function countByCategory(string $category): int
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE file_category = ?";
        $row = Database::queryOne($sql, [$category]);
        return (int)($row['total'] ?? 0);
    }

    public function findByTag(string $tag, int $page = 1, int $perPage = 20, string $sort = 'new'): array
    {
        $offset = ($page - 1) * $perPage;
        
        $orderBy = match($sort) {
            'hot' => 'link_id DESC',
            'size_asc' => 'CAST(REPLACE(file_size, "MB", "") AS DECIMAL) ASC',
            'size_desc' => 'CAST(REPLACE(file_size, "MB", "") AS DECIMAL) DESC',
            default => 'link_id DESC',
        };

        // 使用 FIND_IN_SET 或 LIKE 查找标签
        $sql = "SELECT * FROM {$this->table} WHERE FIND_IN_SET(?, REPLACE(file_tag, '，', ',')) > 0 ORDER BY {$orderBy} LIMIT ?, ?";
        $rows = Database::query($sql, [$tag, $offset, $perPage]);
        return array_map(fn($row) => BookDTO::fromArray($row), $rows);
    }

    public function countByTag(string $tag): int
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE FIND_IN_SET(?, REPLACE(file_tag, '，', ',')) > 0";
        $row = Database::queryOne($sql, [$tag]);
        return (int)($row['total'] ?? 0);
    }

    public function findByFormat(string $format, int $page = 1, int $perPage = 20, string $sort = 'new'): array
    {
        $offset = ($page - 1) * $perPage;
        
        $orderBy = match($sort) {
            'hot' => 'link_id DESC',
            'size_asc' => 'CAST(REPLACE(file_size, "MB", "") AS DECIMAL) ASC',
            'size_desc' => 'CAST(REPLACE(file_size, "MB", "") AS DECIMAL) DESC',
            default => 'link_id DESC',
        };

        $sql = "SELECT * FROM {$this->table} WHERE LOWER(file_type) = LOWER(?) ORDER BY {$orderBy} LIMIT ?, ?";
        $rows = Database::query($sql, [$format, $offset, $perPage]);
        return array_map(fn($row) => BookDTO::fromArray($row), $rows);
    }

    public function countByFormat(string $format): int
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE LOWER(file_type) = LOWER(?)";
        $row = Database::queryOne($sql, [$format]);
        return (int)($row['total'] ?? 0);
    }

    public function findBySource(string $source, int $page = 1, int $perPage = 20): array
    {
        $offset = ($page - 1) * $perPage;
        $sql = "SELECT * FROM {$this->table} WHERE file_src = ? ORDER BY link_id DESC LIMIT ?, ?";
        $rows = Database::query($sql, [$source, $offset, $perPage]);
        return array_map(fn($row) => BookDTO::fromArray($row), $rows);
    }

    public function countBySource(string $source): int
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE file_src = ?";
        $row = Database::queryOne($sql, [$source]);
        return (int)($row['total'] ?? 0);
    }

    public function search(string $keyword, int $page = 1, int $perPage = 20, array $filters = []): array
    {
        $offset = ($page - 1) * $perPage;
        
        // 构建全文搜索查询
        $where = "MATCH(file_name, link_words, file_category, file_tag) AGAINST (? IN NATURAL LANGUAGE MODE)";
        $params = [$keyword];
        
        // 添加筛选条件
        if (!empty($filters['category'])) {
            $where .= " AND file_category = ?";
            $params[] = $filters['category'];
        }
        
        if (!empty($filters['format'])) {
            $where .= " AND LOWER(file_type) = LOWER(?)";
            $params[] = $filters['format'];
        }
        
        if (!empty($filters['source'])) {
            $where .= " AND file_src = ?";
            $params[] = $filters['source'];
        }
        
        if (!empty($filters['size'])) {
            $where .= " AND " . $this->buildSizeCondition($filters['size']);
        }
        
        $orderBy = $filters['sort'] === 'hot' ? 'link_id DESC' : 'link_id DESC';
        
        $sql = "SELECT * FROM {$this->table} WHERE {$where} ORDER BY {$orderBy} LIMIT ?, ?";
        $params[] = $offset;
        $params[] = $perPage;
        
        $rows = Database::query($sql, $params);
        return array_map(fn($row) => BookDTO::fromArray($row), $rows);
    }

    public function countSearch(string $keyword, array $filters = []): int
    {
        $where = "MATCH(file_name, link_words, file_category, file_tag) AGAINST (? IN NATURAL LANGUAGE MODE)";
        $params = [$keyword];
        
        if (!empty($filters['category'])) {
            $where .= " AND file_category = ?";
            $params[] = $filters['category'];
        }
        
        if (!empty($filters['format'])) {
            $where .= " AND LOWER(file_type) = LOWER(?)";
            $params[] = $filters['format'];
        }
        
        if (!empty($filters['source'])) {
            $where .= " AND file_src = ?";
            $params[] = $filters['source'];
        }
        
        if (!empty($filters['size'])) {
            $where .= " AND " . $this->buildSizeCondition($filters['size']);
        }
        
        $sql = "SELECT COUNT(*) as total FROM {$this->table} WHERE {$where}";
        $row = Database::queryOne($sql, $params);
        return (int)($row['total'] ?? 0);
    }

    private function buildSizeCondition(string $size): string
    {
        return match($size) {
            'lt10' => 'CAST(REPLACE(file_size, "MB", "") AS DECIMAL) < 10',
            '10-50' => 'CAST(REPLACE(file_size, "MB", "") AS DECIMAL) BETWEEN 10 AND 50',
            '50-100' => 'CAST(REPLACE(file_size, "MB", "") AS DECIMAL) BETWEEN 50 AND 100',
            'gt100' => 'CAST(REPLACE(file_size, "MB", "") AS DECIMAL) > 100',
            default => '1=1',
        };
    }

    public function getLatest(int $limit = 10, int $offset = 0): array
    {
        $sql = "SELECT * FROM {$this->table} ORDER BY link_id DESC LIMIT ? OFFSET ?";
        $rows = Database::query($sql, [$limit, $offset]);
        return array_map(fn($row) => BookDTO::fromArray($row), $rows);
    }

    public function countLatest(): int
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->table}";
        $row = Database::queryOne($sql);
        return (int)($row['total'] ?? 0);
    }

    public function getHot(int $limit = 10, int $days = 30): array
    {
        // 基于下载次数排序，次数相同时按最后下载时间倒序
        $sql = "SELECT * FROM {$this->table} WHERE link_download > 0 ORDER BY link_download DESC, last_download_time DESC LIMIT ?";
        $rows = Database::query($sql, [$limit]);
        
        // 如果没有下载记录，回退到按 link_id 倒序
        if (empty($rows)) {
            $sql = "SELECT * FROM {$this->table} ORDER BY link_id DESC LIMIT ?";
            $rows = Database::query($sql, [$limit]);
        }
        return array_map(fn($row) => BookDTO::fromArray($row), $rows);
    }

    public function getPopularByPeriod(int $days = 30, int $limit = 20): array
    {
        // 优先按时间范围查询
        $sql = "SELECT * FROM {$this->table} WHERE file_time >= DATE_SUB(NOW(), INTERVAL ? DAY) ORDER BY link_id DESC LIMIT ?";
        $rows = Database::query($sql, [$days, $limit]);
        
        // 如果时间范围内无数据，兜底：按 link_id 倒序取最新
        if (empty($rows)) {
            $sql = "SELECT * FROM {$this->table} ORDER BY link_id DESC LIMIT ?";
            $rows = Database::query($sql, [$limit]);
        }
        return array_map(fn($row) => BookDTO::fromArray($row), $rows);
    }

    public function getPopular24h(int $limit = 20): array
    {
        return $this->getPopularByPeriod(1, $limit);
    }

    public function getPopularWeek(int $limit = 20): array
    {
        return $this->getPopularByPeriod(7, $limit);
    }

    public function getPopularMonth(int $limit = 20): array
    {
        return $this->getPopularByPeriod(30, $limit);
    }

    public function getRelated(string $slug, int $limit = 6): array
    {
        $book = $this->findBySlug($slug);
        if (!$book) {
            return [];
        }

        // 基于分类和标签查找相关书籍
        $tags = $book->tags;
        $category = $book->category;
        
        $whereParts = ['link_slug != ?'];
        $params = [$slug];
        
        if ($category) {
            $whereParts[] = 'file_category = ?';
            $params[] = $category;
        }
        
        if (!empty($tags)) {
            $tagConditions = [];
            foreach ($tags as $tag) {
                $tagConditions[] = "FIND_IN_SET(?, REPLACE(file_tag, '，', ',')) > 0";
                $params[] = $tag;
            }
            $whereParts[] = '(' . implode(' OR ', $tagConditions) . ')';
        }
        
        $where = implode(' AND ', $whereParts);
        $sql = "SELECT * FROM {$this->table} WHERE {$where} ORDER BY link_id DESC LIMIT ?";
        $params[] = $limit;
        
        $rows = Database::query($sql, $params);
        return array_map(fn($row) => BookDTO::fromArray($row), $rows);
    }

    public function getCategories(): array
    {
        $sql = "SELECT file_category as name, COUNT(*) as count FROM {$this->table} GROUP BY file_category ORDER BY count DESC";
        return Database::query($sql);
    }

    public function getTags(int $limit = 50): array
    {
        // 从 file_tag 字段提取所有标签并统计频次
        $sql = "SELECT file_tag FROM {$this->table} WHERE file_tag != '' AND file_tag IS NOT NULL";
        $rows = Database::query($sql);
        
        $tagCounts = [];
        foreach ($rows as $row) {
            $tags = array_filter(array_map('trim', explode(',', str_replace('，', ',', $row['file_tag'] ?? ''))));
            foreach ($tags as $tag) {
                if (!empty($tag)) {
                    $tagCounts[$tag] = ($tagCounts[$tag] ?? 0) + 1;
                }
            }
        }
        
        arsort($tagCounts);
        $result = [];
        foreach (array_slice($tagCounts, 0, $limit, true) as $tag => $count) {
            $result[] = ['name' => $tag, 'count' => $count];
        }
        return $result;
    }

    public function getFormats(): array
    {
        $sql = "SELECT LOWER(file_type) as format, COUNT(*) as count FROM {$this->table} WHERE file_type != '' GROUP BY LOWER(file_type) ORDER BY count DESC";
        return Database::query($sql);
    }

    public function getSources(): array
    {
        $sql = "SELECT file_src as source, COUNT(*) as count FROM {$this->table} WHERE file_src != '' GROUP BY file_src ORDER BY count DESC";
        return Database::query($sql);
    }

    public function getStats(): array
    {
        $total = Database::queryOne("SELECT COUNT(*) as total FROM {$this->table}")['total'] ?? 0;
        $categories = Database::queryOne("SELECT COUNT(DISTINCT file_category) as total FROM {$this->table}")['total'] ?? 0;
        $formats = Database::queryOne("SELECT COUNT(DISTINCT file_type) as total FROM {$this->table}")['total'] ?? 0;
        $sources = Database::queryOne("SELECT COUNT(DISTINCT file_src) as total FROM {$this->table}")['total'] ?? 0;
        
        return [
            'total_books' => (int)$total,
            'total_categories' => (int)$categories,
            'total_formats' => (int)$formats,
            'total_sources' => (int)$sources,
        ];
    }

    public function updateHealthStatus(string $slug, string $status, int $httpCode = 0, int $responseTime = 0): bool
    {
        $sql = "UPDATE {$this->table} SET link_status = ?, last_checked = NOW() WHERE link_slug = ?";
        // 这里需要先添加 link_status 和 last_checked 字段
        // 暂时返回 true，实际实现需要数据库迁移
        return true;
    }
}