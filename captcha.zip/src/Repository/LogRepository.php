<?php

namespace App\Repository;

use App\Database;

class LogRepository
{
    private string $downloadLogTable = 'download_logs';
    private string $linkHealthTable = 'link_health';

    public function logDownload(string $slug, string $mirror, string $ip, string $userAgent, string $status = 'success'): bool
    {
        $ipHash = hash('sha256', $ip . \App\Config::jwt('secret'));
        
        $sql = "INSERT INTO {$this->downloadLogTable} (book_slug, mirror, ip_hash, user_agent, status) VALUES (?, ?, ?, ?, ?)";
        return Database::execute($sql, [$slug, $mirror, $ipHash, $userAgent, $status]) !== false;
    }

    public function getDownloadCount(string $slug, int $days = 30): int
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->downloadLogTable} WHERE book_slug = ? AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)";
        $row = Database::queryOne($sql, [$slug, $days]);
        return (int)($row['total'] ?? 0);
    }

    public function getTotalDownloads(int $days = 30): int
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->downloadLogTable} WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)";
        $row = Database::queryOne($sql, [$days]);
        return (int)($row['total'] ?? 0);
    }

    public function getHotBooks(int $limit = 10, int $days = 30): array
    {
        $sql = "SELECT book_slug, COUNT(*) as count FROM {$this->downloadLogTable} 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) 
                GROUP BY book_slug ORDER BY count DESC LIMIT ?";
        return Database::query($sql, [$days, $limit]);
    }

    public function getDailyStats(int $days = 30): array
    {
        $sql = "SELECT DATE(created_at) as date, COUNT(*) as count FROM {$this->downloadLogTable} 
                WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) 
                GROUP BY DATE(created_at) ORDER BY date DESC";
        return Database::query($sql, [$days]);
    }

    // Link Health 相关
    public function updateLinkHealth(string $slug, string $mirror, string $status, int $httpCode = 0, int $responseTime = 0): bool
    {
        $sql = "INSERT INTO {$this->linkHealthTable} (book_slug, mirror, status, http_code, response_time_ms, last_checked) 
                VALUES (?, ?, ?, ?, ?, NOW())
                ON DUPLICATE KEY UPDATE 
                status = VALUES(status), 
                http_code = VALUES(http_code), 
                response_time_ms = VALUES(response_time_ms), 
                last_checked = VALUES(last_checked)";
        return Database::execute($sql, [$slug, $mirror, $status, $httpCode, $responseTime]) !== false;
    }

    public function getLinkHealth(string $slug): ?array
    {
        $sql = "SELECT * FROM {$this->linkHealthTable} WHERE book_slug = ?";
        return Database::queryOne($sql, [$slug]);
    }

    public function getLinksToCheck(int $limit = 100): array
    {
        // 获取需要检查的链接：从未检查过，或上次检查超过 24 小时
        $sql = "SELECT al.link_slug, al.link_url, al.file_src 
                FROM all_links al
                LEFT JOIN {$this->linkHealthTable} lh ON al.link_slug = lh.book_slug
                WHERE lh.last_checked IS NULL OR lh.last_checked < DATE_SUB(NOW(), INTERVAL 24 HOUR)
                ORDER BY lh.last_checked ASC NULLS FIRST
                LIMIT ?";
        return Database::query($sql, [$limit]);
    }

    public function getHealthStats(): array
    {
        $sql = "SELECT status, COUNT(*) as count FROM {$this->linkHealthTable} GROUP BY status";
        return Database::query($sql);
    }
}