<?php

namespace App\Middleware;

class CacheControlMiddleware
{
    private array $rules = [];

    public function __construct(array $rules = [])
    {
        $this->rules = array_merge([
            '/api/' => 'public, max-age=60, stale-while-revalidate=30',
            '/assets/' => 'public, max-age=31536000, immutable',
            '/sitemap.xml' => 'public, max-age=3600',
            '/robots.txt' => 'public, max-age=86400',
            '/' => 'public, max-age=60, stale-while-revalidate=30',
        ], $rules);
    }

    public function handle(array &$params): ?\App\Http\Response
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        
        foreach ($this->rules as $pattern => $cacheControl) {
            if ($this->matchPattern($uri, $pattern)) {
                header("Cache-Control: {$cacheControl}");
                break;
            }
        }

        return null;
    }

    private function matchPattern(string $uri, string $pattern): bool
    {
        if ($pattern === '/') {
            return $uri === '/' || $uri === '/index.php';
        }
        
        if (str_ends_with($pattern, '/')) {
            return str_starts_with($uri, $pattern);
        }
        
        return $uri === $pattern || str_starts_with($uri, $pattern . '/');
    }
}