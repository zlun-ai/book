<?php

namespace App\Middleware;

use App\Config;

class SecurityHeadersMiddleware
{
    public function handle(array &$params): ?\App\Http\Response
    {
        $csp = Config::security('csp');
        $hstsMaxAge = Config::security('hsts_max_age', 31536000);
        $referrerPolicy = Config::security('referrer_policy', 'strict-origin-when-cross-origin');

        // 这些头会在响应发送时自动添加
        // 这里只是定义，实际应用需要在响应发送前调用
        
        return null;
    }

    public static function applyHeaders(): void
    {
        $csp = Config::security('csp');
        $hstsMaxAge = Config::security('hsts_max_age', 31536000);
        $referrerPolicy = Config::security('referrer_policy', 'strict-origin-when-cross-origin');

        if ($csp) {
            header("Content-Security-Policy: {$csp}");
        }

        // HSTS 仅在 HTTPS 下发送
        if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
            header("Strict-Transport-Security: max-age={$hstsMaxAge}; includeSubDomains; preload");
        }

        header("X-Content-Type-Options: nosniff");
        header("X-Frame-Options: DENY");
        header("X-XSS-Protection: 1; mode=block");
        header("Referrer-Policy: {$referrerPolicy}");
        header("Permissions-Policy: geolocation=(), microphone=(), camera=()");
    }
}