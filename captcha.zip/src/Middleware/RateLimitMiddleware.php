<?php

namespace App\Middleware;

use App\Cache;

class RateLimitMiddleware
{
    private int $maxRequests;
    private int $windowSeconds;
    private string $prefix;

    public function __construct(int $maxRequests = 60, int $windowSeconds = 60, string $prefix = 'ratelimit')
    {
        $this->maxRequests = $maxRequests;
        $this->windowSeconds = $windowSeconds;
        $this->prefix = $prefix;
    }

    public function handle(array &$params): ?\App\Http\Response
    {
        if (!Cache::isEnabled()) {
            return null;
        }

        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $key = "{$this->prefix}:{$ip}";
        
        $current = Cache::increment($key);
        
        if ($current === 1) {
            // 第一次请求，设置过期时间
            // 这里无法直接设置过期，需要用 setex，但我们用 increment 后手动 expire
            // 简单处理：用一个单独的 key 记录时间窗口
        }
        
        // 检查是否超限
        if ($current > $this->maxRequests) {
            // 获取剩余时间
            $ttl = $this->windowSeconds;
            
            return \App\Http\Response::error(
                '请求过于频繁，请稍后再试',
                429,
                ['retry_after' => $ttl]
            )->withHeader('Retry-After', (string)$ttl)
              ->withHeader('X-RateLimit-Limit', (string)$this->maxRequests)
              ->withHeader('X-RateLimit-Remaining', '0')
              ->withHeader('X-RateLimit-Reset', (string)(time() + $ttl));
        }

        // 添加限流头
        // 注意：这里无法直接修改响应头，需要在控制器中处理
        // 或者使用全局中间件栈
        
        return null;
    }
}