<?php

namespace App;

class Cache
{
    private static string $cacheDir = '';
    private static bool $enabled = true;
    private static array $memoryCache = [];

    public static function configure(array $config): void
    {
        self::$cacheDir = $config['cache_dir'] ?? sys_get_temp_dir() . '/yunlio_cache';
        self::$enabled = $config['enabled'] ?? true;
        
        if (self::$enabled && !is_dir(self::$cacheDir)) {
            @mkdir(self::$cacheDir, 0755, true);
        }
    }

    private static string $prefix = 'yunlio:';

    private static function key(string $key): string
    {
        return self::$prefix . $key;
    }

    private static function filePath(string $key): string
    {
        $safeKey = preg_replace('/[^a-zA-Z0-9_:.-]/', '_', self::key($key));
        return self::$cacheDir . '/' . $safeKey . '.cache';
    }

    public static function isEnabled(): bool
    {
        return self::$enabled;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        if (!self::$enabled) {
            return $default;
        }

        // 内存缓存
        if (isset(self::$memoryCache[$key])) {
            $entry = self::$memoryCache[$key];
            if ($entry['expire'] === 0 || $entry['expire'] > time()) {
                return $entry['value'];
            }
            unset(self::$memoryCache[$key]);
        }

        // 文件缓存
        $file = self::filePath($key);
        if (file_exists($file)) {
            $content = @file_get_contents($file);
            if ($content !== false) {
                $data = @unserialize($content);
                if ($data !== false && ($data['expire'] === 0 || $data['expire'] > time())) {
                    self::$memoryCache[$key] = ['value' => $data['value'], 'expire' => $data['expire']];
                    return $data['value'];
                }
                @unlink($file);
            }
        }

        return $default;
    }

    public static function set(string $key, mixed $value, int $ttl = 0): bool
    {
        if (!self::$enabled) {
            return false;
        }

        $expire = $ttl > 0 ? time() + $ttl : 0;
        $entry = ['value' => $value, 'expire' => $expire];

        // 写入内存缓存
        self::$memoryCache[$key] = $entry;

        // 写入文件缓存
        $file = self::filePath($key);
        $dir = dirname($file);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        return @file_put_contents($file, serialize($entry), LOCK_EX) !== false;
    }

    public static function delete(string $key): bool
    {
        if (!self::$enabled) {
            return false;
        }

        unset(self::$memoryCache[$key]);

        $file = self::filePath($key);
        return file_exists($file) && @unlink($file);
    }

    public static function exists(string $key): bool
    {
        if (!self::$enabled) {
            return false;
        }

        if (isset(self::$memoryCache[$key])) {
            $entry = self::$memoryCache[$key];
            if ($entry['expire'] === 0 || $entry['expire'] > time()) {
                return true;
            }
            unset(self::$memoryCache[$key]);
        }

        $file = self::filePath($key);
        if (file_exists($file)) {
            $content = @file_get_contents($file);
            if ($content !== false) {
                $data = @unserialize($content);
                if ($data !== false && ($data['expire'] === 0 || $data['expire'] > time())) {
                    return true;
                }
                @unlink($file);
            }
        }
        return false;
    }

    public static function remember(string $key, int $ttl, callable $callback): mixed
    {
        $cached = self::get($key);
        if ($cached !== null) {
            return $cached;
        }

        $value = $callback();
        self::set($key, $value, $ttl);
        return $value;
    }

    public static function flush(): bool
    {
        if (!self::$enabled) {
            return false;
        }

        self::$memoryCache = [];

        // 删除文件缓存目录下所有文件
        $files = glob(self::$cacheDir . '/*.cache');
        foreach ($files as $file) {
            @unlink($file);
        }
        return true;
    }

    public static function increment(string $key, int $value = 1): int
    {
        if (!self::$enabled) {
            return 0;
        }

        // 文件/内存缓存不支持原子增量，简单实现
        $current = self::get($key, 0);
        $new = $current + $value;
        self::set($key, $new, 3600);
        return $new;
    }

    // 清理过期文件缓存（建议在 cron 中调用）
    public static function gc(int $maxAge = 86400): int
    {
        $files = glob(self::$cacheDir . '/*.cache');
        $deleted = 0;
        $now = time();
        
        foreach ($files as $file) {
            if ($now - filemtime($file) > $maxAge) {
                @unlink($file);
                $deleted++;
            }
        }
        return $deleted;
    }
}