<?php

namespace App\Controller\Api;

use App\Service\SearchService;
use App\Http\Response;
use App\Http\Request;
use App\Config;

class SearchController
{
    private SearchService $searchService;

    public function __construct()
    {
        $this->searchService = new SearchService();
    }

    public function search(array $params): Response
    {
        $request = new Request();
        $keyword = $request->query('q', '');
        
        if (empty($keyword)) {
            return Response::error('Missing query parameter "q"', 400);
        }

        $page = max(1, (int)$request->query('page', 1));
        $perPage = min(max(1, (int)$request->query('per_page', 20)), Config::pagination('max_per_page', 100));
        
        $filters = [];
        if ($category = $request->query('category')) {
            $filters['category'] = $category;
        }
        if ($format = $request->query('format')) {
            $filters['format'] = $format;
        }
        if ($source = $request->query('source')) {
            $filters['source'] = $source;
        }
        if ($size = $request->query('size')) {
            $filters['size'] = $size;
        }
        if ($sort = $request->query('sort')) {
            $filters['sort'] = $sort;
        }

        $result = $this->searchService->search($keyword, $page, $perPage, $filters);
        
        $data = $result->toArray();
        $data['meta']['links'] = $result->getPaginationLinks();
        
        return Response::json($data);
    }

    public function suggest(array $params): Response
    {
        $request = new Request();
        $keyword = $request->query('q', '');
        $limit = min(max(1, (int)$request->query('limit', 10)), 20);
        
        if (mb_strlen($keyword) < 2) {
            return Response::success([]);
        }

        $suggestions = $this->searchService->getSuggestions($keyword, $limit);
        
        return Response::success($suggestions);
    }
}