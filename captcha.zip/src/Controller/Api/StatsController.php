<?php

namespace App\Controller\Api;

use App\Service\BookService;
use App\Http\Response;

class StatsController
{
    private BookService $bookService;

    public function __construct()
    {
        $this->bookService = new BookService();
    }

    public function overview(array $params): Response
    {
        $stats = $this->bookService->getStats();
        return Response::success($stats);
    }
}