<?php

namespace App\Controller\Api;

use App\Service\BookService;
use App\Http\Response;
use App\Http\Request;
use App\Config;

class BooksController
{
    private BookService $bookService;

    public function __construct()
    {
        $this->bookService = new BookService();
    }

    public function latest(array $params): Response
    {
        $limit = min((int)($_GET['limit'] ?? 10), 50);
        $books = $this->bookService->getLatest($limit);
        
        return Response::success(array_map(fn($b) => $b->toArray(), $books));
    }

    public function hot(array $params): Response
    {
        $limit = min((int)($_GET['limit'] ?? 10), 50);
        $days = min((int)($_GET['days'] ?? 30), 365);
        $books = $this->bookService->getHot($limit, $days);
        
        return Response::success(array_map(fn($b) => $b->toArray(), $books));
    }

    public function show(array $params): Response
    {
        $slug = $params['slug'] ?? '';
        if (empty($slug)) {
            return Response::error('Missing slug', 400);
        }

        $book = $this->bookService->getBook($slug);
        if (!$book) {
            return Response::error('Book not found', 404);
        }

        return Response::success($book->toArray());
    }

    public function related(array $params): Response
    {
        $slug = $params['slug'] ?? '';
        if (empty($slug)) {
            return Response::error('Missing slug', 400);
        }

        $limit = min((int)($_GET['limit'] ?? 6), 20);
        $books = $this->bookService->getRelated($slug, $limit);
        
        return Response::success(array_map(fn($b) => $b->toArray(), $books));
    }

    public function categories(array $params): Response
    {
        $categories = $this->bookService->getCategories();
        return Response::success($categories);
    }

    public function tags(array $params): Response
    {
        $limit = min((int)($_GET['limit'] ?? 50), 100);
        $tags = $this->bookService->getTags($limit);
        return Response::success($tags);
    }

    public function formats(array $params): Response
    {
        $formats = $this->bookService->getFormats();
        return Response::success($formats);
    }

    public function sources(array $params): Response
    {
        $sources = $this->bookService->getSources();
        return Response::success($sources);
    }
}