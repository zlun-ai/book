<?php

namespace App\Controller\Api;

use App\Service\BookService;
use App\Service\DownloadService;
use App\Http\Response;
use App\Http\Request;
use App\Config;

class DownloadController
{
    private BookService $bookService;
    private DownloadService $downloadService;

    public function __construct()
    {
        $this->bookService = new BookService();
        $this->downloadService = new DownloadService();
    }

    public function getToken(array $params): Response
    {
        $slug = $params['slug'] ?? '';
        if (empty($slug)) {
            return Response::error('Missing slug', 400);
        }

        $downloadInfo = $this->downloadService->generateDownloadToken($slug);
        if (!$downloadInfo) {
            return Response::error('Book not found or no download link', 404);
        }

        // 记录下载统计
        $this->bookService->recordDownload($slug, $downloadInfo['source'] ?? 'default');

        return Response::success($downloadInfo);
    }

    public function redirect(array $params): Response
    {
        $request = new Request();
        $token = $request->query('token', '');
        
        if (empty($token)) {
            return Response::error('Missing token', 400);
        }

        $url = $this->downloadService->validateAndRedirect($token);
        if (!$url) {
            return Response::error('Invalid or expired download token', 410);
        }

        // 302 重定向到真实下载链接
        return Response::redirect($url, 302);
    }

    public function checkHealth(array $params): Response
    {
        $slug = $params['slug'] ?? '';
        if (empty($slug)) {
            return Response::error('Missing slug', 400);
        }

        $health = $this->downloadService->checkLinkHealth($slug);
        
        return Response::success($health);
    }
}