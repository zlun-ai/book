<?php

namespace App\Controller\View;

use App\Service\BookService;
use App\Http\Response;
use App\Http\Request;
use App\Config;

class CategoryController
{
    private BookService $bookService;

    public function __construct()
    {
        $this->bookService = new BookService();
    }

    public function show(array $params): Response
    {
        $slug = $params['slug'] ?? '';
        $page = max(1, (int)($params['page'] ?? 1));
        
        if (empty($slug)) {
            return Response::error('Missing category', 404)->withStatus(404);
        }

        // URL 解码分类名（支持中文）
        $category = urldecode($slug);
        
        $perPage = 20;
        $sort = $_GET['sort'] ?? 'new';
        
        $books = $this->bookService->getBooksByCategory($category, $page, $perPage, $sort);
        $total = $this->bookService->countBooksByCategory($category);
        $lastPage = (int)ceil($total / $perPage);
        
        $categories = $this->bookService->getCategories();
        $stats = $this->bookService->getStats();

        // 面包屑
        $breadcrumbs = [
            ['name' => '首页', 'url' => Config::url('/')],
            ['name' => $category, 'url' => ''],
        ];

        return Response::view('category', [
            'siteName' => Config::app('name', 'YunLio'),
            'siteDesc' => Config::app('description', '免费下载epub、mobi、azw3、pdf、txt等格式电子书！'),
            'stats' => $stats,
            'category' => $category,
            'books' => array_map(fn($b) => $b->toArray(), $books),
            'categories' => $categories,
            'currentPage' => $page,
            'lastPage' => $lastPage,
            'total' => $total,
            'perPage' => $perPage,
            'sort' => $sort,
            'filters' => ['sort' => $sort],
            'breadcrumbs' => $breadcrumbs,
            'pageTitle' => $category . ' - 免费电子书下载 | ' . Config::app('name'),
            'pageDescription' => "收录 {$category} 类电子书 {$total} 本，提供 PDF/EPUB/MOBI/TXT 多格式免费下载。",
            'canonicalUrl' => Config::url("/category/{$slug}/"),
            'prevUrl' => $page > 1 ? Config::url("/category/{$slug}/page/" . ($page - 1) . "/") : null,
            'nextUrl' => $page < $lastPage ? Config::url("/category/{$slug}/page/" . ($page + 1) . "/") : null,
        ]);
    }
}