<?php

namespace App\Controller\View;

use App\Http\Response;
use App\Config;

class StaticController
{
    public function about(array $params): Response
    {
        return Response::view('static/about', [
            'siteName' => Config::app('name', 'YunLio'),
            'siteDesc' => Config::app('description', ''),
            'pageTitle' => '关于我们 | ' . Config::app('name'),
            'pageDescription' => '了解 YunLio 电子书下载站的使命、数据来源和免责声明。',
            'canonicalUrl' => Config::url('/about/'),
        ]);
    }

    public function dmca(array $params): Response
    {
        return Response::view('static/dmca', [
            'siteName' => Config::app('name', 'YunLio'),
            'pageTitle' => '版权声明 (DMCA) | ' . Config::app('name'),
            'pageDescription' => 'YunLio 遵守 DMCA 版权保护法案，提供版权投诉和下架流程。',
            'canonicalUrl' => Config::url('/dmca/'),
        ]);
    }

    public function contact(array $params): Response
    {
        return Response::view('static/contact', [
            'siteName' => Config::app('name', 'YunLio'),
            'pageTitle' => '联系我们 | ' . Config::app('name'),
            'pageDescription' => '联系 YunLio 团队，反馈问题、建议合作或提交版权投诉。',
            'canonicalUrl' => Config::url('/contact/'),
        ]);
    }

    public function sitemap(array $params): Response
    {
        // 生成 XML Sitemap
        header('Content-Type: application/xml; charset=utf-8');
        
        $bookService = new \App\Service\BookService();
        $latestBooks = $bookService->getLatest(5000);
        $categories = $bookService->getCategories();
        $tags = $bookService->getTags(1000);
        
        $urls = [];
        $now = date('c');
        
        // 首页
        $urls[] = [
            'loc' => Config::url('/'),
            'lastmod' => $now,
            'changefreq' => 'daily',
            'priority' => '1.0',
        ];
        
        // 分类页
        foreach ($categories as $cat) {
            $urls[] = [
                'loc' => Config::url("/category/" . urlencode($cat['name']) . "/"),
                'lastmod' => $now,
                'changefreq' => 'daily',
                'priority' => '0.8',
            ];
        }
        
        // 标签页
        foreach ($tags as $tag) {
            $urls[] = [
                'loc' => Config::url("/tag/" . urlencode($tag['name']) . "/"),
                'lastmod' => $now,
                'changefreq' => 'weekly',
                'priority' => '0.6',
            ];
        }
        
        // 详情页
        foreach ($latestBooks as $book) {
            $urls[] = [
                'loc' => $book->getCanonicalUrl(),
                'lastmod' => $book->getIsoDate(),
                'changefreq' => 'monthly',
                'priority' => '0.5',
            ];
        }
        
        // 静态页
        $staticPages = ['/about/', '/dmca/', '/contact/'];
        foreach ($staticPages as $page) {
            $urls[] = [
                'loc' => Config::url($page),
                'lastmod' => $now,
                'changefreq' => 'monthly',
                'priority' => '0.3',
            ];
        }
        
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        
        foreach ($urls as $url) {
            echo "  <url>\n";
            echo "    <loc>" . htmlspecialchars($url['loc']) . "</loc>\n";
            echo "    <lastmod>{$url['lastmod']}</lastmod>\n";
            echo "    <changefreq>{$url['changefreq']}</changefreq>\n";
            echo "    <priority>{$url['priority']}</priority>\n";
            echo "  </url>\n";
        }
        
        echo '</urlset>';
        exit;
    }

    public function robots(array $params): Response
    {
        $content = "User-agent: *\n";
        $content .= "Allow: /\n";
        $content .= "Disallow: /api/\n";
        $content .= "Disallow: /cron/\n";
        $content .= "Disallow: /src/\n";
        $content .= "Disallow: /config/\n";
        $content .= "Disallow: /vendor/\n";
        $content .= "Disallow: /storage/\n";
        $content .= "Disallow: /*.php$\n";
        $content .= "Sitemap: " . Config::url('/sitemap.xml') . "\n";
        
        return Response::make($content, 200, [
            'Content-Type' => 'text/plain; charset=utf-8',
        ]);
    }
}