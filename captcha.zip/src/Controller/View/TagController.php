<?php

namespace App\Controller\View;

use App\Service\BookService;
use App\Http\Response;
use App\Config;

class TagController
{
    private BookService $bookService;

    public function __construct()
    {
        $this->bookService = new BookService();
    }

    public function show(array $params): Response
    {
        $slug = $params['slug'] ?? '';
        $page = max(1, (int)($params['page'] ?? 1));
        
        if (empty($slug)) {
            return Response::error('Missing tag', 404)->withStatus(404);
        }

        $tag = urldecode($slug);
        $perPage = 20;
        $sort = $_GET['sort'] ?? 'new';
        
        $books = $this->bookService->getBooksByTag($tag, $page, $perPage, $sort);
        $total = $this->bookService->countBooksByTag($tag);
        $lastPage = (int)ceil($total / $perPage);
        
        // 转为数组供模板和 getFormatSummary 使用
        $booksArray = array_map(fn($b) => $b->toArray(), $books);
        
        // 获取相关标签（共现分析简化版）
        $relatedTags = $this->getRelatedTags($tag);
        
        // 面包屑
        $breadcrumbs = [
            ['name' => '首页', 'url' => Config::url('/')],
            ['name' => '标签', 'url' => Config::url('/tags/')],
            ['name' => $tag, 'url' => ''],
        ];

        return Response::view('tag', [
            'siteName' => Config::app('name', 'YunLio'),
            'siteDesc' => Config::app('description', '免费下载epub、mobi、azw3、pdf、txt等格式电子书！'),
            'tag' => $tag,
            'books' => $booksArray,
            'relatedTags' => $relatedTags,
            'categories' => $this->bookService->getCategories(),
            'tags' => $this->bookService->getTags(30),
            'stats' => $this->bookService->getStats(),
            'currentPage' => $page,
            'lastPage' => $lastPage,
            'total' => $total,
            'perPage' => $perPage,
            'sort' => $sort,
            'breadcrumbs' => $breadcrumbs,
            'pageTitle' => $tag . ' - 标签聚合 | ' . Config::app('name'),
            'pageDescription' => "标签 \"{$tag}\" 收录 {$total} 本电子书，主要格式包含 " . $this->getFormatSummary($booksArray) . "。",
            'canonicalUrl' => Config::url("/tag/{$slug}/"),
            'prevUrl' => $page > 1 ? Config::url("/tag/{$slug}/page/" . ($page - 1) . "/") : null,
            'nextUrl' => $page < $lastPage ? Config::url("/tag/{$slug}/page/" . ($page + 1) . "/") : null,
        ]);
    }

    private function getRelatedTags(string $tag): array
    {
        // 简化：返回热门标签中排除当前标签的前 10 个
        $allTags = $this->bookService->getTags(20);
        return array_filter($allTags, fn($t) => $t['name'] !== $tag);
    }

    private function getFormatSummary(array $books): string
    {
        $formats = [];
        foreach ($books as $book) {
            // 支持数组和 BookDTO 对象
            $format = $book['format'] ?? ($book->format ?? '');
            if (!empty($format)) {
                $formats[$format] = ($formats[$format] ?? 0) + 1;
            }
        }
        arsort($formats);
        $topFormats = array_slice($formats, 0, 3, true);
        $result = [];
        foreach ($topFormats as $fmt => $count) {
            $result[] = strtoupper($fmt) . "({$count})";
        }
        return implode('、', $result);
    }
}