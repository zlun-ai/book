<?php

namespace App\Controller\View;

use App\Service\SearchService;
use App\Service\BookService;
use App\Http\Response;
use App\Http\Request;
use App\Config;

class SearchController
{
    private SearchService $searchService;
    private BookService $bookService;

    public function __construct()
    {
        $this->searchService = new SearchService();
        $this->bookService = new BookService();
    }

    public function show(array $params): Response
    {
        $request = new Request();
        $keyword = $request->query('q', '');
        $page = max(1, (int)$request->query('page', 1));
        
        $hotTags = $this->bookService->getTags(20);

        $result = null;
        $correctedKeyword = null;
        
        if (!empty($keyword)) {
            $perPage = 20;
            $filters = [];
            if ($sort = $request->query('sort')) {
                $filters['sort'] = $sort;
            }

            $result = $this->searchService->search($keyword, $page, $perPage, $filters);
            
            // 拼写纠错
            $corrected = $this->searchService->correctSpelling($keyword);
            if ($corrected && $corrected !== $keyword) {
                $correctedKeyword = $corrected;
            }
        }

        // 面包屑
        $breadcrumbs = [
            ['name' => '首页', 'url' => Config::url('/')],
            ['name' => '搜索', 'url' => ''],
        ];

        return Response::view('search', [
            'siteName' => Config::app('name', 'YunLio'),
            'siteDesc' => Config::app('description', '免费下载epub、mobi、azw3、pdf、txt等格式电子书！'),
            'keyword' => $keyword,
            'correctedKeyword' => $correctedKeyword,
            'result' => $result,
            'categories' => $this->bookService->getCategories(),
            'tags' => $this->bookService->getTags(30),
            'formats' => $this->bookService->getFormats(),
            'sources' => $this->bookService->getSources(),
            'stats' => $this->bookService->getStats(),
            'hotTags' => $hotTags,
            'currentPage' => $page,
            'breadcrumbs' => $breadcrumbs,
            'pageTitle' => ($keyword ? "「{$keyword}」搜索结果" : '搜索') . ' | ' . Config::app('name'),
            'pageDescription' => $keyword 
                ? "搜索「{$keyword}」" . ($result ? "，找到 {$result->total} 本相关电子书" : '，未找到相关结果') 
                : '电子书搜索 - 支持书名、作者、标签、分类全文检索',
            'canonicalUrl' => $keyword ? Config::url('/search/?q=' . urlencode($keyword)) : Config::url('/search/'),
        ]);
    }
}