<?php

namespace App\Controller\View;

use App\Service\BookService;
use App\Service\SearchService;
use App\Http\Response;
use App\Http\Request;
use App\Config;

class HomeController
{
    private BookService $bookService;
    private SearchService $searchService;

    public function __construct()
    {
        $this->bookService = new BookService();
        $this->searchService = new SearchService();
    }

    public function index(array $params): Response
    {
        $popular24h = $this->bookService->getPopular24h(20);
        $popularWeek = $this->bookService->getPopularWeek(20);
        $popularMonth = $this->bookService->getPopularMonth(20);
        $hotBooks = $this->bookService->getHot(20);
        
        $categories = $this->bookService->getCategories();
        $tags = $this->bookService->getTags(30);
        $formats = $this->bookService->getFormats();
        $stats = $this->bookService->getStats();

        return Response::view('home', [
            'siteName' => Config::app('name', 'YunLio'),
            'siteDesc' => Config::app('description', '免费下载epub、mobi、azw3、pdf、txt等格式电子书！'),
            'popular24h' => array_map(fn($b) => $b->toArray(), $popular24h),
            'popularWeek' => array_map(fn($b) => $b->toArray(), $popularWeek),
            'popularMonth' => array_map(fn($b) => $b->toArray(), $popularMonth),
            'hotBooks' => array_map(fn($b) => $b->toArray(), $hotBooks),
            'categories' => $categories,
            'tags' => $tags,
            'formats' => $formats,
            'stats' => $stats,
            'pageTitle' => Config::app('name') . ' | ' . Config::app('description'),
            'pageDescription' => Config::app('description') . ' 收录 ' . $stats['total_books'] . ' 本电子书，提供 PDF/EPUB/MOBI/TXT 等多格式免费下载。',
            'canonicalUrl' => Config::url('/'),
        ]);
    }
}