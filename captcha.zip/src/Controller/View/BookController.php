<?php

namespace App\Controller\View;

use App\Service\BookService;
use App\Http\Response;
use App\Config;

class BookController
{
    private BookService $bookService;

    public function __construct()
    {
        $this->bookService = new BookService();
    }

    public function show(array $params): Response
    {
        $slug = $params['slug'] ?? '';
        
        if (empty($slug)) {
            return Response::error('Missing slug', 404)->withStatus(404);
        }

        $book = $this->bookService->getBook($slug);
        if (!$book) {
            return Response::error('Book not found', 404)->withStatus(404);
        }

        $relatedBooks = $this->bookService->getRelated($slug, 6);
        $categories = $this->bookService->getCategories();

        // 面包屑
        $breadcrumbs = [
            ['name' => '首页', 'url' => Config::url('/')],
            ['name' => $book->category, 'url' => $book->getCategoryUrl()],
            ['name' => $book->title, 'url' => ''],
        ];

        $structuredData = $book->getStructuredData();
        $structuredData['offers']['url'] = Config::url("/api/download/{$slug}");

        return Response::view('book', [
            'siteName' => Config::app('name', 'YunLio'),
            'book' => $book->toArray(),
            'relatedBooks' => array_map(fn($b) => $b->toArray(), $relatedBooks),
            'categories' => $categories,
            'breadcrumbs' => $breadcrumbs,
            'structuredData' => json_encode($structuredData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'pageTitle' => "《{$book->title}》{$book->getFormatDisplay()}免费下载 - {$book->category} | " . Config::app('name'),
            'pageDescription' => "《{$book->title}》{$book->getFormatDisplay()}版免费下载，大小{$book->getSizeDisplay()}，{$book->source}高速下载" . ($book->extractCode ? "，提取码: {$book->extractCode}" : '') . ($book->excerpt ? "。" . mb_substr($book->excerpt, 0, 120) . '...' : ''),
            'canonicalUrl' => $book->getCanonicalUrl(),
            'ogImage' => $book->hasExtractCode() ? Config::asset("images/{$book->format}.jpg") : Config::asset('images/default.jpg'),
        ]);
    }
}