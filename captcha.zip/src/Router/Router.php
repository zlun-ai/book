<?php

namespace App\Router;

class Route
{
    public string $method;
    public string $pattern;
    /** @var callable|array|string */
    public $handler;
    public array $middleware = [];
    public string $name = '';

    public function __construct(string $method, string $pattern, $handler, array $middleware = [], string $name = '')
    {
        $this->method = strtoupper($method);
        $this->pattern = $pattern;
        $this->handler = $handler;
        $this->middleware = $middleware;
        $this->name = $name;
    }

    public function matches(string $method, string $uri): ?array
    {
        if ($this->method !== 'ANY' && $this->method !== strtoupper($method)) {
            return null;
        }

        $pattern = $this->pattern;
        $pattern = preg_replace('/\{([a-zA-Z_][a-zA-Z0-9_-]*)\}/', '(?P<$1>[^/]+)', $pattern);
        $pattern = '#^' . $pattern . '$#';

        if (preg_match($pattern, $uri, $matches)) {
            $params = [];
            foreach ($matches as $key => $value) {
                if (!is_int($key)) {
                    $params[$key] = $value;
                }
            }
            return $params;
        }

        return null;
    }
}

class Router
{
    private array $routes = [];
    private array $middleware = [];
    private array $namedRoutes = [];

    public function get(string $pattern, callable|array|string $handler, array $middleware = [], string $name = ''): self
    {
        return $this->add('GET', $pattern, $handler, $middleware, $name);
    }

    public function post(string $pattern, callable|array|string $handler, array $middleware = [], string $name = ''): self
    {
        return $this->add('POST', $pattern, $handler, $middleware, $name);
    }

    public function any(string $pattern, callable|array|string $handler, array $middleware = [], string $name = ''): self
    {
        return $this->add('ANY', $pattern, $handler, $middleware, $name);
    }

    public function group(array $middleware, callable $callback): self
    {
        $prevMiddleware = $this->middleware;
        $this->middleware = array_merge($this->middleware, $middleware);
        $callback($this);
        $this->middleware = $prevMiddleware;
        return $this;
    }

    private function add(string $method, string $pattern, callable|array|string $handler, array $middleware, string $name): self
    {
        $route = new Route($method, $pattern, $handler, array_merge($this->middleware, $middleware), $name);
        $this->routes[] = $route;
        
        if ($name) {
            $this->namedRoutes[$name] = $route;
        }
        
        return $this;
    }

    public function dispatch(string $method, string $uri): mixed
    {
        $method = strtoupper($method);
        
        foreach ($this->routes as $route) {
            $params = $route->matches($method, $uri);
            if ($params !== null) {
                return $this->executeRoute($route, $params);
            }
        }

        // 404 Not Found
        http_response_code(404);
        return $this->render404();
    }

    private function executeRoute(Route $route, array $params): mixed
    {
        // 执行中间件
        foreach ($route->middleware as $middleware) {
            $result = $this->executeMiddleware($middleware, $params);
            if ($result !== null) {
                return $result;
            }
        }

        // 执行处理器
        $handler = $route->handler;
        
        if (is_string($handler)) {
            // 控制器@方法 格式
            if (strpos($handler, '@') !== false) {
                [$controllerClass, $method] = explode('@', $handler);
                $controller = new $controllerClass();
                return $controller->$method($params);
            }
            // 类名，调用 __invoke
            $handler = new $handler();
        }

        if (is_array($handler)) {
            // [类名, 方法名] 或 [实例, 方法名]
            [$controller, $method] = $handler;
            if (is_string($controller)) {
                $controller = new $controller();
            }
            return $controller->$method($params);
        }

        if (is_callable($handler)) {
            return $handler($params);
        }

        throw new \RuntimeException('Invalid route handler');
    }

    private function executeMiddleware(string|array $middleware, array &$params): mixed
    {
        if (is_string($middleware)) {
            $middlewareClass = $middleware;
            $middleware = new $middlewareClass();
        }

        if (is_array($middleware)) {
            [$middlewareClass, $method] = $middleware;
            if (is_string($middlewareClass)) {
                $middlewareClass = new $middlewareClass();
            }
            return $middlewareClass->$method($params);
        }

        if ($middleware instanceof \Closure) {
            return $middleware($params);
        }

        if (method_exists($middleware, 'handle')) {
            return $middleware->handle($params);
        }

        return null;
    }

    private function render404(): void
    {
        $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
        if (strpos($accept, 'application/json') !== false || strpos($_SERVER['REQUEST_URI'] ?? '', '/api/') === 0) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'code' => 404,
                'message' => 'Not Found',
                'data' => null,
            ], JSON_UNESCAPED_UNICODE);
        } else {
            // 渲染 404 页面
            $viewPath = __DIR__ . '/../../view/404.php';
            if (file_exists($viewPath)) {
                include $viewPath;
            } else {
                echo '<h1>404 - Page Not Found</h1>';
            }
        }
    }

    public function url(string $name, array $params = []): string
    {
        if (!isset($this->namedRoutes[$name])) {
            return '';
        }

        $route = $this->namedRoutes[$name];
        $url = $route->pattern;
        
        foreach ($params as $key => $value) {
            $url = str_replace('{' . $key . '}', $value, $url);
        }
        
        return $url;
    }

    public function getRoutes(): array
    {
        return $this->routes;
    }
}