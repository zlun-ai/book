<?php
include "config.php";
include "fun.php";
?>
<?php
$q = get_param("keyword");
//$q = base64_decode($q);
//echo $q;
$safe_q = get_safe_search($q);
$res = get_search($q);
if(count($res)<1){
	$res = get_search($q, $num=30, $type="wordpress");
}
foreach ($res as $p){
?>
<div class="xe-card col-sm-6 ">
						
                        <div class="xe-widget xe-conversations box2 label-info">
						
                <div class="xe-comment-entry">
                    <div class="xe-user-img">
                                                <img class="img-circle lazy" src="<?php echo HOME_URL.'/template/images/pdf.png';?>" onerror="" width="40">
                                            </div>
                    <div class="xe-comment">
						<div><a class="btn-cat" href="<?php echo HOME_URL.'/category/'.urlencode($p->post_category).'.html';?>"><?php echo htmlspecialchars($p->post_category);?></a>
						</div>
                        <div class="xe-user-name overflowClip_1 method_icon_name">
                            <strong><a href="<?php echo HOME_URL.'/file/'.$p->post_slug.'.html';?>"><?php echo htmlspecialchars($p->post_title);?></a></strong>
                        </div>
						
                        <div  style="clear:both;"></div>
                        <p class="overflowClip_2">大小：<?php echo $p->post_filesize;?> · 格式：<?php echo strtoupper($p->post_format); ?></p>
					
                    </div>
                </div>
            </div>
            
            </div>
<?php
}
?>