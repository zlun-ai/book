function performCustomSearch() {
	
	var keyword = $('#search-text').val().trim();
    if (keyword === '') return;
    //alert(keyword);
    //$('#loading').show();
    //$('#search-results').html('');
    
    // 调用自定义API端点
    var apiUrl = domain+'/process-search.php';
	
	var request = $.ajax({
		url: apiUrl,
		method: "POST",
		data: {
            keyword: keyword,
            per_page: 30,
            page: 1
        },
        dataType: 'text'
	});
    request.done(function(response, status, xhr) {
	console.log("XHR状态:", status);
    console.log("HTTP状态码:", xhr.status);
    console.log("完整响应:", response);
    
    // 检查HTTP状态码（重要！）
    if (xhr.status !== 200) {
        //alert("服务器返回错误状态: " + xhr.status);
        return;
    }
    
    // 不要直接假设response.data存在
    // 先检查整个响应结构
    if (!response) {
        $('#search_result_box_loading').html('<div class="nothing" id="search_info">抱歉，未查询到任何图书文件，请修改搜索关键词后重试！</div>');
        return;
    }
	$('#search_result_box_loading').hide();
    $('#search_result_box').html(response);
	$('#search_result_box').show();
    // 尝试多种可能的响应结构
    
    });
    request.fail(function(jqXHR, textStatus, errorThrown) {
	$('#search_result_box_loading').html('<div class="nothing" id="search_info">抱歉，未查询到任何图书文件，请修改搜索关键词后重试！</div>');
    });
}// JavaScript Document

function loading_related(keyword, slug) {
	
	//var keyword = $('#search-text').val().trim();
    if (keyword === '') return;
    //alert(keyword);
    //$('#loading').show();
    //$('#search-results').html('');
    
    // 调用自定义API端点
    var apiUrl = domain+'/process-related.php';
	
	var request = $.ajax({
		url: apiUrl,
		method: "POST",
		data: {
            keyword: keyword,
			slug: slug,
            page: 1
        },
        dataType: 'text'
	});
    request.done(function(response, status, xhr) {
	console.log("XHR状态:", status);
    console.log("HTTP状态码:", xhr.status);
    console.log("完整响应:", response);
    
    // 检查HTTP状态码（重要！）
    if (xhr.status !== 200) {
        //alert("服务器返回错误状态: " + xhr.status);
        return;
    }
    
    // 不要直接假设response.data存在
    // 先检查整个响应结构
    if (!response) {
        $('#search_result_box_loading').html('<div class="nothing" id="search_info">抱歉，未找到任何相似图书文件！</div>');
        return;
    }
	$('#search_result_box_loading').hide();
    $('#search_result_box').html(response);
	$('#search_result_box').show();
    // 尝试多种可能的响应结构
    
    });
    request.fail(function(jqXHR, textStatus, errorThrown) {
	$('#search_result_box_loading').html('<div class="nothing" id="search_info">抱歉，未找到任何相似图书文件！</div>');
    });
}// JavaScript Document

function checkcode() {
	
	var code = $('#very_code').val().trim();
	var slug = $('#slug').val().trim();
    if (code === '') return;
    //alert(keyword);
    //$('#loading').show();
    //$('#search-results').html('');
	$('#code_msg').html('正在验证验证码，请稍后！');
    
    // 调用自定义API端点
    var apiUrl = domain+'/process-captha.php';
	
	var request = $.ajax({
		url: apiUrl,
		method: "POST",
		data: {
            code: code,
			slug: slug
        },
        dataType: 'text'
	});
    request.done(function(response, status, xhr) {
    
    // 检查HTTP状态码（重要！）
    if (xhr.status !== 200) {
        //alert("服务器返回错误状态: " + xhr.status);
        return;
    }
    
    // 不要直接假设response.data存在
    // 先检查整个响应结构
    if (!response) {
        //$('#code_msg').html('验证输出错误，请重新输入！');
        return;
    }
	$('#code_msg').html(response);
    
    });
    request.fail(function(jqXHR, textStatus, errorThrown) {
	$('#code_msg').html('验证输出错误，请重新输入！');
    });
}