<?php
// target-website.com/api/posts.php
include_once '../config.php';
include_once '../fun.php';
include_once '../post.php';

$data =  file_get_contents('php://input');

$res =  (object)json_decode($data, true);
//print_r($res->title);
$post_status = $res->post_status;
echo $post_status;

// 处理不同请求
switch ($post_status) {
    case 'publish':
        // 创建或更新文章
		$p = new Post();
	    $p->init($res);
		//print_r($p);
		$p->add();
        
        break;
        
    case 'trash':
        // 删除文章
      	$p = new Post();
	    $p->init($res);
		$p->delete();
        break;
        
    default:
       
        exit;
}

?>