<?php

/**
 * 路由配置
 */

use App\Router\Router;
use App\Controller\Api\BooksController;
use App\Controller\Api\SearchController;
use App\Controller\Api\DownloadController;
use App\Controller\Api\StatsController;
use App\Controller\View\HomeController;
use App\Controller\View\CategoryController;
use App\Controller\View\TagController;
use App\Controller\View\SearchController as ViewSearchController;
use App\Controller\View\BookController;
use App\Controller\View\StaticController;

$router = new Router();

// ==================== API 路由 ====================
// 图书相关 API
$router->get('/api/books/latest', [BooksController::class, 'latest'], [], 'api.books.latest');
$router->get('/api/books/hot', [BooksController::class, 'hot'], [], 'api.books.hot');
$router->get('/api/books/{slug}', [BooksController::class, 'show'], [], 'api.books.show');
$router->get('/api/books/{slug}/related', [BooksController::class, 'related'], [], 'api.books.related');

// 分类、标签、格式、来源
$router->get('/api/categories', [BooksController::class, 'categories'], [], 'api.categories');
$router->get('/api/tags', [BooksController::class, 'tags'], [], 'api.tags');
$router->get('/api/formats', [BooksController::class, 'formats'], [], 'api.formats');
$router->get('/api/sources', [BooksController::class, 'sources'], [], 'api.sources');

// 搜索 API
$router->get('/api/search', [SearchController::class, 'search'], [], 'api.search');
$router->get('/api/search/suggest', [SearchController::class, 'suggest'], [], 'api.search.suggest');

// 下载 API
$router->get('/api/download/{slug}', [DownloadController::class, 'getToken'], [], 'api.download.token');
$router->get('/api/download', [DownloadController::class, 'redirect'], [], 'api.download.redirect');
$router->get('/api/download/{slug}/health', [DownloadController::class, 'checkHealth'], [], 'api.download.health');

// 统计 API
$router->get('/api/stats/overview', [StatsController::class, 'overview'], [], 'api.stats.overview');

// ==================== 页面路由 (SSR) ====================

// 首页
$router->get('/', [HomeController::class, 'index'], [], 'home');

// 分类列表页
$router->get('/category/{slug}/', [CategoryController::class, 'show'], [], 'category.show');
$router->get('/category/{slug}/page/{page}/', [CategoryController::class, 'show'], [], 'category.page');

// 标签聚合页
$router->get('/tag/{slug}/', [TagController::class, 'show'], [], 'tag.show');
$router->get('/tag/{slug}/page/{page}/', [TagController::class, 'show'], [], 'tag.page');

// 搜索页
$router->get('/search/', [ViewSearchController::class, 'show'], [], 'search');
$router->get('/search/page/{page}/', [ViewSearchController::class, 'show'], [], 'search.page');

// 图书详情页
$router->get('/book/{slug}.html', [BookController::class, 'show'], [], 'book.show');

// 静态页面
$router->get('/about/', [StaticController::class, 'about'], [], 'about');
$router->get('/dmca/', [StaticController::class, 'dmca'], [], 'dmca');
$router->get('/contact/', [StaticController::class, 'contact'], [], 'contact');

// Sitemap & Robots
$router->get('/sitemap.xml', [StaticController::class, 'sitemap'], [], 'sitemap');
$router->get('/robots.txt', [StaticController::class, 'robots'], [], 'robots');

// 兼容旧 URL 重定向
$router->get('/file/{slug}.html', function ($params) {
    return \App\Http\Response::redirect(\App\Config::url("/book/{$params['slug']}.html"), 301);
}, [], 'legacy.file');

$router->get('/category/{cat}-{page}.html', function ($params) {
    return \App\Http\Response::redirect(\App\Config::url("/category/{$params['cat']}/page/{$params['page']}/"), 301);
}, [], 'legacy.category');

return $router;