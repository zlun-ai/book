<?php

return [
    'app' => [
        'name' => 'YunLio',
        'description' => '免费下载epub、mobi、azw3、pdf、txt等格式电子书！',
        'url' => 'http://127.0.0.1/01-book-link',
        'timezone' => 'Asia/Shanghai',
        'locale' => 'zh-CN',
        'debug' => true,
    ],

    'database' => [
        'driver' => 'mysql',
        'host' => '127.0.0.1',
        'port' => 3306,
        'database' => '01_yunpan_link_site',
        'username' => 'root',
        'password' => 'Pass@1234',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'options' => [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 5,
        ],
    ],

    'jwt' => [
        'secret' => 'yunlio-jwt-secret-key-2025-change-in-production',
        'algorithm' => 'HS256',
        'ttl' => 300, // 5 minutes
        'issuer' => 'yunlio.com',
        'audience' => 'yunlio-users',
    ],

    'cache' => [
        'default_ttl' => 300, // 5 minutes
        'long_ttl' => 3600,   // 1 hour
        'short_ttl' => 60,    // 1 minute
        'enabled' => true,
        'cache_dir' => __DIR__ . '/../storage/cache', // 相对于 config 目录
    ],

    'pagination' => [
        'default_per_page' => 20,
        'max_per_page' => 100,
    ],

    'search' => [
        'min_query_length' => 2,
        'suggest_limit' => 10,
        'highlight_tag' => 'mark',
    ],

    'download' => [
        'token_ttl' => 300, // 5 minutes
        'bind_ip' => true,
        'log_downloads' => true,
    ],

    'link_health' => [
        'check_timeout' => 10,
        'max_redirects' => 3,
        'healthy_codes' => [200, 206],
        'need_password_codes' => [401, 403],
        'rate_limit_codes' => [429],
    ],

    'security' => [
        'csp' => "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' cdn.jsdelivr.net cdn.tailwindcss.com; style-src 'self' 'unsafe-inline' cdn.jsdelivr.net cdn.tailwindcss.com; font-src 'self' data: cdn.jsdelivr.net; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none';",
        'hsts_max_age' => 31536000,
        'referrer_policy' => 'strict-origin-when-cross-origin',
    ],

    'wp_api' => [
        'base_url' => 'http://127.0.0.1/wp-link-search/wp-json/restapi/v1',
        'timeout' => 10,
    ],
];