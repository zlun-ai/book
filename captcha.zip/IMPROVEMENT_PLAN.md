# 电子书下载站重构改进方案

> 基于现有 WordPress REST API 数据源（标题、分类、标签、格式、大小、下载链接、提取码、来源、发布时间、Slug）的务实重构方案

---

## 1. 页面架构设计（共 6 类 15+ 页面）

| 页面类型 | URL 模式 | 页面数 | 核心价值 |
|----------|----------|--------|----------|
| 首页 | `/` | 1 | 流量入口、分类导航、新书展示、热门标签 |
| 分类列表页 | `/category/{slug}/` `/category/{slug}/page/{n}/` | 12 (动态) | 垂直领域流量聚合、长尾词覆盖 |
| 标签聚合页 | `/tag/{slug}/` `/tag/{slug}/page/{n}/` | N (动态) | 精准长尾流量、交叉筛选入口 |
| 搜索结果页 | `/search/?q={keyword}&page={n}` | 1 | 高意图流量承接、纠错建议 |
| 图书详情页 | `/book/{slug}.html` | N (动态) | 核心转化页、下载入口、SEO 落地页 |
| 静态信息页 | `/about/` `/dmca/` `/contact/` `/sitemap.xml` | 4 | 信任信号、合规、爬虫引导 |

---

## 2. 各页面详细规格

### 2.1 首页 (`/`)
**SEO 目标**：品牌词 + 核心大词（"电子书免费下载"、"epub 下载"、"mobi 下载"）

#### 内容模块
| 模块 | 内容来源 | 展示逻辑 | SEO 要点 |
|------|----------|----------|----------|
| Hero 区 | 站点 Slogan + 搜索框 | 固定 | H1 包含核心词，搜索框 `role="search"` |
| 新书速递 | `post_date` 近 7 天 | 按时间倒序 10 条 | `schema.org/ItemList` + `Book` |
| 分类导航 | `get_all_cats()` | 网格图标 + 数量徽章 | 内链矩阵，锚文本含分类名 |
| 热门标签云 | 高频 `post_tag` | Top 30，字体大小加权 | 长尾词内链入口 |
| 热门下载榜 | 下载日志统计 | 近 30 天 Top 10 | 社交证明、点击诱导 |
| 格式快捷入口 | `post_format` 去重 | 5 个格式卡片 | 交叉分类入口 |

#### 交互功能
- 实时搜索建议（防抖 300ms，调用 `/api/suggest`）
- 分类卡片 hover 预览前 3 本
- PWA 安装提示（Service Worker 已注册）

#### 结构化数据
```json
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "YunLio",
  "url": "https://yunlio.com",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://yunlio.com/search/?q={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
```

---

### 2.2 分类列表页 (`/category/{slug}/page/{n}/`)
**SEO 目标**：分类核心词（"小说电子书下载"、"计算机书籍下载"）

#### URL 设计
- 规范化：`/category/xiaoshuo-wenxue/`（中文 slug → 拼音/英文）
- 分页：`/category/xiaoshuo-wenxue/page/2/`
- `rel="canonical"` 指向首页，分页页 `rel="prev/next"`

#### 页面结构
```html
<main>
  <header class="category-header">
    <h1>小说文学 - 免费电子书下载 <span class="count">(1,234 本)</span></h1>
    <p class="description">收录小说文学类电子书 1234 本，涵盖言情、玄幻、历史、都市等题材，提供 PDF/EPUB/MOBI/TXT 多格式免费下载。</p>
    <nav class="sub-filters" aria-label="筛选">
      <select name="format">格式：<option value="">全部</option><option value="epub">EPUB</option>...</select>
      <select name="size">大小：<option value="">全部</option><option value="lt10">＜10MB</option>...</select>
      <select name="source">来源：<option value="">全部</option><option value="ctfile">城通网盘</option>...</select>
      <select name="sort">排序：<option value="new">最新</option><option value="hot">热门</option><option value="size">大小</option></select>
    </nav>
  </header>

  <section class="book-grid" itemscope itemtype="https://schema.org/ItemList">
    <!-- 重复 BookCard 组件 -->
    <article class="book-card" itemprop="itemListElement" itemscope itemtype="https://schema.org/Book">
      <a href="/book/{slug}.html" class="book-link" itemprop="url">
        <div class="book-cover" aria-hidden="true">
          <span class="format-badge" itemprop="bookFormat">EPUB</span>
        </div>
        <h2 class="book-title" itemprop="name">《三体》</h2>
        <div class="book-meta">
          <span class="tag" itemprop="keywords">科幻</span>
          <span class="tag" itemprop="keywords">刘慈欣</span>
          <span class="source-badge ctfile">城通</span>
        </div>
        <div class="book-stats">
          <span itemprop="fileSize" content="2.3 MB">2.3 MB</span>
          <time itemprop="datePublished" datetime="2024-01-15">3 天前</time>
        </div>
      </a>
    </article>
  </section>

  <nav class="pagination" aria-label="分页导航">
    <link rel="prev" href="/category/xiaoshuo-wenxue/page/1/">
    <a rel="next" href="/category/xiaoshuo-wenxue/page/3/">下一页</a>
    <span class="page-numbers">第 2 / 50 页</span>
  </nav>
</main>
```

#### 结构化数据（每张卡片）
```json
{
  "@type": "Book",
  "@id": "https://yunlio.com/book/{slug}.html",
  "name": "《三体》",
  "bookFormat": "EPUB",
  "fileSize": "2.3 MB",
  "datePublished": "2024-01-15",
  "keywords": ["科幻", "刘慈欣", "雨果奖"],
  "publisher": { "@type": "Organization", "name": "城通网盘" },
  "offers": {
    "@type": "Offer",
    "price": "0",
    "priceCurrency": "CNY",
    "availability": "https://schema.org/InStock",
    "url": "https://yunlio.com/book/{slug}.html"
  }
}
```

---

### 2.3 标签聚合页 (`/tag/{slug}/page/{n}/`)
**SEO 目标**：超长尾精准词（"刘慈欣 epub 下载"、"Python 编程 pdf"）

#### 差异化设计
- 面包屑：`首页 > 标签 > 科幻`
- 标签语义描述（自动生成）：`"科幻" 标签收录 456 本电子书，主要格式为 EPUB(60%)、PDF(30%)，热门作者包括 刘慈欣、阿西莫夫、赫伯特...`
- 相关标签推荐（共现分析）：`科幻 → 刘慈欣、三体、雨果奖、硬科幻`

---

### 2.5 搜索结果页 (`/search/?q={keyword}&page={n}`)
**SEO 目标**：捕获所有长尾搜索意图

#### 功能规格
| 功能 | 实现 |
|------|------|
| 全文检索 | MySQL Fulltext (`file_name`, `link_words`, `file_category`, `file_tag`) |
| 加权排序 | 标题精准匹配 > 标题分词匹配 > 标签匹配 > 摘要匹配 > 分类匹配 |
| 高亮显示 | 标题/标签/摘要片段 `<mark>关键词</mark>` |
| 拼写纠错 | 编辑距离 + 拼音匹配 → "您是否在找：xxx" |
| 搜索建议 | `/api/suggest?q=xxx` 返回 Top 10 热门相关词 |
| 空结果兜底 | 推荐热门分类/标签/新书 |
| URL 规范化 | 去除停用词、小写、去重 → `/search/?q=python+编程` |

#### 结构化数据
```json
{
  "@context": "https://schema.org",
  "@type": "SearchResultsPage",
  "mainEntity": {
    "@type": "ItemList",
    "numberOfItems": 1234,
    "itemListElement": [...Book 结构化数据...]
  }
}
```

---

### 2.6 图书详情页 (`/book/{slug}.html`) —— **核心转化页**
**SEO 目标**：书名 + 格式 + 下载（"三体 epub 下载"、"三体 mobi 免费下载"`）

#### 页面完整结构
```html
<article itemscope itemtype="https://schema.org/Book" itemid="/book/{slug}.html">
  <meta itemprop="url" content="https://yunlio.com/book/{slug}.html">

  <!-- 面包屑 -->
  <nav class="breadcrumb" aria-label="面包屑导航" itemscope itemtype="https://schema.org/BreadcrumbList">
    <span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
      <a itemprop="item" href="/"><span itemprop="name">首页</span></a>
      <meta itemprop="position" content="1">
    </span>
    <span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
      <a itemprop="item" href="/category/{cat_slug}/"><span itemprop="name">{分类名}</span></a>
      <meta itemprop="position" content="2">
    </span>
    <span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
      <span itemprop="name">{书名}</span>
      <meta itemprop="position" content="3">
    </span>
  </nav>

  <!-- 核心信息区 -->
  <header class="book-header">
    <h1 itemprop="name"><span class="title-mark">《</span>{书名}<span class="title-mark">》</span></h1>
    <div class="book-meta-bar">
      <span class="category" itemprop="genre">{分类名}</span>
      <span class="format-badge" itemprop="bookFormat">{格式}</span>
      <span class="file-size" itemprop="fileSize" content="{KB} KB">{大小}</span>
      <span class="source-badge {来源}" itemprop="publisher" itemscope itemtype="https://schema.org/Organization">
        <span itemprop="name">{来源}</span>
      </span>
      <time class="pub-date" itemprop="datePublished" datetime="{ISO日期}">{相对时间}</time>
    </div>
    <div class="tags" itemprop="keywords">
      {标签1} {标签2} {标签3} ...
    </div>
  </header>

  <!-- 下载区（Above the Fold） -->
  <section class="download-section" aria-labelledby="download-heading">
    <h2 id="download-heading" class="visually-hidden">下载选项</h2>
    <div class="mirror-list">
      <!-- 单源或多源 -->
      <div class="mirror-item" data-mirror="ctfile">
        <a href="/api/download/{slug}?token={JWT}&mirror=ctfile"
           class="btn-download"
           rel="noopener noreferrer"
           target="_blank"
           data-track="download_click">
          <i class="fa fa-download" aria-hidden="true"></i>
          <span>直链下载</span>
          <span class="format">{格式}</span>
        </a>
        <div class="extract-code" v-if="psw">
          <label>提取码：</label>
          <code id="psw-{slug}">{提取码}</code>
          <button class="btn-copy" data-clipboard-target="#psw-{slug}"
                  aria-label="复制提取码">复制</button>
        </div>
        <span class="health-badge healthy" title="链接正常，最近检测于 {时间}">🟢 链接正常</span>
      </div>
    </div>
    <p class="download-tip">提示：建议使用 IDM/迅雷等工具下载大文件；EPUB 推荐用 Neat Reader/微信读书打开。</p>
  </section>

  <!-- 简介区（利用 post_excerpt） -->
  <section class="book-excerpt" itemprop="description">
    <h2>内容简介</h2>
    <div class="excerpt-content">{post_excerpt 内容，无则隐藏该区块}</div>
  </section>

  <!-- 相关推荐 -->
  <section class="related-books" aria-labelledby="related-heading">
    <h2 id="related-heading">相关推荐</h2>
    <div class="book-grid">
      <!-- 复用 BookCard，数据来自 /api/related/{slug} -->
    </div>
  </section>

  <!-- 结构化数据注入（JSON-LD） -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Book",
    "@id": "https://yunlio.com/book/{slug}.html",
    "name": "{书名}",
    "bookFormat": "{格式}",
    "fileSize": "{大小}",
    "datePublished": "{ISO日期}",
    "description": "{摘要前 200 字}",
    "keywords": ["{标签1}", "{标签2}", "..."],
    "genre": "{分类}",
    "publisher": { "@type": "Organization", "name": "{来源}" },
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "CNY",
      "availability": "https://schema.org/InStock",
      "url": "https://yunlio.com/api/download/{slug}?token={JWT}",
      "description": "{来源} 下载，{提取码提示}"
    },
    "isFamilyFriendly": true,
    "inLanguage": "zh-CN"
  }
  </script>
</article>
```

#### 关键 SEO 细节
| 要点 | 实现 |
|------|------|
| 规范 URL | `<link rel="canonical" href="https://yunlio.com/book/{slug}.html">` |
| 社交分享 | Open Graph + Twitter Card（封面用格式图标兜底） |
| 语义化 HTML | `<article>` `<header>` `<section>` `<time>` `<code>` |
| 无障碍 | `aria-label`、语义标签、颜色对比度 AA 级 |
| 核心指标 | LCP < 2.5s（SSR 首屏）、CLS < 0.1（图片占位）、FID < 100ms |
| 爬虫友好 | 无 JS 渲染核心内容、`robots.txt` 允许、`sitemap.xml` 包含 |

---

### 2.7 静态信息页
| 页面 | 内容要点 | SEO 作用 |
|------|----------|----------|
| `/about/` | 站点使命、数据来源声明、免责条款、联系方式 | E-E-A-T 信任信号 |
| `/dmca/` | DMCA 流程、下架邮箱、处理时效、反通知流程 | 合规、降低法律风险 |
| `/contact/` | 表单（再CAPTCHA v3）、Telegram/Email、常见问题 | 用户信任、长尾问词 |
| `/sitemap.xml` | 每日自动生成：首页、分类、标签、近 30 天新书、所有详情页 | 爬虫发现效率 |

---

## 3. API 接口设计（供前端/爬虫调用）

| 接口 | 方法 | 参数 | 返回 | 缓存策略 |
|------|------|------|------|----------|
| `/api/books/latest` | GET | `limit=10` | Book[] | Redis 5min |
| `/api/books/hot` | GET | `limit=10, days=30` | Book[] | Redis 1h |
| `/api/books/{slug}` | GET | - | BookDetail | Redis 10min |
| `/api/books/{slug}/related` | GET | `limit=6` | Book[] | Redis 30min |
| `/api/categories` | GET | - | Category[] | Redis 1h |
| `/api/tags/hot` | GET | `limit=30` | Tag[] | Redis 1h |
| `/api/search` | GET | `q, page, per_page, format, category, sort` | PaginatedResult | Redis 5min (按 q+page) |
| `/api/suggest` | GET | `q, limit=10` | string[] | Redis 10min |
| `/api/download/{slug}` | GET | `token, mirror` | 302 Redirect / JSON Error | 无缓存 |
| `/api/stats/overview` | GET | - | 统计汇总 | Redis 1h |

**统一响应格式**：
```json
{
  "code": 200,
  "message": "ok",
  "data": { ... },
  "meta": { "page": 1, "per_page": 20, "total": 1234 },
  "links": { "next": "/api/books?page=2" }
}
```

---

## 4. 技术实施细节

### 4.1 后端重构（PHP 原生 + 单文件路由）
```
public/
├── index.php              # 统一入口，路由分发
├── api/
│   ├── books.php          # 图书相关 API
│   ├── search.php         # 搜索/建议
│   ├── categories.php
│   ├── tags.php
│   ├── download.php       # 下载中转
│   └── stats.php
├── view/
│   ├── home.php           # 首页 SSR
│   ├── category.php       # 分类页 SSR
│   ├── tag.php            # 标签页 SSR
│   ├── search.php         # 搜索页 SSR
│   ├── book.php           # 详情页 SSR
│   └── static/            # about/dmca/contact
├── src/
│   ├── Router.php         # 简易路由
│   ├── Controller/        # 各页面控制器
│   ├── Service/           # BookService, SearchService, DownloadService
│   ├── Repository/        # BookRepository, LogRepository
│   ├── DTO/               # BookDTO, SearchResultDTO
│   ├── Middleware/        # RateLimit, CacheControl, SecurityHeaders
│   └── View/              # 模板引擎封装
├── config/
│   ├── app.php
│   ├── database.php
│   ├── redis.php
│   └── jwt.php
└── cron/
    └── check_links.php    # 每日链接健康检查
```

### 4.2 前端技术栈（零构建、渐进增强）
- **Alpine.js 3.x** (CDN) —— 交互状态管理（搜索建议、复制提取码、移动端菜单）
- **Tailwind CSS 3.x** (CDN JIT) —— 样式，无需构建
- **原生 Fetch API** —— 数据请求
- **Service Worker** (Workbox CDN) —— 离线缓存、PWA
- **结构化数据** —— 模板直接渲染 JSON-LD

### 4.3 数据库优化
```sql
-- 核心索引
ALTER TABLE all_links 
  ADD FULLTEXT INDEX ft_search (file_name, link_words, file_category, file_tag),
  ADD INDEX idx_category_date (file_category, file_time DESC),
  ADD INDEX idx_format (file_type),
  ADD INDEX idx_source (file_src),
  ADD INDEX idx_date (file_time DESC),
  ADD INDEX idx_slug (link_slug);

-- 新增表
CREATE TABLE download_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  book_slug VARCHAR(64) NOT NULL,
  mirror VARCHAR(32),
  ip_hash CHAR(32) NOT NULL,  -- SHA256(ip+salt) 隐私保护
  user_agent VARCHAR(512),
  status ENUM('success','failed','expired','dead_link') DEFAULT 'success',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_book_date (book_slug, created_at),
  INDEX idx_date (created_at)
);

CREATE TABLE link_health (
  book_slug VARCHAR(64) PRIMARY KEY,
  mirror VARCHAR(32),
  status ENUM('healthy','need_password','rate_limited','dead') DEFAULT 'healthy',
  last_checked TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  http_code SMALLINT,
  response_time_ms INT
);
```

### 4.4 下载链接健康检查（每日 Cron）
```php
// cron/check_links.php
foreach ($pendingLinks as $link) {
  $result = httpHead($link['url'], ['timeout' => 10, 'follow_redirects' => 3]);
  $status = match(true) {
    $result['code'] === 200 => 'healthy',
    $result['code'] === 403 || $result['code'] === 401 => 'need_password',
    $result['code'] === 429 => 'rate_limited',
    default => 'dead'
  };
  // 更新 link_health 表
  // 若 dead：更新 all_links.link_status = 3，发送通知邮件给管理员
}
```

---

## 5. SEO 执行清单（上线前必做）

### 5.1 技术 SEO
- [ ] HTTPS 全站强制（HSTS 预加载）
- [ ] `robots.txt` 允许所有页面，屏蔽 `/api/` `/cron/` `/admin/`
- [ ] `sitemap.xml` 每日 02:00 自动生成，提交 Search Console / 百度资源平台
- [ ] 规范化 URL：www 301 到非 www、HTTP 301 到 HTTPS、尾斜杠统一
- [ ] 404 页面友好 + 搜索框 + 热门分类链接
- [ ] 面包屑导航全站覆盖 + BreadcrumbList 结构化数据
- [ ] 分页 `rel="prev/next"` + `rel="canonical"` 指向首页
- [ ] 核心页面 LCP < 2.5s、CLS < 0.1、INP < 200ms

### 5.2 内容 SEO
- [ ] 每个分类/标签/格式页有唯一 Description（模板化生成，含数量/格式分布/热门标签）
- [ ] 详情页 Title：`《{书名}》{格式}免费下载 - {分类} - YunLio`（< 60 字符）
- [ ] 详情页 Description：`《{书名}》{格式}版免费下载，大小{大小}，{来源}高速下载。{摘要前120字}...`（< 160 字符）
- [ ] 图片 Alt：`《{书名}》{格式}电子书封面`（无封面用格式图标）
- [ ] 结构化数据：Book + Offer + BreadcrumbList + SearchResultsPage 全覆盖
- [ ] 内链策略：详情页 → 3 个相关推荐、分类页、标签页、格式页

### 5.3 合规与信任
- [ ] DMCA 页面完整、响应流程公开
- [ ] 隐私政策、免责声明、用户协议
- [ ] ICP 备案号页脚展示
- [ ] 无恶意跳转、无强制下载器、无捆绑软件

---

## 6. 实施路线图

### Phase 1：核心重构（Week 1-2）
| 任务 | 产出 |
|------|------|
| 搭建路由/控制器/服务分层 | 可运行的 MVC 架构 |
| 实现 BookRepository + SearchService | 搜索/分类/详情数据层 |
| JWT 下载中替代验证码 | 删除 captcha/cookie 相关代码 |
| 详情页 SSR + Book 结构化数据 | 核心落地页上线 |
| 首页/分类页/搜索页 SSR | 主流量入口上线 |

### Phase 2：聚合页与体验（Week 3）
| 任务 | 产出 |
|------|------|
| 标签页 | 长尾流量入口 |
| 面包屑/分页/筛选面板 | 导航体验 |
| 下载统计/链接健康检查 Cron | 运营数据 + 信任徽章 |
| PWA / Service Worker | 离线/安装体验 |

### Phase 3：SEO 冲刺与运营（Week 4+）
| 任务 | 产出 |
|------|------|
| Sitemap 自动生成 + 提交 | 收录加速 |
| Search Console / 百度资源平台配置 | 监控收录/点击 |
| 热门标签/搜索词运营看板 | 内容决策 |
| 相关推荐算法迭代 | PV/下载率提升 |

---

## 7. 代码清理列表（删除/替换）

### 删除文件
```
captcha/VerifyCode.php
process-captha.php
cookie.php (仅保留通用工具类)
template/js/base.js (验证码/下载相关函数)
template/link-view-demo.html (旧详情页模板)
```

### 替换文件
| 旧文件 | 新文件 | 说明 |
|--------|--------|------|
| `index.php` | `public/index.php` | 统一入口 |
| `link-home-demo.html` | `view/home.php` | SSR 首页 |
| `link-cat.php` + `link-cat-demo.html` | `view/category.php` | SSR 分类页 |
| `process-search.php` | `api/search.php` | JSON API |
| `process-related.php` | `api/books.php?action=related` | JSON API |
| `link-view.php` + `link-view-demo.html` | `view/book.php` | SSR 详情页 |
| `fun.php` (部分) | `src/Service/BookService.php` | 业务逻辑分离 |

---

## 8. 预期收益量化

| 指标 | 现状 | 目标 | 提升路径 |
|------|------|------|----------|
| 首屏 LCP | ~4-6s | < 2.5s | SSR + 关键 CSS 内联 + 字体预加载 |
| 搜索收录页数 | ~基础 | +300% | 聚合页 + Sitemap + 结构化数据 |
| 长尾流量占比 | < 20% | > 50% | 标签聚合页 + 搜索优化 |
| 下载转化率 | 基准 | +40% | 直链下载 + 健康度徽章 + 无验证码 |
| 移动端易用性 | 差 | 优 | 响应式 + PWA + 触控优化 |
| 维护性 | 耦合严重 | 模块化 | 分层架构 + 单一职责 |

---

## 9. 风险与对策

| 风险 | 概率 | 影响 | 对策 |
|------|------|------|------|
| 远程 API 限流/变更 | 中 | 高 | 本地全量缓存、降级策略、多源备选 |
| 版权投诉下架 | 高 | 中 | DMCA 流程自动化、链接失效自动隐藏 |
| 搜索引擎算法调整 | 低 | 高 | 白帽 SEO、内容为王、技术合规 |
| 服务器资源不足 | 低 | 中 | Redis 缓存、CDN 静态资源、读写分离 |

---

## 10. 起步行动项（今日可开始）

1. **创建 `public/index.php` 统一入口**，引入 FastRoute 或原生路由表
2. **抽离 `BookService` 类**，将 `fun.php` 中的查询逻辑迁移进去
3. **实现 `generateDownloadToken()` + `/api/download/{slug}`**，替换验证码流程
4. **重写 `view/book.php` 详情页模板**，包含完整 JSON-LD 结构化数据
5. **配置 Nginx 伪静态**，支持 `/book/{slug}.html` `/category/{slug}/` 等语义化 URL

---

> **文档版本**：v1.0  
> **创建日期**：2025-09-26  
> **维护者**：重构组  
> **下一步**：Phase 1 代码落地，建议新建分支 `refactor/core` 开发