<?php
include_once "config.php";
include_once 'fun.php';
include_once "db.php";

function get_all_cats(){
	$cat_dict = "小说文学|经济管理|历史军事|计算机类|人文社科|艺术摄影|哲学宗教|医学健康|政治法律|自然科学|教材教辅|其他类型";
	$cat_icon = "fa-paper-plane|fa-th-list|fa-retweet|fa-desktop|fa-trophy|fa-table|fa-balance-scale|fa-plus|fa-codepen|fa-gg|fa-file-pdf-o|fa-sitemap";
	$cats = explode("|",$cat_dict);
	$icons = explode("|",$cat_icon);
	
	$x = array();
	$lx = count($cats);
	for($i=0; $i<$lx; $i++){
		$x[$cats[$i]] = array(HOME_URL."/category/".urlencode($cats[$i]).".html", $icons[$i]);
		
	}
	return $x;

}

class Category{
	public $cat_title = "";
    public $cat_slug = ""; 
	
	
	
	public function add_cat(){
	}
}
class Post{
	public $post_title = "";
    public $post_slug = "";
    public $post_link = "";
    public $post_modified = "";
	public $post_date = "";
    public $post_id = 0;
    public $post_content = "";
    public $post_excerpt = "";
	public $post_category = "";
	public $post_filesize = "";
	public $post_psw = "";
	public $post_user_name = "";
	public $post_user_id = "";
	
	public $post_src = "";
	public $post_page_link = "";
	public $post_format = "";
	public $post_tag = "";
	
	
	public function get_format(){
		$arr=array("pdf","epub","mobi","txt","chm","doc");
		
	}
	public function get_link_src($url){
		$pos = stripos($url, "ctfile.com/");
		if($pos){
			return "城通";
		}
		return "";
	}
	
	public function init($res){
		$this->post_title = $res->post_title;
		$this->post_title = str_replace("《","",$this->post_title);
		$this->post_title = str_replace("》","",$this->post_title);
		
		
		$this->post_slug = $res->post_slug;
		$this->post_modified = $res->post_modified;
		
		$ctx = $res->post_content;
		$post_excerpt = $res->post_excerpt;
		
		$post_filesize = getBetweenTags($ctx, "[filesize]","[/filesize]");
		$post_category = getBetweenTags($ctx, "[cat]","[/cat]");
		$post_link = getBetweenTags($ctx, "[url]","[/url]");
		$post_psw = getBetweenTags($ctx, "[psw]","[/psw]");
		$post_user = getBetweenTags($ctx, "[username]","[/username]");
		$post_user_id = getBetweenTags($ctx, "[userid]","[/userid]");
		
		$post_date = getBetweenTags($ctx, "[date]","[/date]");
		$post_format = getBetweenTags($ctx, "[format]","[/format]");
		$post_tag = getBetweenTags($ctx, "[tag]","[/tag]");
		
		$this->post_filesize = trim($post_filesize);
		$this->post_category = trim($post_category);
		$this->post_link = trim($post_link);
		$this->post_psw = trim($post_psw);
		$this->post_user_name = trim($post_user);
		$this->post_user_id = trim($post_user_id);
		$this->post_date = trim($post_date);
		$this->post_format = trim($post_format);
		$this->post_src = $this->get_link_src($post_link);
		$this->post_excerpt = trim($post_excerpt);
		$this->post_tag = trim($post_tag);
		
	}
	public function update(){
		if($this->post_slug == ""){
			return;
		}
		$updated = Database::execute(
            "UPDATE all_links SET link_words = ?, link_url = ?,link_psw=?, link_date=?, file_name=?, file_size=?, file_time=?, file_category=?, file_tag=?, file_type=?, file_src=?, userid=?, username=? WHERE link_slug = ?",
            [$this->post_excerpt,
		$this->post_link,
		$this->post_psw,
		$this->post_modified,
		$this->post_title,
		$this->post_filesize,
		$this->post_date,
		$this->post_category,
		$this->post_tag,
		$this->post_format,
		$this->post_src,
		$this->post_user_id,
		$this->post_user_name,
		$this->post_slug
		]
        );
	}
	public function is_exist(){
		if($this->post_slug == ""){
			return false;
		}
		$res = Database::query("SELECT link_id FROM all_links WHERE link_slug=? ", [$this->post_slug]);
	if($res) {
		echo "存在";
       return true; 
		}
	return false;
	}
	public function delete(){
		if($this->post_slug == ""){
				return;
			}
		Database::execute("delete from all_links WHERE link_slug = ?",[$this->post_slug]);
	}
	public function add(){
		if($this->post_slug == ""){
				return;
			}
		if ($this->is_exist()){
			$this->update();
			return;
		}
		$result = Database::execute(
		$link_words = 
        "INSERT INTO all_links (link_slug, link_words, link_url, link_psw, link_date, file_name, file_size, file_time, file_category, file_tag, file_type, file_src, userid, username) VALUES (?, ?, ?, ?,?, ?,?, ?,?, ?,?, ?,?,?)",
        [$this->post_slug,
		$this->post_excerpt,
		$this->post_link,
		$this->post_psw,
		$this->post_modified,
		$this->post_title,
		$this->post_filesize,
		$this->post_date,
		$this->post_category,
		$this->post_tag,
		$this->post_format,
		$this->post_src,
		$this->post_user_id,
		$this->post_user_name,
		]
    );
	}
	
	
	
    /*public $post_type = "post";
    

    public $post_img = "";
    public $pos_category = array();
    public $pos_tag = array();

    public function init_term($wp_term_array){
        foreach($wp_term_array as $terms){ #term_type
            foreach($terms as $term){
                $t = new Term();
                $t->term_type = $term->taxonomy;
                $t->term_name = $term->name;
                $t->term_slug = $term->slug;
                $t->term_id = $term->id;
                if($t->term_type == "post_tag"){
                    $this->pos_tag[] = $t;
                }else{
                    $this->pos_category[]= $t;
                }

            }
        }
    }*/

}

class Term{
    public $term_name = "";
    public $term_slug = "";
    public $term_id = 0;
    public $term_type = "";
}
?>