<?php
/**
 * Cookie管理器类 - 安全地处理cookie的设置、读取和删除
 * 遵循封装原则，将数据和方法捆绑在类中，隐藏内部实现细节 [[4]]
 */
class CookieManager
{
    /** @var string 默认路径 */
    private $path;
    
    /** @var string|null 默认域名 */
    private $domain;
    
    /** @var bool 是否仅通过HTTPS发送 */
    private $secure;
    
    /** @var bool 是否仅限HTTP访问（防止XSS攻击） */
    private $httponly;
    
    /** @var string SameSite策略 */
    private $samesite;
    
    /**
     * 构造函数 - 初始化cookie配置
     * 
     * @param string $path 默认路径（通常为'/'表示全站有效）
     * @param string|null $domain 域名（可选）
     * @param bool $secure 是否仅通过HTTPS发送
     * @param bool $httponly 是否禁止JavaScript访问
     * @param string $samesite SameSite策略（'Strict', 'Lax', 'None'）
     */
    public function __construct(
        string $path = '/',
        ?string $domain = null,
        bool $secure = true,
        bool $httponly = true,
        string $samesite = 'Strict'
    ) {
        $this->path = $path;
        $this->domain = $domain;
        $this->secure = $secure;
        $this->httponly = $httponly;
        $this->samesite = $samesite;
    }
    
    /**
     * 设置cookie
     *
     * @param string $name cookie名称
     * @param string $value cookie值
     * @param int $expire 过期时间戳（0表示会话cookie）
     * @return bool 是否成功发送cookie头
     */
    public function set(string $name, string $value, int $expire = 0): bool
    {
        // 确保在任何输出前设置cookie，否则会失败
        if (headers_sent()) {
            error_log("无法设置cookie: {$name} - headers已发送");
            return false;
        }
        
        return setcookie(
            $name,
            $value,
            [
                'expires' => $expire,
                'path' => $this->path,
                'domain' => $this->domain,
                'secure' => $this->secure,
                'httponly' => $this->httponly,
                'samesite' => $this->samesite
            ]
        );
    }
    
    /**
     * 获取cookie值
     *
     * @param string $name cookie名称
     * @param mixed $default 默认值（如果cookie不存在）
     * @return mixed cookie值或默认值
     */
    public function get(string $name, $default = null)
    {
        // 不要信任来自cookie的数据，始终进行验证 [[8]]
        return $_COOKIE[$name] ?? $default;
    }
    
    /**
     * 检查cookie是否存在
     *
     * @param string $name cookie名称
     * @return bool 是否存在
     */
    public function exists(string $name): bool
    {
        return isset($_COOKIE[$name]);
    }
    
    /**
     * 删除cookie
     *
     * @param string $name cookie名称
     * @return bool 是否成功
     */
    public function delete(string $name): bool
    {
        // 通过设置过去的时间来删除cookie
        return $this->set($name, '', time() - 3600);
    }
    
    /**
     * 获取所有cookie
     *
     * @return array 所有cookie的数组
     */
    public function getAll(): array
    {
        // 不要插入敏感数据到cookie中 [[8]]
        return $_COOKIE;
    }
}
?>