<?php
require_once __DIR__ . '/src/Autoloader.php';
\App\Config::load(__DIR__ . '/config/app.php');

$pdo = \App\Database::getInstance();

$sql = "
CREATE TABLE IF NOT EXISTS download_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    book_slug VARCHAR(300) NOT NULL,
    mirror VARCHAR(32) DEFAULT 'default',
    ip_hash CHAR(64) NOT NULL,
    user_agent VARCHAR(512) DEFAULT '',
    status ENUM('success','failed','expired','dead_link') DEFAULT 'success',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_book_slug (book_slug),
    INDEX idx_created_at (created_at),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='下载日志表';
";

try {
    $pdo->exec($sql);
    echo "Table download_logs created successfully." . PHP_EOL;
} catch (PDOException $e) {
    echo 'Error: ' . $e->getMessage() . PHP_EOL;
}