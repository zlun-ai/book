<?php
include "Request.php";
include "post.php";
include_once "inc/fenci.php";
include_once "db.php";
/**
 * 自定义字符串编码函数
 * 
 * 使用异或(XOR)操作和十六进制转换实现简单的数据混淆
 * 
 * @param string $string 要编码的原始字符串
 * @param string $key 加密密钥(默认为'secure_key')，密钥越复杂越安全
 * @return string 编码后的十六进制字符串
 */
function custom_encode($string, $key = 'secure_key') {
    $key_length = strlen($key);
    $result = '';
    
    // 1. 使用密钥对每个字符进行异或操作
    for ($i = 0; $i < strlen($string); $i++) {
        // 获取当前字符的ASCII值与密钥对应字符的ASCII值进行异或
        $xor_result = ord($string[$i]) ^ ord($key[$i % $key_length]);
        $result .= chr($xor_result);
    }
    
    // 2. 转换为十六进制确保可读性和URL安全
    return bin2hex($result);
}

/**
 * 自定义字符串解码函数
 * 
 * 逆转编码过程，恢复原始字符串
 * 
 * @param string $encoded_string 已编码的十六进制字符串
 * @param string $key 解密密钥(必须与编码时使用的密钥相同)
 * @return string 解码后的原始字符串
 * @throws Exception 当输入不是有效的十六进制字符串时抛出异常
 */
function custom_decode($encoded_string, $key = 'secure_key') {
    // 1. 验证输入是否为有效的十六进制字符串
    if (!preg_match('/^[0-9a-fA-F]*$/', $encoded_string) || strlen($encoded_string) % 2 !== 0) {
        throw new Exception("Invalid encoded string format");
    }
    
    // 2. 将十六进制转换回二进制数据
    $binary = hex2bin($encoded_string);
    if ($binary === false) {
        throw new Exception("Failed to decode hex string");
    }
    
    $key_length = strlen($key);
    $result = '';
    
    // 3. 使用相同密钥进行逆向异或操作
    for ($i = 0; $i < strlen($binary); $i++) {
        $xor_result = ord($binary[$i]) ^ ord($key[$i % $key_length]);
        $result .= chr($xor_result);
    }
    
    return $result;
}

function removePunctuationExcept($str, $keep = []) {
    if (!is_string($str)) {
        return $str;
    }
    
    // 默认所有标点
    $pattern = '/[\p{P}\p{S}]/u';
    
    if (!empty($keep)) {
        // 转义保留的标点
        $escaped = array_map(function($char) {
            return preg_quote($char, '/');
        }, $keep);
        
        // 创建排除模式
        $pattern = '/[\p{P}\p{S}](?!' . implode('|', $escaped) . ')/u';
    }
    
    return preg_replace($pattern, ' ', $str);
}

function getBetweenTags($str, $startTag = '[meta]', $endTag = '[/meta]') {
    // 转义特殊字符（因为[和]是正则特殊字符）
    $startEscaped = preg_quote($startTag, '/');
    $endEscaped = preg_quote($endTag, '/');
    
    // 创建正则模式：非贪婪匹配
    $pattern = "/{$startEscaped}(.*?){$endEscaped}/s";
    
    // 执行匹配
    if (preg_match($pattern, $str, $matches)) {
        return $matches[1]; // 返回第一个捕获组
    }
    
    return ''; // 未找到匹配
}

function get_url_content($url){
    //echo $url;
    $request = new Request($url);
    $request->execute();
    $response = $request->getResponse();
    //echo $request->getError();
    return $response;
}
?>
<?php
function get_param($name){
	if(isset($_GET[$name])){
		return $_GET[$name];
	}
	if(isset($_POST[$name])){
		return $_POST[$name];
	}
	return "";
}
function get_file_by_slug($slug){ // 
	$res = get_file_by_slug_from_local($slug);
	$p = "";
	if($res){
		$p = $res[0];
	}else{
		$p = get_file_by_slug_from_wordpress($slug);
	}
	return $p;
}

function get_file_by_slug_from_local($slug){
	$res = Database::query("SELECT * FROM all_links WHERE link_slug=?  order by link_id desc limit 0,6", [$slug]);
	//print_r($res);
    $x = array();
	if($res) {
        
        foreach ($res as $r) {
			
            $p = new Post();
			$p->post_slug = trim($r["link_slug"]);
			$p->post_filesize = trim($r["file_size"]);
			$p->post_title = trim($r["file_name"]);
		$p->post_category = trim($r["file_category"]);
		$p->post_link = trim($r["link_url"]);
		$p->post_psw = trim($r["link_psw"]);
		$p->post_user_name = trim($r["username"]);
		$p->post_user_id = trim($r["userid"]);
		$p->post_date = trim($r["file_time"]);
		$p->post_format = strtolower(trim($r["file_type"]));
		$p->post_src = trim($r["file_src"]);
		$x[]=$p;
        }
	}
	return $x;
}

function get_file_by_slug_from_wordpress($slug){
	if($slug==""){
		return "";
	}
//http://127.0.0.1/wp-link-search/wp-json/restapi/v1/post-slug/b9eee700ddefbf1b495ec17704307048
	$url = Config::$url."/post-slug/".$slug;
	$json = get_url_content($url);

    $obj = json_decode($json);          // 转换为对象
	print_r($obj);
	if(isset($obj->post_title)){
	}else{
		return "";
	}


    $p = new Post();
	$p->init($obj);
	return $p;
	
}

function get_files_by_key_from_wordpress($key_words,$num=30){
	//echo $key_words;
	$url = Config::$url."/search/?keyword=".urlencode($key_words)."&per_page=".$num;
	//echo $url;
	$json = get_url_content($url);
    $obj = json_decode($json);          // 转换为对象
	//print_r($obj);
	$data=$obj->data;
	//print_r($data);
	
	$res=array();
	foreach($data as $d){
		$p = new Post();
		$p->init($d);
		$res[]=$p;
		add_file_to_db($p);
	}

    
	return $res;
	
}
function get_safe_search($q){
	$q = urldecode($q);
	$q = removePunctuationExcept($q);
	$q = trim($q);
	$q = str_replace("="," ",$q);
	return $q;
}
function get_search($q, $num=30, $type="local"){
	$q = urldecode($q);
	$q = trim($q);
	if(strlen($q)<2){
		return array();
	}
	$words = get_fenci_words($q);
	//print_r($words);
	if(count($words)<1){
		return array();
	}
	$key_words = implode(" ", $words);
	if($type=="wordpress"){
		$res = get_files_by_key_from_wordpress($key_words, $num);
	}else{
		$res = get_files_by_key_from_local($key_words, $num);
	}
	
	//print_r($res);
	return $res;
}
function add_file_to_db($p){
	//link_slug	link_name	link_desc	link_words	link_url	link_psw	isbn_list	content_length_kb	link_status	link_date	link_download	file_name	file_size	file_time	file_category	file_type	file_dir	userid	username	file_id	

	$result = Database::execute(
        "INSERT INTO all_links (link_slug, link_words, link_url, link_psw, link_date, file_name, file_size, file_time, file_category, file_type, file_src, userid, username) VALUES (?, ?, ?, ?,?, ?,?, ?,?, ?,?, ?,?)",
        [$p->post_slug,
		$p->post_excerpt,
		$p->post_link,
		$p->post_psw,
		$p->post_modified,
		$p->post_title,
		$p->post_filesize,
		$p->post_date,
		$p->post_category,
		$p->post_format,
		$p->post_src,
		$p->post_user_id,
		$p->post_user_name,
		]
    );
}
function get_files_by_key_from_local($key_words, $num){
	if($key_words==""){
		return array();
	}
	$res = Database::query("SELECT * FROM all_links WHERE MATCH(link_words) AGAINST (? IN NATURAL LANGUAGE MODE) limit 0,?", [$key_words,$num]);
    $x = array();
	if($res) {
        
        foreach ($res as $r) {
			
            $p = new Post();
			$p->post_slug = trim($r["link_slug"]);
			$p->post_filesize = trim($r["file_size"]);
			$p->post_title = trim($r["file_name"]);
		$p->post_category = trim($r["file_category"]);
		$p->post_link = trim($r["link_url"]);
		$p->post_psw = trim($r["link_psw"]);
		$p->post_user_name = trim($r["username"]);
		$p->post_user_id = trim($r["userid"]);
		$p->post_date = trim($r["file_time"]);
		$p->post_format = trim($r["file_type"]);
		$p->post_src = trim($r["file_src"]);
		$x[]=$p;
        }
	}
	return $x;
}
function get_files_by_cat_name_from_local($cat_name, $page = 1, $num = 6){
	$start = ($page-1)*$num;
	$res = Database::query("SELECT * FROM all_links WHERE file_category=?  order by link_id desc limit ?,?", [$cat_name, $start, $num]);
	
    $x = array();
	if($res) {
        
        foreach ($res as $r) {
			
            $p = new Post();
			$p->post_slug = trim($r["link_slug"]);
			$p->post_filesize = trim($r["file_size"]);
			$p->post_title = trim($r["file_name"]);
		$p->post_category = trim($r["file_category"]);
		$p->post_link = trim($r["link_url"]);
		$p->post_psw = trim($r["link_psw"]);
		$p->post_user_name = trim($r["username"]);
		$p->post_user_id = trim($r["userid"]);
		$p->post_date = trim($r["file_time"]);
		$p->post_format = strtolower(trim($r["file_type"]));
		$p->post_src = trim($r["file_src"]);
		$x[]=$p;
        }
	}
	return $x;
}
?>