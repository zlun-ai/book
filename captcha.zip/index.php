<?php
include "config.php";
include "fun.php";
include_once "post.php";
?>
<?php
$all_cats = get_all_cats();
$is_home = true;
?>
<?php
include "template/link-home-demo.html";
?>