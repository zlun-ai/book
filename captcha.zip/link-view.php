<?php
include "config.php";
include "fun.php";
include_once "cookie.php";
?>
<?php
$slug = get_param("slug");
$post = get_file_by_slug($slug);

if($post==""){
}else{
?>
<?php
$cookie = new CookieManager(
    '/', 
    '127.0.0.1',  //example.com
    true,   // Secure - 仅HTTPS
    true,   // HttpOnly - 防止XSS
    'Strict' // SameSite - 防止CSRF
);
$title= "";
if($post->post_format!=""){
	$title = "《".$post->post_title."》".".".strtolower($post->post_format)."免费下载";
}else{
	$title = "《".$post->post_title."》免费下载";
}


$ux = custom_encode($post->post_link);
$cookie->set($post->post_slug, $ux, time() + 3600);
include "template/link-view-demo.html";
}
?>