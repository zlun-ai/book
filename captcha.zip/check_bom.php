<?php
// Check for BOM in key PHP files
$files = [
    __DIR__ . '/public/index.php',
    __DIR__ . '/src/Autoloader.php',
    __DIR__ . '/config/app.php',
    __DIR__ . '/src/Autoloader.php',
    __DIR__ . '/view/partials/header.php',
    __DIR__ . '/view/partials/book-card.php',
];

foreach ($files as $file) {
    $content = file_get_contents($file);
    if (substr($content, 0, 3) === "\xEF\xBB\xBF") {
        echo "BOM found in: $file\n";
    }
    
    // Check for any output before <?php
    $pos = strpos($content, '<?php');
    if ($pos !== 0) {
        $prefix = substr($content, 0, $pos);
        if (trim($prefix) !== '') {
            echo "Whitespace/output before <?php in: $file (length: " . strlen($prefix) . ")\n";
            echo "  Prefix: '" . substr($prefix, 0, 50) . "'\n";
        }
    }
}

echo "Check complete.\n";