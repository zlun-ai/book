<?php
require_once __DIR__ . '/src/Autoloader.php';
\App\Config::load(__DIR__ . '/config/app.php');
\App\Cache::configure(\App\Config::cache());

// Test direct DB query
$pdo = \App\Database::getInstance();
$rows = $pdo->query("SELECT link_id, file_name, file_type FROM all_links ORDER BY link_id DESC LIMIT 10")->fetchAll();

echo "Direct DB query results:\n";
foreach ($rows as $row) {
    echo "ID: {$row['link_id']}, Title: {$row['file_name']}, Type: {$row['file_type']}\n";
    echo "  Title bytes: " . bin2hex($row['file_name']) . "\n";
    echo "  Title encoding: " . mb_detect_encoding($row['file_name']) . "\n";
}

echo "\n=== Testing DTO ===\n";
$repo = new \App\Repository\BookRepository();
$books = $repo->getPopular24h(5);
echo "Books count: " . count($books) . "\n";
foreach ($books as $book) {
    echo "Title: {$book->title}\n";
    echo "  Bytes: " . bin2hex($book->title) . "\n";
    echo "  Encoding: " . mb_detect_encoding($book->title) . "\n";
}