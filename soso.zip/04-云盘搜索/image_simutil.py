import cv2
import matplotlib.pyplot as plt
import os
import fileutil


# Resize images to a similar dimension
# This helps improve accuracy and decreases unnecessarily high number of keypoints
def imageResizeTrain(image):
    maxD = 1024
    height, width = image.shape
    aspectRatio = width / height
    if aspectRatio < 1:
        newSize = (int(maxD * aspectRatio), maxD)
    else:
        newSize = (maxD, int(maxD / aspectRatio))
    image = cv2.resize(image, newSize)
    return image


def imageResizeTest(image):
    maxD = 1024
    height, width, channel = image.shape
    aspectRatio = width / height
    if aspectRatio < 1:
        newSize = (int(maxD * aspectRatio), maxD)
    else:
        newSize = (maxD, int(maxD / aspectRatio))
    image = cv2.resize(image, newSize)
    return image


def computeSIFT(image):
    #sift = cv2.xfeatures2d.SIFT_create()
    sift = cv2.SIFT_create()
    return sift.detectAndCompute(image, None)


def calculateResultsFor(image_1, image_2):
    # print(cv2.imread(image_1,0))
    image_1_data = imageResizeTrain(cv2.imread(image_1, 0))
    image_2_data = imageResizeTrain(cv2.imread(image_2, 0))
    keypoint1, descriptor1 = computeSIFT(image_1_data)
    keypoint2, descriptor2 = computeSIFT(image_2_data)
    matches = calculateMatches(descriptor1, descriptor2)
    score = calculateScore(len(matches), len(keypoint1), len(keypoint2))
    plot = getPlotFor(image_1, image_2, keypoint1, keypoint2, matches)
    # print(len(matches),len(keypoint1),len(keypoint2),len(descriptor1),len(descriptor2))
    # print(score) # 结果
    # print(type(plot))
    # plt.imsave("test.png", plot)

    #plt.imshow(plot)
    # plt.savefig("test.png")
    #plt.show()
    return score, plot


def getPlotFor(image1, image2, keypoint1, keypoint2, matches):
    image1 = imageResizeTest(cv2.imread(image1))
    image2 = imageResizeTest(cv2.imread(image2))
    return getPlot(image1, image2, keypoint1, keypoint2, matches)


def calculateScore(matches, keypoint1, keypoint2):
    return 100 * (matches / min(keypoint1, keypoint2))


def calculateMatches(des1, des2):
    bf = cv2.BFMatcher()
    matches = bf.knnMatch(des1, des2, k=2)
    topResults1 = []
    for m, n in matches:
        if m.distance < 0.7 * n.distance:
            topResults1.append([m])
    matches = bf.knnMatch(des2, des1, k=2)
    topResults2 = []
    for m, n in matches:
        if m.distance < 0.7 * n.distance:
            topResults2.append([m])
    topResults = []
    for match1 in topResults1:
        match1QueryIndex = match1[0].queryIdx
        match1TrainIndex = match1[0].trainIdx
        for match2 in topResults2:
            match2QueryIndex = match2[0].queryIdx
            match2TrainIndex = match2[0].trainIdx
            if (match1QueryIndex == match2TrainIndex) and (match1TrainIndex == match2QueryIndex):
                topResults.append(match1)
    return topResults


def getPlot(image1, image2, keypoint1, keypoint2, matches):
    image1 = cv2.cvtColor(image1, cv2.COLOR_BGR2RGB)
    image2 = cv2.cvtColor(image2, cv2.COLOR_BGR2RGB)
    matchPlot = cv2.drawMatchesKnn(image1, keypoint1, image2, keypoint2, matches, None, [255, 255, 255], flags=2)
    return matchPlot


# --
imageList = [
    r"F:\all-google-zh-pdf\douban-images\9780071408516.jpg",
    "F:\\all-google-zh-pdf\\download-images\\0a77adabab9a63899a6a16e8ebd0998d.png"]
lx = len(imageList) - 1

#douban = fileutil.traverseDir("F:\\all-google-zh-pdf\\douban-images", ['9787206043550.jpg'])
#cover = fileutil.traverseDir("F:\\all-google-zh-pdf\\download-images", ["40dc2fea536f41d20ee300005218f82b.png"])
#for d in douban:
    #i = 0
    #for c in cover:
        #score, plot = calculateResultsFor(d, c)
        #print(score)
        #if score > 20:
            #
            #dirname, filename, extend = fileutil.getFilePathInfo(d)
            #plt.imshow(plot)
            #p = r"F:\all-google-zh-pdf\similar" + "\\" + filename + "-" + str(i) + ".png"
            #plt.savefig(p)
            #i += 1
# for i in range(lx):
# print(imageList[i])
# if not os.path.exists(imageList[i]):
# continue
# print(imageList[i+1])
#calculateResultsFor(r'F:\all-google-en-pdf\cover\7\9780990576747.jpg',r"F:\all-google-en-pdf\cover\7\9780990576747.jpg")
# print(imageList[i],imageList[i+1],score)
