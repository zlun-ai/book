#-*- coding: utf-8 -*-
# author: Zhilun Yu

import  pandas  as pd
#data = {'Name':['Tom', 'Jack', 'Steve', 'Ricky'],'Age':[28,34,29,42]}
def save_data_to_excel(excel_name, sheet_name, data):
    columns = []
    for k, v in data.items():
        columns.append(k)
    with pd.ExcelWriter(excel_name) as writer:
        df = pd.DataFrame(data, index=None)
        df.to_excel(writer, sheet_name=sheet_name, index=False, columns=columns)

def getRows(excel_file, sheet_name, start_row = 0, offset = 1):

    def get_text(v):
        v = str(v).strip()
        if v == "nan":
            v = ""
        return v

    excel_data = pd.read_excel(excel_file, sheet_name = sheet_name, header=None)
    # print(excel_data)
    size = excel_data.shape
    print(size)
    row_num = size[0]
    datax = []
    for i in range(start_row, row_num):
        data = excel_data.iloc[i].values.tolist()
        datax.append(data)

    if offset == 1:
        header = datax[0]
        datax = datax[1:]

        header_x = {}
        header_name = []
        for u in header:
            header_name.append(u)
        print("header_name=",header_name)
        column_num = len(header_name)
        for i in range(column_num):
            u = header_name[i]
            header_x[u] = [get_text(d[i]) for d in datax]
        datax = header_x
    return datax