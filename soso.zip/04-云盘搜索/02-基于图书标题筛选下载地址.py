# -*- coding:utf-8 -*-
import os.path
import jieba
import netutil
import fileutil
import urllib
import time
import random
import stringutil
import htmlutil
import json
import tabledb
from tqdm import  tqdm
import re
import book_util
#-----------
def remove_date(text):
    pattern = re.compile(r'[0-9\-/]{5,}', re.IGNORECASE)
    text = re.sub(pattern, '', text)
    text = text.strip()
    return text
def get_valid_file_name(file_name):
    dirname, filename, extend = fileutil.getFilePathInfo(file_name)
    filename = remove_date(filename)

    return filename
def get_links_by_text(text, num = 5):
    text_words = stringutil.get_fenci(text)
    if text_words == "":
        return []
    sql = f"SELECT link_id, file_name FROM `yunpan_link` WHERE match(link_words) against('{text_words}') limit  {num}"
    #print(sql)
    links = tabledb.query_sql(sql)
    if links is None:
        return []
    all_links = []
    for link in links:
        link_id = link[0]
        link_name = link[1]
        d={}
        d["link_id"]=link_id
        d["link_name"] = link_name
        all_links.append(d)
    return all_links



def get_links(book, num = 10):
    all_links = []

    ctx = book["book_name"]
    all_links_by_book_name = get_links_by_text(ctx)
    all_links.extend(all_links_by_book_name)

    if book["book_author"] !="":
        ctx = book["book_name"]+" "+book["book_author"]
        all_links_by_book_author = get_links_by_text(ctx)
        all_links.extend(all_links_by_book_author)
    if book["book_ori_author"] != "":
        ctx = book["book_name"] + " " + book["book_author"] + " "+book["book_ori_author"]
        all_links_by_book_author = get_links_by_text(ctx)
        all_links.extend(all_links_by_book_author)

    if book["book_isbn"] != "":
        ctx = book["book_isbn"]
        all_links_by_isbn = get_links_by_text(ctx)
        all_links.extend(all_links_by_isbn)
    return all_links




def is_book_type(text):
    text = text.strip()
    text = text.lower()
    arr = [".pdf",".epub",".mobi", ".zip",".rar",".txt",".docs",".chm",".azw",".azw3",".azw6"]
    for a in arr:
        if text.endswith(a):
            return True
    return False

def get_all_books():
    #遍历所有的链接
    table = "all_book"
    keys = 'book_id,book_slug,book_name,book_author,book_ori_author,book_isbn'
    books = tabledb.query(table, keys, data={"1":1}, orderby = "book_id asc", num = None)
    return books

all_books = get_all_books()

for book in tqdm(all_books):
    b = {}
    b["book_id"] = book[0]
    b["book_name"] =book[2]
    b["book_author"] = book[3]
    b["book_ori_author"] = book[4]
    b["book_isbn"] = book[5]
    all_links = get_links(b)
    if not all_links:
        continue
    #print(all_links)
    saved_links={}
    for link in all_links:
        link_id = link["link_id"]
        if link_id in saved_links:
            continue
        saved_links[link_id] = link_id
        link_name = link["link_name"]
        flag = book_util.is_book(link_name, b["book_name"], b["book_author"], b["book_isbn"])
        if flag:
            print(f"book_name={b["book_name"]}, link_name = {link_name}, link_id={link_id}")


