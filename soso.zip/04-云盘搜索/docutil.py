import urllib.parse
from bs4 import BeautifulSoup
import fileutil
import io
import sys
import htmlutil
import urlutil
import html
import re
import json
import stringutil
from unidecode import unidecode
import nltkutil
import isbnutil


# 判断标题是否是单一句子
def isPureValidTitle(title, doc_type='pdf'):
    title_temp = title.replace("|", " - ")
    title_temp = title_temp.replace("⋙", " - ")
    title_temp = title_temp.replace(">>", " - ")

    title_arr = title_temp.split(" - ")
    title_len = len(title_arr)
    if (title_len > 1):  # 如果一个标题中存在" - ",则说明不合法
        return False
    else:
        return True


# 是否是一个合法的标题
def isValidTitle(title, strict=True, doc_type='pdf', word_min_num=3):
    title = title.strip()
    if (title == ""):
        return False
    # 是否包含非英文字符，如果包含，比如中文，则认为是非法的
    if stringutil.containsNonAscii(title):
        return False
    if strict:  # 允许超过长度
        if (title.endswith("..")):
            return False
        if title.count('..') > 0:
            return False
    else:
        if '..' in title:
            tx = title.split(" ")  # 安装空格进行判断
            if len(tx) < word_min_num:  # 必须包含至少5个单词？
                return False
    # isbn，如果标题中包含了isbn，则非法
    if stringutil.containISBN(title):
        return False

    title = title.lower()
    title_temp = stringutil.removeSymbol(title)
    title_arr = title_temp.split(" ")
    # 如果标题中包含这些单词，则非法
    invalid_arr = ['preview', 'pdf', 'chapter', 'download', 'docs', 'document', 'documents', 'ebook', 'e-book',
                   'ebooks', 'e-books', 'book', 'books', "online", "free", "paper", "papers"]
    for invalid in invalid_arr:
        if invalid in title_arr:
            return False

    dotnum = title.count("?");
    if dotnum >= 2:
        return False
    dotnum = title.count("!");
    if dotnum >= 2:
        return False

    invalid_arr = ["free", 'download', 'full', 'text', 'file', 'fulltext', 'view', "kb", "mb", "[", "]", "epub", "book",
                   "mobi", "chm", 'read', 'find', 'online', "document", "click", "now", "right", "pdf", "word", "txt",
                   "xls", "ppt", "doc", "pptx", "docx", "xlsx", "epub", "mobi"]
    num = 0;
    for invalid in invalid_arr:
        if invalid in title_arr:
            num = num + 1
    if num >= 1:
        return False
    # word_min_num = 3
    num = 0
    title_arr = title.split(" ")
    for t in title_arr:
        if len(t) >= 2:
            num += 1
    if num < word_min_num:
        return False
    #
    if strict:
        if title.count('(') != title.count(')'):
            return False

        if title.count('[') != title.count(']'):
            return False
        #
        if title.count('"') % 2 != 0:
            return False

    #
    ends_arr = ["even if", "whether", "if", "who", "what", "when", "where", "why", "how", "and", "then", "that",
                "those", "whose", "which", "is", "are", "was", "were", "it", "we", "our", "he", "she", "that", "they",
                "those", "these", "this", "him", "her", "his", "their", "there", "its", "some", "any", "also", "how",
                "when", "where", "why", "which", "who", "whose", "as", "because", "if", "whether", "what", "i", "it",
                "he", "she", "you", "your", "me", "him", "her", "that", "they", "those", "these", "this", "his",
                "their", "there", "its", "some", "any", "also", "my", "but", "although", "however", "is", "was", "am",
                "were", "not", "yes", "none", "few", "little", "much", "many", "are",
                "with", "at", "from", "into", "during", "including", "until", "against", "among", "throughout",
                "despite", "towards", "upon", "concerning", "to", "in", "for", "on", "its", "by", "about", "like",
                "beyond", "behind", "across", "following", "along", "within", "under", "without", "since", "after",
                "between", "before", "over", "plus", "except",
                "but",
                "and",
                "a",
                "in",
                "for",
                "will",
                "would",
                "far",
                "can",
                "like",
                "may",
                "though",
                "get",
                "plenty",
                "may be",
                "might",
                "whereas",
                "nowadays",
                "unit",
                "ready",
                "less",
                "unless",
                "nor",
                "or",
                "need",
                "been",
                "unlike",
                "could",
                "shall",
                "have",
                "has",
                "had",
                "fully",
                "then",
                "here",
                "one",
                "more",
                "much",
                "little",
                "less",
                "many",
                "one",
                "all",
                "us",
                "our",
                "own",
                "me",
                "most",
                "so",
                "such",
                "we",
                "than",
                "below",
                "only",
                "besides",
                "beside",
                "by",
                "got",
                "just",
                "very",
                "often",
                "usually",
                "well",
                "should",
                "being",
                "be",
                "great",
                "few",
                "still",
                "do",
                "dose",
                "too",
                "also",
                "else",
                "did",
                "other",
                "least",
                "another",
                "even",
                "others",
                "along",
                "again",
                "always",
                "each",
                "every",
                "something",
                "anyting",
                "none",
                "nothing",
                "yet",
                "thus",
                "weekly",
                "daily",
                "due",
                "a",
                "an",
                "the",
                "near",
                "above",
                "off",
                "whole",
                "around",
                "mine",
                "anybody",
                "nothing",
                "certain",
                "same",
                "self",
                "yourself",
                "someone",
                "itself",
                "themselves",
                "yours",
                "whoever",
                "whenever",
                "whichever",
                "wherever",
                "whatever",
                "nobody",
                "none",
                "himself",
                "herself",
                "myself",
                "really",
                "early",
                "never",
                "likely",
                "simply",
                "together",
                "generally",
                "instead",
                "actually",
                "rather",
                "almost",
                "especially",
                "specially",
                "probably",
                "therefore",
                "already",
                "probably",
                "quickly",
                "fastly",
                "slowly",
                "eventually",
                "exactly",
                "certainly",
                "normally",
                "owner",
                "currently",
                "extremely",
                "finally",
                "constantly",
                "properly",
                "soon",
                "immediately",
                "highly",
                "daily",
                "ahead",
                "either",
                "done",
                "relatively",
                "primarily",
                "completely",
                "fairly",
                "ultimately",
                "widely",
                "recently",
                "lot",
                "once",
                "no one",
                "everyone",
                "everybody",
                "ever",
                "briefly",
                "one",
                "as",
                "now",
                "hardly",
                "suddenly",
                "truly",
                "later",
                "quit",
                "please",
                "somewhere",
                "anywhere",
                "nowhere",
                "yeah",
                "please",
                "onto",
                "into",
                "out",
                "out of",
                "ago",
                "upon",
                "somehow",
                "away",
                "both",
                "doing",
                "quite",
                "last",
                "next",
                "finally",
                "whys",
                "hows",
                "whos",
                "whats",
                "whichs",
                "wheres",
                "whys",
                "whens",
                "no",
                "hi",
                "'s",
                "of",
                "&#x27;s"
                "somebody"]
    for e in ends_arr:
        if title.endswith(" " + e):
            return False
    start_arr = ["in", "into", "not", "and", "to", "about", "or", "of", "with", "at", "by", 'pdf', 'read', 'book',
                 doc_type]
    for s in start_arr:
        if title.startswith(s + " "):
            return False
    return True


# 修复标题
def afterFixTitle(title, doc_type='pdf'):
    title_origintal = title
    title = fixTitle(title)
    #
    # specail string
    title = stringutil.replace(r' About Packt Publishing', '', title)
    title = stringutil.replace(r' Packt Publishing Ltd', '', title)

    # deep learning ...

    # title array
    title_temp = title.replace("|", " - ")
    title_temp = title_temp.replace("⋙", " - ")
    title_temp = title_temp.replace(">>", " - ")

    title_arr = title_temp.split(" - ")  # 选择长的
    title_len = len(title_arr)
    if (title_len >= 2):
        last = title_len - 1
        t_end = title_arr[last]
        if (t_end.endswith('...')):  # remove
            t_len_len = len(t_end)
            t_start_arr = title_arr[0: title_len - 1]
            t_start = ' - '.join(t_start_arr)
            t_start = t_start.strip()
            t_start_len = len(t_start)
            if t_start_len >= t_len_len:  # 说明去除了...部分后，前面一部分仍然较长
                return t_start
            else:
                return title
    return title


# 修复以格式结尾的
def fixTitle(title, doc_type='pdf'):
    # 修复文件大小
    pattern = re.compile(r'[0-9]{1,}[ ]{0,}mb', re.I)
    title = re.sub(pattern, ' ', title)
    pattern = re.compile(r'[0-9]{1,}[ ]{0,}kb', re.I)
    title = re.sub(pattern, ' ', title)

    endpoint = "." + doc_type
    title_temp = title.lower()
    if title_temp.endswith(endpoint):
        l = len(endpoint)
        title = title[0: -l]
    endpoint = " " + doc_type
    if title_temp.endswith(endpoint):
        l = len(endpoint)
        title = title[0: -l]
    pattern = re.compile(r'[ ]{2,}')
    title = re.sub(pattern, ' ', title)
    return title.strip()




# 获取链接标题
def getLinkTitle(search_key, link_name, link_content, link_url, doc_type='pdf'):
    print("----new----")
    root = urlutil.getRootURL(link_url)
    domain = root[1]

    link_name = html.unescape(link_name)

    link_name = stringutil.replace("[" + doc_type + "]", "", link_name)
    link_name = stringutil.replace("(" + doc_type + ")", "", link_name)
    link_name = stringutil.replace("{" + doc_type + "}", "", link_name)
    link_name = stringutil.replace("【" + doc_type + "】", "", link_name)
    link_name = stringutil.replace("（" + doc_type + "）", "", link_name)

    # 修复标题
    link_name = fixTitle(link_name)
    # remove blank
    pattern = re.compile(r'[ ]{2,}')
    link_name = re.sub(pattern, ' ', link_name)
    link_name = link_name.strip()

    # ----------
    link_content = link_content.replace("<b>", "<em>")
    link_content = link_content.replace("</b>", "</em>")
    link_content = link_content.replace("<i>", "<em>")
    link_content = link_content.replace("</i>", "</em>")
    link_content = link_content.replace("<strong>", "<em>")
    link_content = link_content.replace("</strong>", "</em>")

    em_arr = htmlutil.getTags(link_content, tag='em')
    valid_em_arr = []  # 保存合法的重点词
    if len(em_arr) < 1: #不存在
        em_arr = [x for x in search_key.split(" ") if len(x) > 2 and " "+x.lower()+" " in " "+link_name.lower()+" " ]
    if em_arr:
        em_str = " ".join(em_arr)
        em_str = html.unescape(em_str)
        ###
        em_str = stringutil.removeSymbol(em_str)
        ###
        em_str = re.sub(pattern, ' ', em_str)
        em_str = em_str.strip()
        # print(em_str)
        # em_arr = em_str.split(" ")
        em_arr = nltkutil.lemmatize_sentence(em_str) + em_str.split(" ")
        # print(em_arr)
        # exit(0)

        invalid_arr = ["free", "download", "books", 'docs', 'document', "and", "the", "book", "for", "with", "without", "about",
                       ".com", "or", ".org", ".net", ".hk", ".au", ".it", ".io", ".info", ".ca", ".edu", doc_type]


        for em_string in em_arr:
            # print(em_string)
            em_string = em_string.strip()
            em_string = em_string.lower()
            if len(em_string) < 3:
                continue
            if em_string in invalid_arr:
                continue

            if em_string in domain:
                continue

            if stringutil.isAllNumber(em_string):
                continue
            # contain a-z
            if not stringutil.containsEnglishChar(em_string):
                continue

            if em_string not in valid_em_arr:
                valid_em_arr.append(em_string)

    # title contains <em></em>
    print("valid_em_arr =",valid_em_arr)
    # title array
    link_name = link_name.replace("|", " - ")
    link_name = link_name.replace("⋙", " - ")
    link_name = link_name.replace(">>", " - ")

    title_arr = link_name.split(" - ")

    temp_title_arr = []
    for x in title_arr:
        xt = stringutil.removeEmpty(x,True)
        xt = xt.replace(" ","")
        xt = stringutil.removeSymbols(xt)
        if xt.strip().lower() not in domain:
            temp_title_arr.append(x)
    title_arr = temp_title_arr
    # 如果没有重点词
    if len(valid_em_arr) < 1:
        link_name = " - ".join(title_arr)
        link_name = link_name.strip()

        if isPureValidTitle(link_name):  # 如果是单一句子标题
            if isValidTitle(link_name, strict=False): #不严格
                return link_name, 200  # 有效
            else:
                return link_name, -200  #
        else:
            return link_name, 1



    # end to start
    index_end = -1
    title_len = len(title_arr)
    for i in range(title_len):
        index = title_len - 1 - i  # 从倒数第二个开始？
        temp_title = title_arr[index]
        #
        temp = stringutil.removeSymbol(temp_title)
        temp_title = temp_title + ". " + temp
        temp_title = temp_title.lower()
        # temp_title_arr = temp_title.split(" ")
        temp_title_arr = nltkutil.lemmatize_sentence(temp_title)
        # print('em arry')
        # print(valid_em_arr)
        # print('end title arry')
        # print(temp_title_arr)

        for valid_em in valid_em_arr:
            if valid_em in temp_title_arr:
                index_end = index
                break
        if index_end != -1:
            break
    print("index end = " + str(index_end))
    index_start = -1
    for i in range(title_len):
        index = i
        temp_title = title_arr[index]
        #
        temp = stringutil.removeSymbol(temp_title)
        temp_title = temp_title + ". " + temp
        temp_title = temp_title.lower()
        # temp_title_arr = temp_title.split(" ")
        temp_title_arr = nltkutil.lemmatize_sentence(temp_title) + temp_title.split(" ")
        # print('em arry')
        # print(valid_em_arr)
        # print('start title arry')
        print("temp_title_arr",temp_title_arr)
        for valid_em in valid_em_arr:
            if valid_em in temp_title_arr:
                index_start = index
                break
        if index_start != -1:
            break
    print("index start = " + str(index_start))

    # return valid title
    if index_start >= 0 and index_end >= 0 and index_end >= index_start:
        title = title_arr[index_start: index_end + 1]
        # may be java - java...
        title_len = len(title)
        if title_len > 1:
            end_title = title[title_len - 1]
            #
            pattern = re.compile(r'[^a-zA-Z0-9\-\.]{1,}')
            end_title = re.sub(pattern, '', end_title)

            if end_title.lower() in domain:
                title = title_arr[index_start: index_end]

        valid_title = " - ".join(title)
        valid_title = valid_title.strip()
        valid_title = afterFixTitle(valid_title)
        if isValidTitle(valid_title, strict=False):
            return valid_title, 100  # 真正的标题 ---有效
        else:
            return valid_title, -100  # REST with Spring ebook
    return link_name, 2
    # check the end


def isBook(link_desc):
    # 去除html标记
    link_desc = htmlutil.filter_tags(link_desc)
    link_desc = link_desc.lower()
    link_desc = link_desc.replace(":", " ")
    link_desc = link_desc.replace("-", " ")

    link_desc = stringutil.removeSymbol(link_desc)

    link_desc = " " + link_desc

    if "isbn" in link_desc:
        isbn_list = isbnutil.getValidISBN(link_desc)
        if len(isbn_list) >= 0:
            return True

    return False
#(search_key, link_name, link_content, link_url, doc_type='pdf'):
link_content = "fears and desires in search of power at any cost. November 2020. History / Politics. Royal hardback. 320pp £20. ISBN 978 1 78816 123 7."
link_url = "https://profilebooks.com/wp-content/uploads/2021/02/LOW-RES-Profile-SPRING-2021-UK-Catalogue-SMALL.pdf"
x = getLinkTitle(" [PDF] A Scheme of Heaven - Profile Books", " [PDF] A Scheme of Heaven - Profile Books", link_content, link_url)
print(x)
#sx = 'deep neural networks are applied to image denoising and speech recognition. Keywords Deep Learning, Neural Networks, Multilayer Perceptron, Probabilistic Model, Restricted Boltzmann Machine, Deep Boltzmann Machine, Denoising Autoencoder ISBN (printed) 978-952-60-5574-9 ISBN …'
#print(isBook(sx))