# -*- coding:utf-8 -*-
import urllib
import brotli
import re
import ssl
print("load model over")

def filter_tags(htmlstr):
    htmlstr = htmlstr.strip()
    re_cdata=re.compile('//<!\[CDATA\[[^>]*//\]\]>',re.I) #匹配CDATA
    re_script=re.compile('<\s*script[^>]*>[^<]*<\s*/\s*script\s*>',re.I)#Script
    re_style=re.compile('<\s*style[^>]*>[^<]*<\s*/\s*style\s*>',re.I)#style
    re_br=re.compile('<br\s*?/?>')#处理换行
    re_h=re.compile('</?\w+[^>]*>')#HTML标签
    re_comment=re.compile('<!--[^>]*-->')#HTML注释
    blank_line=re.compile('\n+')

    #过滤匹配内容
    s=re_cdata.sub('',htmlstr)#去掉CDATA
    s=re_script.sub('',s) #去掉SCRIPT
    s=re_style.sub('',s)#去掉style
    s=re_br.sub('\n',s)#将br转换为换行
    s=re_h.sub('',s) #去掉HTML 标签
    s=re_comment.sub('',s)#去掉HTML注释
    s=blank_line.sub('\n',s)#去掉多余的空行

    return s
def filterBlank(str):
    b = re.compile(r'\s{2,}')
    str = b.sub('', str)
    b = re.compile(r'[\r\n\f]{1,}')
    str = b.sub('', str)
    str = str.strip()
    return str

def getcontent(crawl_response):
    #print(crawl_response.getheaders())
    content = crawl_response.read()
    
    encoding = crawl_response.getheader("Content-Encoding")
    #charest and content_type
    message = crawl_response.info()
    content_type = message.get_content_type()
    if content_type != 'text/html':
        pass
    
    if not encoding:
        pass
    
    try:
        if encoding == 'br':
            import brotli
            content = brotli.decompress(content)
            
        if encoding == 'gzip':
            import gzip
            content = gzip.decompress(content)
    except Exception as e:
        print(e)
        
        #charset
    charset = None
    charset = message .get_content_charset(None)
    if not charset:
        charset = message.get_charsets(None)
        if not charset:
            import chardet
            result=chardet.detect(content)
            charset=result['encoding']
        else:
            charset = charset[0]
    if not charset: # default set utf-8
        charset = 'utf-8'    
       # print(content)

       
    content = content.decode(charset)
        
    if charset != 'utf-8':# convert utf-8
        content = content.encode('utf-8', errors='ignore').decode("utf-8")
    return content
    

def getRequestOpener(url, cookie = False):
    opener = None
    if cookie :
        cookie = http.cookiejar.CookieJar()
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie))
    else:
        opener = urllib.request.build_opener()
    headers = []
    headers.append(('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'))
    headers.append(('Accept-Encoding', 'gzip, deflate, br'))
    headers.append(('Accept-Language', 'zh-CN,zh;q=0.9'))
    headers.append(('Cache-Control', 'max-age=0'))
    headers.append(('Referer', getRootURL(url)))
    headers.append(('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'))
    
    opener.addheaders = headers
    return opener



def networkIsOnline():
    class CustomHTTPRedirectHandler(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, hdrs, newurl):
            return None
        
    def getRequestOpener():
        redirectHandler = CustomHTTPRedirectHandler()
        context=ssl._create_unverified_context()  
        sslHandler = urllib.request.HTTPSHandler(context=context)
       
        opener = urllib.request.build_opener(redirectHandler,sslHandler)
            
        headers = []
        headers.append(('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'))
        headers.append(('Accept-Encoding', 'gzip, deflate, br'))
        headers.append(('Accept-Language', 'zh-CN,zh;q=0.9'))
        headers.append(('Cache-Control', 'max-age=0'))
        headers.append(('Referer', 'https://www.google.com/'))
        headers.append(('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'))
        
        opener.addheaders = headers
        
        return opener

    sites = ['https://www.163.com/','https://www.taobao.com/','https://www.facebook.com/','https://www.ebay.com/',  'https://ww.baidu.com/', 'https://www.jd.com/', 'https://www.stackoverflow.com','https://www.amazon.com/']
    online = False    
    for crawl_url in sites:
        print("check url = " + crawl_url)
        opener = getRequestOpener()
        crawl_response = None
        try:
            #ignore ssl        
            crawl_response = opener.open(crawl_url, timeout = 30)
        except Exception as e:
            print(e)
            crawl_response = None
        if not crawl_response:
            online = False
            continue
        crawl_response_code = crawl_response.getcode()
        if crawl_response_code == 200:   
            try:
                content = getcontent(crawl_response)
            except Exception as ex:
                online = False
                continue
            content = filter_tags(content)
            content = filterBlank(content)
            if len(content) > 800:
                online =  True
                break
            else:
                online = False
        else:
            online = False
    return online
    
'''online = networkIsOnline()
if not online:
    print("network is offline")
else:
    print("network is online")'''


    
    

