import sys, fitz
from bs4 import BeautifulSoup
import re
import html
import stringutil

def containsDate(title):
    d = ['January', 'Jan', 'February', 'Feb', 'March', 'Mar', 'AprilAPR', 'Apr', 'May', 'May', 'June', 'Jun', 'July', 'Jul', 'August', 'Aug', 'September', 'Sep', 'October', 'Oct', 'November', 'Nov', 'December', 'Dec']
    
    dr = re.compile(r'[^0-9a-zA-Z]',re.S)
    title = dr.sub(' ',title)
    
    title = " "+title+" "
    
    for i in range(1900,2022):
        i = " "+str(i) + " "
        if i in title:
            for dx in d:
                dx = " "+dx.lower()+" "
                if dx in title:
                    return True
    return False
def isAllNumber(title):
    dr = re.compile('[0-9\- %\.\+]{1,}',re.S)
    temptitle = dr.sub('',title)
    temptitle=temptitle.strip()
    if temptitle == "":
        return True
    return False
    
def isValidTitle(title):
    dr = re.compile(r'[^0-9a-zA-Z]{1,}',re.S)
    temptitle = dr.sub('',title)
    if temptitle == "":
        return False
    if isAllNumber(title):
        return False
    
    title = title.lower()
    tag ='table of content'
    if tag in title:
        return False
    if 'about' in title and 'author' in title:
        return False
    valid_words = ['arXiv:','<img','. . . . . . . .', 'contents at a glance']
    for w in valid_words:
        if w.lower() in title:
            return False
    if containsDate(title):
        return False
    return True

def getfontsize(html):
    pattern = r'font-size:([0-9.]{1,20})pt;'
    #re.match(pattern, html, re.I)
    matcher = re.findall(pattern, html, re.I)  
    sizes = []
    if not matcher:
        return None  
    sizes = [float(i) for i in matcher]
    return list(set(sizes))

def parserpage(page, font_size):
    page = deleteAllAnnotations(page)
    html_data = page.getText("html")
    return parser(html_data, font_size)
    
def parser(html_data, font_size):
    #print(html_data)
    html_data = html_data.encode("utf-8")
    soup = BeautifulSoup(html_data, 'html.parser')
    spans = soup.find_all("span")
    #print(spans)
    result = []
    max_lines = 5
    first_line = -1
    second_line = 0
    title_count = 0
    for s in spans:
        if not s:
            continue
        font1 = 'font-size:'+str(font_size)+'pt;' 
        font2 = 'font-size:'+str(int(font_size))+'pt;'        
        htmlstr = str(s)
        #print(htmlstr)
        
        if font1 in htmlstr or font2 in htmlstr:
            if first_line <= max_lines:
                result.append(htmlstr)
                first_line = 0
                title_count+=1
            else:
                break
        if first_line != -1:
            first_line += 1
            
    #print(result)
    if title_count > 10:
        return ""
    title = " ".join(result)
    title = removeHTML(title)
    title = title.strip()
    return formatTitle(html.unescape(title))

def removeHTML(html):
    dr = re.compile(r'<[^>]+>',re.S)
    dd = dr.sub('',html)
    return dd
def formatTitle(title):
    dr = re.compile(r'[ ]{2,}',re.S)
    dd = dr.sub(' ',title)
    return dd.strip()
def deleteAllAnnotations(page):
    first_annotation = page.firstAnnot
    while first_annotation:
        page.deleteAnnot(first_annotation)
        first_annotation = page.firstAnnot
    return page

def getPdfTitle(file_pdf, min_pages = 10):
    pdf = file_pdf
    doc = fitz.open(pdf)
    max_num = min_pages
    num = 0
    
    max_font_sizes = []
    html_data = ''
    pages = []
    for page in doc:
        page = deleteAllAnnotations(page)
        html_text = page.getText("html")
        html_data += html_text
        sizes = getfontsize(html_text)
        if sizes:
            max_font_sizes.extend(sizes)
        num+=1
        pages.append(page)
        if num >=max_num:
            break
        
    #print(html_data)  
    titles = []  
    if max_font_sizes:
        max_font_sizes = list(set(max_font_sizes))
        max_font_sizes.sort(reverse=True)
        #t = sorted(max_font_sizes, reverse=True)
        max_font_sizes = max_font_sizes[0:30]
        print(max_font_sizes)
        flag = False
        for i in range(len(max_font_sizes)):
            if flag:
                break
            font_size = max_font_sizes[i]
            for page in pages:
                title = parserpage(page, font_size)
                #print(title)
                tx = title.split()
                num_words = 0
                for txx in tx:
                    if len(txx)>1:
                        num_words += 1
                if num_words >= 3:
                    if isValidTitle(title):
                        if title not in titles:
                            #print(title)
                            titles.append(title)
                            flag = True
                            break
                    #else:
                        #print("invalid title="+title)
    doc.close()        
            
    if titles:
        #print('titles=')   
        #print(titles[0])
        return titles[0]
    else:
        print('no title extract')
    return None

def getPDFTitleUse(file_pdf, pages=[4,6,8,10]):
    titles = []
    for page_num in pages:
        title = getPdfTitle(file_pdf, min_pages = page_num)
        if title:
            if title in titles:
                return title
            else:
                titles.append(title)
    if titles:
        return titles[0]
    return None
def getPdfTitleWithBased(file_pdf, base_title = None, min_pages = 10):
    if not base_title:
        return getPDFTitleUse(file_pdf)
    # remove ...
    endpoint = "..."
    #print(base_title)
    if base_title.endswith(endpoint):
        l = len(endpoint)
        base_title = base_title[0: -l]  
        #print(base_title)
    #base_title = html.escape(base_title)  
    tag_base_title = base_title.lower()
    tag_base_title = stringutil.removeEmpty(tag_base_title)
    tag_base_title = stringutil.onlyRemainAZ(tag_base_title)
    print(tag_base_title)
    ####
    pdf = file_pdf
    doc = fitz.open(pdf)
    max_num = min_pages
    num = 0
    
    max_font_sizes = []
    html_data = ''
    pages = []
    for page in doc:
        page = deleteAllAnnotations(page)
        html_text = page.getText("text")
        html_data += html.unescape(html_text)
        
        num+=1
        pages.append(page)
        if num >=max_num:
            break
    htmls = html_data.split('\n')
    print(htmls)
    for str in htmls:
        
        str_temp = str.lower()
        str_temp = stringutil.onlyRemainAZ(str_temp)
        if str_temp.count(tag_base_title) > 0:
            return str
    # if not in a line
    title_res = ''
    index_start = -1
    index_t_start = 0
    for str in htmls:
        index_start = index_start +1
        
        str_temp = str.lower()
        str_temp = stringutil.onlyRemainAZ(str_temp)
        if str_temp == '':
            continue
        if tag_base_title.count(str_temp) > 0:
            title_res = title_res + " " + str
            index_t_start = index_t_start + 1
            print(title_res)
        else:
            # res+str
            temp_str = title_res + " " +str
            temp_str = temp_str.lower()
            temp_str = stringutil.onlyRemainAZ(temp_str)
            if temp_str.count(tag_base_title):
                t = title_res + " " +str
                title_res = stringutil.removeEmpty(t)
                break
            else:
                title_res = title_res.strip()
                temp_res = title_res.lower()
                temp_res = stringutil.onlyRemainAZ(temp_res)
                if (len(temp_res) / len(tag_base_title)) < 0.9:
                    title_res = ''
                    index_t_start = 0
                else:
                    break
                    
    #print(html_data)
    if title_res:
        title_res_2 =  getPDFTitleUse(file_pdf)
        print(title_res_2)
        temp_str = title_res_2.lower()
        temp_str = stringutil.onlyRemainAZ(temp_str)
            
        temp_str_2 = title_res.lower()
        temp_str_2 = stringutil.onlyRemainAZ(temp_str_2)
        
        if temp_str.count(temp_str_2) and (len(temp_str_2)/len(temp_str)>0.8):
            title_res = title_res_2
        
    return stringutil.removeEmpty(title_res)
'''file_pdf=r"F:\PDF-Documents\Waiting-for-Process-Books\124845.pdf" 

  
title_use = getPDFTitleUse(file_pdf)
print("title_use="+title_use)'''