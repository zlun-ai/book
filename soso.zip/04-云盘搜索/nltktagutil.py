import nltk
#nltk.download('wordnet')
#nltk.download('punkt')
from nltk.stem import WordNetLemmatizer
from nltk import word_tokenize, pos_tag, sent_tokenize
from nltk.corpus import wordnet
import sys, fitz
import stringutil
import re
import tagdb
import fileutil

TYPE_CAN = 'can'
TYPE_IS_ARE = 'is'
type_USE = 'use'

def isValidTag(t):
    t = t.strip()
    pattern = r'[^A-Z0-9a-z\.\-#\+&%$ ]{1,}'
    temp = re.sub(pattern, "", t)
    temp = temp.strip()
    if len(temp) != len(t):
        return False
    
    if len(t) <3:
        return False
    #.9604 .9409 .9216 .9025 .8836 .8649 .8464
    pattern = r'[0-9\.\-#\+&%$ ]{1,}'
    temp = re.sub(pattern, "", t)
    temp = temp.strip()
    if len(t) == 0:
        return False
    
    #--------------
    first = t[0]
    if first == '+' or first == '%' or first == '#' or first == '-' or first == '$' or first == '&':
        return False
    last = t[-1]
    if last == '-' or last == '$' or last == '&' or last == '%' or last == '.':
        return False
    
    first = t[0:2]
    if first == 'A ' :
        return False
    return True


def nn_in_sentence(sentence):
    tags = []
    ws = []
    pre_pos = ''
    type = ''
    for word, pos in pos_tag(word_tokenize(sentence)):
        if pos =='NNP':# or pos =='NN':
            ws.append(word)
        else:
            if len(ws) > 0 and (word == 'is' or word == 'are') :#(pos == 'MD' or (word == 'is' or word == 'are')):
                '''if pos == 'MD':
                    type = TYPE_CAN'''
                if word == 'is' or word == 'are':
                    type = TYPE_IS_ARE
                    
                t = " ".join(ws)
                if isValidTag(t) :#and type !='':
                    
                    if t not in tags:
                        tags.append((t,type))
                        #print(t + "   <=>   " +sentence)
            ws = []
    return tags
def getAllPDFPages(file):
    doc = None
    try:
        doc = fitz.open(file) 
    except Exception as e:
        print(e)
        if doc:
            doc.close()
        return  None,[]
    pages = []
    print(doc.pageCount)
    i = 0
    for i in range(doc.pageCount):
        try:
            pages.append(doc[i])
        except Exception as e:
            print("page = " + str(i))
            print(e)
    return doc,pages
def extractTagFromText(text, bookmarks):
    sens = sent_tokenize(text)
    for sen in sens:
        nn = nn_in_sentence(sen)
        if not nn:
            continue
        #print(nn)
        for n in nn:
            if n[0] in bookmarks:
                print(n)
                tagdb.addTag(n[0], n[1])
def getPDFPageText(page):
    text = page.getText()
    text = stringutil.removeEmpty(text)
    return text

def getTagFromPdf(f):
    doc,pages = getAllPDFPages(f)
    if not pages:
        return None
    toc = doc.getToC(simple = True)
    if len(toc) < 1:
        return
    bookmarks = ''
    for b in toc:
        bookmarks = bookmarks + " , " + b[1]
    for page in pages:
        text = getPDFPageText(page)
        #print(text)
        extractTagFromText(text, bookmarks)
        #break

    
def get_wordnet_pos(treebank_tag):
    if treebank_tag.startswith('J'):
        return wordnet.ADJ
    elif treebank_tag.startswith('V'):
        return wordnet.VERB
    elif treebank_tag.startswith('N'):
        return wordnet.NOUN
    elif treebank_tag.startswith('R'):
        return wordnet.ADV
    else:
        return None


#nnp 专有名词，单数形式 NNPS 复数形式
#常用名词 单数形式NN
#can:MD 情态助动词

#s = 'asp.net can speed up your site developoment'
#print(sentence_pos(s))
    
def lemmatize_sentence(sentence):
    res = []
    lemmatizer = WordNetLemmatizer()
    # get word and its pos
    for word, pos in pos_tag(word_tokenize(sentence)):
        wordnet_pos = get_wordnet_pos(pos) or wordnet.NOUN
        res.append(lemmatizer.lemmatize(word, pos=wordnet_pos))

    return res
s  ='Working with Scalable Vector Graphics'
#s = 'Python for Beginners'
#print(pos_tag(word_tokenize(s)))
#print(lemmatize_sentence('done'))

d='F:\\www.all-pdf.com\\67-Head-First-jQuery.pdf'
d = r'G:\1701.01574.pdf'
#getTagFromPdf(d)

dir = "F:\\google-pdf\\"
#dir = "F:\\PDF-Documents\\Standard-Books\\2\\" 

files = fileutil.traverseDir(dir, file_type = '.pdf')
print("files="+str(len(files)))
for f in files:
    print(f)
    getTagFromPdf(f)