import urllib.parse
import fileutil
import stringutil
import jieba
from collections import Counter
import re

def tokenize(text):
    # 简单分词：英文按空格，中文可使用 jieba（如果需要）
    return text.split()
def remove_date(text):
    pattern = re.compile(r'[0-9\-/]{5,}', re.IGNORECASE)
    text = re.sub(pattern, '', text)
    text = text.strip()

    pattern = re.compile(r'[\-]{2,}', re.IGNORECASE)
    text = re.sub(pattern, '-', text)
    text = text.strip()

    return text
def get_valid_book_name(file_name):
    file_name = file_name.strip()

    arr = [".pdf", ".epub", ".mobi",".azw3",".chm",".txt"]
    flag = False
    for a in arr:
        if file_name.lower().endswith(a):
            flag = True
            file_name = file_name.split(".")[0:-1]
            file_name = ".".join(file_name)  # 去除后缀
            break
    if not flag:
        return ""
    file_name = remove_date(file_name)
    if file_name == "":
        return ""

    # 修复序号
    first = file_name[0]
    if stringutil.isAllNumber(first):
        pattern = re.compile(r'^[0-9]{1,3}[ ]{0,}[\.。，、\-：]{1,}', re.IGNORECASE)
        file_name = re.sub(pattern, '', file_name)
        file_name = file_name.strip()

    file_name = stringutil.removeEmpty(file_name, True)
    return file_name

def is_book_name(file_name):
    #

    file_name = file_name.strip()
    file_name = get_valid_book_name(file_name)
    if file_name == "":
        return False

    file_name = file_name.strip()
    # 全部是数字的不是
    if stringutil.isAllNumber(file_name):
        return False
    file_name = stringutil.getStringSlug(file_name)
    temp = file_name.replace(" ","")
    #print(temp)
    #如果包含了
    # 情况1：去除所有非
    if stringutil.count_chinese_characters(file_name) >= 4:
        return True
    else:
        return False

    no_abc = stringutil.remove_non_ascii(file_name, " ")
    no_abc = no_abc.strip()

    nx = no_abc.split(" ")
    ax =[a.strip() for a in nx if len(a.strip())>2 and not stringutil.isAllNumber(a.strip())]
    if len(ax) >= 3:
        return True
    return False

    #
def get_ngrams(text, n):
    tokens = tokenize(text)
    ngrams = []
    for i in range(len(tokens) - n + 1):
        ngram = ' '.join(tokens[i:i + n])  # 使用空格连接，也可以用 tuple
        ngrams.append(ngram)
    return Counter(ngrams)  # 返回词频统计


def jaccard_similarity(set1, set2):
    intersection = set(set1.keys()) & set(set2.keys())
    union = set(set1.keys()) | set(set2.keys())
    return len(intersection) / len(union) if union else 0.0


def ngram_similarity(text1, text2, n=2):
    ngrams1 = get_ngrams(text1, n)
    ngrams2 = get_ngrams(text2, n)

    #print(f"Text1 {n}-grams:", ngrams1)
   # print(f"Text2 {n}-grams:", ngrams2)

    sim = jaccard_similarity(ngrams1, ngrams2)
    return sim
def fix_number(text):
    n = "零一二三四五六七八九十"
    for i in range(0, 11):
        text = text.replace(str(i),n[i])
    return text
def get_clean(filename, sep = " "):
    filename = stringutil.getStringSlug(filename)

    seg_list = jieba.cut(filename, cut_all=False)
    seg_list = [x.strip() for x in seg_list if x.strip() != ""]
    seg = sep.join(seg_list)
    seg = seg.strip()
    return seg

#完全匹配时才是
def check_book_by_full_match(valid_file_name, book_name):
    #print(f"判断{valid_file_name} 与 {book_name} 是否完全匹配...")
    clean_file_name = get_clean(valid_file_name, "").lower()
    clean_book_name = get_clean(book_name, "").lower()
    if clean_file_name=="" or clean_book_name=="":
        return False
    if clean_file_name == clean_book_name:
        return True
    return False
def check_book_by_in(valid_file_name, book_name):
    #print(f"判断{valid_file_name} 与 {book_name} 是否字符串包含...")
    clean_file_name = get_clean(valid_file_name, "").lower()
    clean_book_name = get_clean(book_name, "").lower()
    if clean_file_name=="" or clean_book_name=="":
        return False

    if clean_file_name in clean_book_name: #or clean_book_name in clean_file_name:
        # 必须
        n = len(clean_file_name) / len(clean_book_name)
        if len(clean_file_name) > 10:
            if n>=0.8:
                return True
        else:
            if clean_book_name.startswith(clean_file_name):
                if n > 0.8:
                    return True
    #---
    if clean_book_name in clean_file_name:
        n = len(clean_book_name) / len(clean_file_name)
        if len(clean_book_name)>10:
            if n >= 0.8:
                return True
        else:
            if clean_file_name.startswith(clean_book_name):
                if n >= 0.8:
                    return True
    return False
#
def check_book_by_fenci_in(valid_file_name, book_name):
    #print(f"判断{valid_file_name} 与 {book_name} 是否完全分词包含...")
    clean_file_name = get_clean(valid_file_name, " ").lower()
    clean_book_name = get_clean(book_name, " ").lower()
    if clean_file_name=="" or clean_book_name=="":
        return False

    fx = clean_file_name.split()
    fn = len(fx)
    bx = clean_book_name.split()
    bn = len(bx)
    if bn>fn:
        n = fn/bn
    else:
        n = bn/fn
    flag = True
    for f in fx:
        if f not in bx:
            flag = False
            break

    if flag and n>=0.8: # 如果文件全部在图书里面

        return flag

    flag = True
    for b in bx:
        if b not in fx:
            flag = False
            break
    if flag and n>=0.8:
        return flag
    return False

def check_book_by_start(text, start_text):
    if text.startswith(start_text+"："):
        return True
    if text.startswith(start_text+"（"):
        return True
    return False

def is_book(valid_file_name, book_name, book_authors, book_isbn):
    #--规则1：完全匹配
    book_name = fix_number(book_name)
    valid_file_name = fix_number(valid_file_name)

    #print(f"check valid_file_name={valid_file_name}, book_name = {book_name}")
    if check_book_by_full_match(valid_file_name, book_name):
        return True
    if check_book_by_full_match(valid_file_name, book_isbn):
        return True
    if check_book_by_in(valid_file_name, book_isbn):
        return True
    #電影冷知識：跨越銀幕之外，我們都想探索的電影製造祕密 (許立衡、張凱淯)
    # book_name进行修正
    temp_book_name = book_name.replace(":","：")
    temp_book_name = temp_book_name.replace("【", "：")
    temp_book_name = temp_book_name.replace("[", "：")
    temp_file_name = valid_file_name.replace(":","：")
    temp_file_name = temp_file_name.replace("【", "：")
    temp_file_name = temp_file_name.replace("[", "：")
    #--
    temp_book_name = temp_book_name.replace("(", "（")
    temp_book_name = temp_book_name.replace(")", "）")
    kuo_temp_book = stringutil.cut(temp_book_name, "（", "）")
    if "册" in kuo_temp_book or "上下" in kuo_temp_book or "上中下" in kuo_temp_book:  # 不能分割
        pass
    else:
        temp_book_name = temp_book_name.replace("（", "：")

    #  括号的处理
    temp_file_name = temp_file_name.replace("(","（")
    temp_file_name = temp_file_name.replace(")", "）")
    kuo_temp_file = stringutil.cut(temp_file_name, "（", "）")
    if "册" in kuo_temp_file or "上下" in kuo_temp_file or "上中下" in kuo_temp_file: # 不能分割
        pass
    else:
        temp_file_name = temp_file_name.replace("（", "：")


    temp_books = temp_book_name.split("：")
    temp_files = temp_file_name.split("：")
    books = []
    files = []
    if len(temp_books)>1:
        if check_book_by_start(temp_file_name, temp_books[0]):
            return True
        if len(temp_books[0]) > 4:
            books.append(temp_books[0])

    books.append(temp_book_name)
    if len(temp_files)>1:
        if check_book_by_start(temp_book_name, temp_files[0]):
            return True

        if len(temp_files[0])>4:
            files.append(temp_files[0])
    files.append(temp_file_name)

    book_authors = stringutil.getStringSlug(book_authors)
    authors = book_authors.split(" ")
    authors.insert(0, " ")
    for temp_file in files:
        for temp_book in books:
            for author in authors:
                temp_book_name = temp_book+ " "+ author
                if check_book_by_full_match(temp_file, temp_book_name):
                    return True
                if check_book_by_fenci_in(temp_file, temp_book_name):
                    return True
                if check_book_by_in(temp_file, temp_book_name):
                    return True

    return False

if __name__ == "__main__":
    fx = "隐谷路 ： 一个精神分裂症家族的绝望与希望（非虚构类叙事作品。12个孩子中的6个先后罹患严重的精神分裂症，另6个孩子则在恐惧中等待，等待自己成为下一个，等待更多痛苦和伤害的降临。） "
    book = "精神分裂症：你和你家人需要知道的"
    print(is_book(fx, book, "",""))