import nltk
#nltk.download('wordnet')
#nltk.download('punkt')
from nltk.stem import WordNetLemmatizer
from nltk import word_tokenize, pos_tag, sent_tokenize
from nltk.corpus import wordnet
import sys, fitz
import stringutil
import re
from bs4 import BeautifulSoup
import fileutil
import math
import time
import htmlutil
TYPE_CAN = 'can'
TYPE_IS_ARE = 'is'
type_USE = 'use'

#_____________________
def pureLine(line_text):
    #remove all html tags
    text = htmlutil.filter_tags(line_text)
    
    return text.strip()
def getAllLeftPt(ptext):
    pattern = r'left:([0-9\.]{1,20})pt'
    ptexts = ptext.split(">")
    ptext = ptexts[0]
    #re.match(pattern, html, re.I)
    matcher = re.findall(pattern, ptext, re.I)  
   
    sizes = []
    if not matcher:
        return None  
    #print(matcher)
    sizes = [float(i) for i in matcher]
    return list(set(sizes))
    
def isBookMarkPage(page_html, per = 0.6):
    
    arr = ['......', '------']
    lines = page_html.split("\n")
    m = []
    i = 0
    total_line = 0
    for l in lines:
        l = pureLine(l)
        if l == "":
            continue
        total_line += 1
        for a in arr:
            if a in l:
                i += 1
    if total_line < 1:
        return False
    #print(i / total_line)
    if (i / total_line) > 0.6:
        return True
    return False
def getMarkLeft(doc):
    left = []
    max = 50
    for page in doc:
        max -= 1
        print(max)
        if max < 0:
            break
        page_html = page.getText('html')
        if not isBookMarkPage(page_html):
            continue
        cat_tag = '####new####'
        pattern = re.compile(r'[\.\-]{6,}')
        page_html = re.sub(pattern, cat_tag, page_html)
        soup = BeautifulSoup(page_html, 'html.parser')
        p = soup.find_all("p")

        for px in p:
            pstr = str(px)
            if cat_tag not in pstr:
                continue
            #print(pstr)
            left_list = getAllLeftPt(pstr)
            if left_list:
                left.extend(left_list)
    left_list = list(set(left))
    #sort
    return sorted(left_list)
def getMarksByPage(page, markleft):
    if len(markleft) < 1:
        return []
    page_html = page.getText('html')
    if not isBookMarkPage(page_html):
        return []
    #print(page_html)
    cat_tag = '####new####'
    pattern = re.compile(r'[\.\-]{6,}')
    page_html = re.sub(pattern, cat_tag, page_html)
    soup = BeautifulSoup(page_html, 'html.parser')
    p = soup.find_all("p")
    cats = []
    for px in p:
        phtml = str(px)
        
        mtext = px.getText()
        if cat_tag not in mtext:
            continue
        left = getAllLeftPt(phtml)
        
        xs = mtext.split(cat_tag)
        mtext = xs[0]
        mtext = stringutil.removeEmpty(mtext, True)
        mtext = mtext.strip()
        if mtext == "":
            continue
        cat_type = 0
        if left:
            left_dist = float(left[0])
            left_dist = float(left_dist)
            if left_dist not in markleft:
                continue
            cat_type = markleft.index(left_dist) + 1
        if cat_type > 0:
            cats.append((cat_type, mtext, 0))
    return cats
#______________________________
def isUpperStart(text_list, per =0.6):
    n = 0
    for str in text_list:
        #remove all
        pattern = re.compile(r'[^A-Za-z]{1,}', re.IGNORECASE)
        str = re.sub(pattern, '', str)
        str = str.strip()
        #
        if str == "":
            continue
        first = str[0]
        if ord(first) >= ord('A') and ord(first) <= ord('Z'): 
            n += 1
    px = n / len(text_list)
    if px < per:
        return False
    return True
def isValidMark(text_list):
    #propcess
    check_data = []
    for t in text_list:
        t = t.strip()
        if len(t) < 1:
            continue
        if t not in check_data:
            check_data.append(t)
    text_list = check_data
    if len(text_list) < 5:
        return False
    if not isUpperStart(text_list):
        return False
    # can not contain
    arr = ['..','https://','http://']
    for text in text_list:
        for a in arr:
            if a in text.lower():
                return False
    for text in text_list:
        text = text.strip()
        if text.endswith("."):
            n = ''.count(". ")
            if n >= 1:
                return False   
    
    end_invalid = 2
    arr = [',', '-',' a',' the', ' are', ' is', ' and', ' to', ' been']
    # all is upper 
    #['T', 'M', 'N', 'T', 'E']
    i = 0
    for text in text_list:
        lx = len(text)
        i += lx
    if i <= len(text_list):
        return False
    #['— # —', '— $ —', '— . —', '— 1 —', 
    
    # number 
    max_number = 1
    i = 0
    for text in text_list:
        flag = stringutil.isAllNumber(text)
        if flag:
            i += 1
    if i>= max_number:
        return False
    #contain a-z
    for text in text_list:
        text = text.strip()
        if len(text) >= 1: #排除空值
            flag = stringutil.containsEnglishChar(text)
            if not flag:
                return False
    #['Me c h a n i c a l E n g i n e e r i n gR e p o r t 2 0 0 5 / 1 6P 
    max_a_len = 10
    for text in text_list:
        tx = text.split()
        i = 0
        for t in tx:
            if len(t) == 1:
                i += 1
        if i>= max_a_len:
            return False    
    return True  
def getValidFontSize(font_page_nos, total):
    
    p1 = 5
    p2 = total*0.2
    va = {}
    for font, page_nos in font_page_nos.items():
        #px = page_nos / total
        px = page_nos
        if page_nos <p1 or px > p2:
            continue
        #if px < 1.0:
        va[float(font)] = px# abs(px - p)
    
    if va:
        vax = sorted(va.items(), key=lambda d:d[0], reverse = True)
        va = vax
    print(va)
    return va
    
def getPerList(ls):
    l = len(ls)
    sum = 0
    for i in range(0,l-1):
        sum += (ls[i+1] - ls[i])
    return sum/l

def isValidTag(t):
    t = t.strip()
    pattern = r'[^A-Z0-9a-z\.\-#\+&%$ ]{1,}'
    temp = re.sub(pattern, "", t)
    temp = temp.strip()
    if len(temp) != len(t):
        return False
    
    if len(t) <3:
        return False
    #.9604 .9409 .9216 .9025 .8836 .8649 .8464
    pattern = r'[0-9\.\-#\+&%$ ]{1,}'
    temp = re.sub(pattern, "", t)
    temp = temp.strip()
    if len(t) == 0:
        return False
    
    #--------------
    first = t[0]
    if first == '+' or first == '%' or first == '#' or first == '-' or first == '$' or first == '&':
        return False
    last = t[-1]
    if last == '-' or last == '$' or last == '&' or last == '%' or last == '.':
        return False
    
    first = t[0:2]
    if first == 'A ' :
        return False
    return True


def getAllPDFPages(file):
    doc = None
    try:
        doc = fitz.open(file) 
    except Exception as e:
        print(e)
        if doc:
            doc.close()
        return  None,[]
    pages = []
    #print(doc.pageCount)
    i = 0
    for i in range(doc.pageCount):
        try:
            pages.append(doc[i])
        except Exception as e:
            print("page = " + str(i))
            print(e)
    return doc,pages

#

def getfontsize(html):
    pattern = r'font-size:([0-9\.]{1,20})pt'
    #re.match(pattern, html, re.I)
    matcher = re.findall(pattern, html, re.I)  
   
    sizes = []
    if not matcher:
        return None  
    
    sizes = [float(i) for i in matcher]
    return list(set(sizes))
def deleteAllAnnotations(page):
    first_annotation = page.firstAnnot
    while first_annotation:
        page.deleteAnnot(first_annotation)
        first_annotation = page.firstAnnot
    return page
def parserpage(page, font_size):
    page = deleteAllAnnotations(page)
    html_data = page.getText("html")
    return parser(html_data, font_size)
#merge lines

def mergeLines(html):
    html = html.replace("<", " <")
    lines = html.split("\n")
    m = []
    fontsize = None
    i = -1
    for l in lines:
        i += 1
        current_font_size = getfontsize(l) #list
        if current_font_size:
            current_font_size = sorted(current_font_size)
        
        if not fontsize:
            fontsize = []
        if not current_font_size:
            current_font_size = []

        
            #print(fontsize)
        fontsize_str = " ".join([str(f) for f in fontsize])
        current_font_size_str = " ".join([str(f) for f in current_font_size])
            
        if fontsize_str == current_font_size_str and len(m) > 0:
            last = m[-1]
            last = last + l
            m[-1] = last
        else:
            m.append(l)
        fontsize = current_font_size
    text = ['<article>'+s +"</article>" for s in m] 
    return "".join(text)       

#get font size list from big to samll
def getFontList(doc):
    html_data = []
    max_font_sizes = []

    for page in doc:
  
        page = deleteAllAnnotations(page)
        html_text = page.getText("html")
        html_text = mergeLines(html_text)
        
        html_data.append(html_text)
        
        sizes = getfontsize(html_text)
           
        if sizes:
            max_font_sizes.extend(sizes)
       
        
    #print(html_data)  
    if max_font_sizes:
        max_font_sizes = list(set(max_font_sizes))
        max_font_sizes.sort(reverse=True)
        
    font_page_nos = {}
    for fontsize in max_font_sizes:
        no = []
        page_no = 0
        #print(html_data[3])
        
        for data in html_data:
            font_1 = "font-size:"+str(fontsize)+"pt"
            flag = False
            if font_1 in data:
                #n = data.count(font_1)
                page_no += 1
                flag = True
            
            font_2 = font_1
            if str(fontsize).endswith(".0") and not flag:
                font_2 = "font-size:"+str(int(fontsize))+"pt"
                if font_2 in data:
                    #n = data.count(font_2)
                    page_no += 1
            #no.append(page_no)
            '''if font_1 in data or font_2 in data:
                no.append(page_no)'''
        font_page_nos[str(fontsize)] = page_no
    return html_data, max_font_sizes, font_page_nos
def getMarks(html_data, font_size):
    marks = []
    for html in html_data:
        soup = BeautifulSoup(html, 'html.parser')
        p = soup.find_all("article")
    
        for s in p:
            if not s:
                continue
            font_1 = 'font-size:'+str(font_size)+'pt' 
            font_2 = font_1
            if str(font_size).endswith(".0"):
                font_2 = "font-size:"+str(int(font_size))+"pt"
            if font_1 in str(s) or font_2 in str(s):
                mtext = s.getText()
                mtext = stringutil.removeEmpty(mtext, True)
                mtext = mtext.strip()
                marks.append(mtext)
    
    return marks
def getBookmarkByPdfDoc(doc):
    
    toc = doc.getToC(simple = True)
    
    if len(toc) < 1:
        print("get bookmark by text")
        toc = []
        #print(f)
        print(doc.pageCount)
        all_left = getMarkLeft(doc)
        print("get p left all end")
        print("--")
        print(all_left)
        print("--")
        max = 50
        for page in doc:
            max -= 1
            if max<0:
                break
            marks = getMarksByPage(page, all_left)
            if marks:
                #print(marks)
                toc.extend(marks)
    return toc
def getBookmarkFromPdf(f):
    doc,pages = getAllPDFPages(f)
    pages = []
    return getBookmarkByPdfDoc(doc)
    
    '''
                html, fontsize, font_page_nos = getFontList(doc)
        #print(fontsize)
        print(font_page_nos)
        va = getValidFontSize(font_page_nos, doc.pageCount)
        #if va:
        
        if len(va) >0:
            #print(va)
            for f in va:
                marks = getMarks(html, font_size = f[0])
                if isValidMark(marks):
                    print(marks)
                    break'''
    
#f = 'g:\\3678.pdf'
#f = 'g:\\1131-DCD-UrbanForestry-December-2012-Final-UTC-Rpt.pdf'
#f = 'g:\\1135-Tulsa_County_Urban_Tree_Canopy_Assessment_2016-07-17a_.pdf'
#print(getBookmarkFromPdf(f))
dir = "F:\\all-google-en-pdf\\download\\"
#dir = "F:\\PDF-Documents\\Standard-Books\\2\\

files = fileutil.traverseDir(dir, file_type = '.pdf')
print("files="+str(len(files)))
for f in files[0:10]:
    #print(f)
    getBookmarkFromPdf(f)
