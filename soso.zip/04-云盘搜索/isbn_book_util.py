import tabledb
import os
import fileutil
import pdf_book_util
import json
from datetime import datetime
import shutil
def get_all_book_dict():
    # 所有的图书信息
    book_fx = [r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250610.json",
               r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250611.json",
               r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250613.json",
               r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250616.json",
               r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250618.json",
               r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250623.json",
               r"D:\04-个人项目\00-图书\书籍文件\05-book.douban.com-解析\book.douban.com-data-20250623.json",
               ]

    all_book_dict = {}
    for fx in book_fx:
        data = fileutil.read_json(fx)
        x_data = {data[d]["ISBN"]: data[d] for d in data}
        all_book_dict.update(x_data)
    print(len(all_book_dict))
    #----------------------------------------------------------------------------------
    #----------------------------------------------------------------------------------

    for isbn in all_book_dict:
        google_isbn = fr"D:\04-个人项目\00-图书\书籍文件\06-book.google.com-isbn\文件\{isbn}.json"
        d = all_book_dict[isbn]
        page = d["页数"]
        author = d["作者"]
        title = d["标题"]
        try:
            page = int(page)
        except:
            if os.path.exists(google_isbn):
                google_data = fileutil.read_json(google_isbn)
                item = google_data["items"][0]
                print(isbn, type(google_data))
                if "pageCount" in item["volumeInfo"]:
                    page = item["volumeInfo"]["pageCount"]
                    print(page, google_data)
                    all_book_dict[isbn]["页数"] = page
    return all_book_dict
#--------------------------------------------

def move(pdf_file, file_name):
    date_str = datetime.now().strftime('%Y%m%d')
    dir = r"D:\04-个人项目\00-图书\书籍文件\01-标准图书-PDF\PDF"+"\\"+date_str
    if not os.path.exists(dir):
        os.makedirs(dir)
    dst = dir+"\\"+file_name+".pdf"
    try:
        #shutil.move(pdf_file, dst)
        if os.path.exists(dst):
           # os.remove(pdf_file)
            return dst
        shutil.copy(pdf_file, dst)


    except Exception as e:
        print(e, pdf_file, file_name)
        return ""
    return dst
#--------------------------------
def save_std_pdf(isbn, pdf_file, all_book_dict):
    dirname, filename, extend = fileutil.getFilePathInfo(pdf_file)

    if isbn in all_book_dict:
        # 获取已有的标准图书信息
        isbn_book_info = get_isbn_book_info(isbn)
        d = {}
        if isbn_book_info is None:
            d["info"] = all_book_dict[isbn]
            d["files"] = {}
        else:
            d["info"] = isbn_book_info["isbn_info"]["info"]
            d["files"] = isbn_book_info["isbn_info"]["files"]
        if filename in d["files"]:  # 说明已经被移动了
            pdf_basic_info = d["files"][filename]
            dst_file_name = pdf_basic_info["pdf_file_name"]
            if os.path.exists(dst_file_name):
                os.remove(pdf_file)
            return

        file_num = len(d["files"])
        if file_num == 0:
            # copy and remove
            dest_file_name = f"{isbn}"
        else:
            file_num += 1
            dest_file_name = f"{isbn}-{file_num}"
        # 判断是否可以移动
        page_count, filesize = pdf_book_util.can_move(pdf_file, d["files"])
        if page_count <= 0:
            print(f"重复：{pdf_file}")
            return
        dst = move(pdf_file, dest_file_name)
        if dst != "":  #
            pdf_basic_info = {}

            pdf_basic_info["pdf_page"] = page_count
            pdf_basic_info["pdf_size"] = filesize
            pdf_basic_info["pdf_file_name"] = dst
            d["files"][filename] = pdf_basic_info
            upate_isbn_book_info(isbn, d["info"], d["files"])
            os.remove(pdf_file) # 放在数据集更新失败导致文件被移动

#------------------------------------------------------------------

def upate_isbn_book_info(isbn, info, files):
    #确定是否存在
    d = get_isbn_book_info(isbn)
    if d is None:
        #add
        add_isbn_book_info(isbn, info, files)
    else:
        d = {}
        d["info"] = info
        d["files"] = files
        update_data = {
            "isbn_info": json.dumps(d, ensure_ascii=False)
        }
        tabledb.update("isbn_books", update_data=update_data, where_data={'isbn_slug': isbn})


def add_isbn_book_info(isbn, info, files):
    d = {}
    d["info"] = info
    d["files"] = files
    data = {
        "isbn_slug": isbn,
        "isbn_info": json.dumps(d, ensure_ascii=False)
    }
    tabledb.insert("isbn_books", data)


def get_isbn_book_info(isbn):
    table = 'isbn_books'
    key = tabledb.query(table, keys='isbn_id, isbn_slug, isbn_info ', data={'isbn_slug': isbn})
    if key is None:
        return None

    isbn_list = []
    d = {}

    for k in key:
        d["isbn_id"] = k[0]
        d["isbn_slug"] = k[1]
        d["isbn_info"] =  json.loads(k[2])
        return d
    return d
#--------------------------------------------