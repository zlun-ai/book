# -*- coding:utf-8 -*-
import os.path
import jieba
import netutil
import fileutil
import urllib
import time
import random
import stringutil
import htmlutil
import json
import tabledb
def get_all_book_dict():
    # 所有的图书信息
    book_fx = [r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250610.json",
               r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250611.json",
               r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250613.json",
               r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250616.json",
               r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250618.json",
               r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250623.json",
               r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250630.json",
               r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250707.json",
               r"D:\04-个人项目\00-图书\书籍文件\05-book.douban.com-解析\book.douban.com-data-20250623.json",
               r"D:\04-个人项目\00-图书\书籍信息\sobooks.cc-data-20250711.json",
               ]

    all_book_dict = {}
    for fx in book_fx:
        data = fileutil.read_json(fx)
        #x_data = {data[d]["ISBN"]: data[d] for d in data}
        all_book_dict.update(data)
    print(len(all_book_dict))
    #----------------------------------------------------------------------------------
    #----------------------------------------------------------------------------------

    for link_slug in all_book_dict:
        d = all_book_dict[link_slug]

        isbn = d["ISBN"]
        google_isbn = fr"D:\04-个人项目\00-图书\书籍文件\06-book.google.com-isbn\文件\{isbn}.json"

        page = d["页数"]
        author = d["作者"]
        title = d["标题"]
        try:
            page = int(page)
        except:

            if os.path.exists(google_isbn):
                google_data = fileutil.read_json(google_isbn)
                item = google_data["items"][0]
                print(isbn, type(google_data))
                if "pageCount" in item["volumeInfo"]:
                    page = item["volumeInfo"]["pageCount"]
                    print(page, google_data)
                    all_book_dict[link_slug]["页数"] = page
    return all_book_dict

# 将图书标题写入到db
name_dict = {}
def add_book(book):
    book_name = book["标题"].strip()
    sub_book_name = book["副标题"].strip()
    if sub_book_name != "":
        book_name = book_name+"："+sub_book_name
    book_author = book["作者"]
    book_ori_author = book["译者"]
    isbn = book["ISBN"]

    book_author = book_author.replace("，", ",")
    book_author = book_author.replace(";", ",")
    book_author = book_author.replace("；", ",")
    book_author = book_author.replace("、", ",")
    book_author=book_author.replace(",","/")
    ax = book_author.split("/")
    ax = [x.strip() for x in ax if len(x.strip())>=2]

    title_slug = f"{book_name}-{book_author}"
    title_slug = stringutil.getStringSlug(title_slug)
    slug = stringutil.getMD5(title_slug)
    if slug in name_dict:
        name_dict[book_name] += 1
        print(book_name)
    else:
        name_dict[book_name] = 1

    ctx = f"{book_name} {book_author} {book_ori_author} {isbn}"
    ctx = stringutil.remove_punctuation_and_special_chars(ctx)
    seg_list = jieba.cut(ctx, cut_all=False)
    seg_list = [x.strip() for x in seg_list if x.strip()!=""]
    seg = " ".join(seg_list)
    seg = seg.strip()

    book_info = json.dumps(book, ensure_ascii=False)

    # 判断是否存在


    table = "all_book"
    data = {"book_slug":slug,
            "book_name":book_name,
            "book_author":book_author,
            "book_ori_author":book_ori_author,
            "book_isbn":isbn,
            "book_content": seg,
            "book_info":book_info}
    tabledb.insert(table, data)

all_book_dict = get_all_book_dict()
print(len(all_book_dict))
for link_slug in all_book_dict:
    book = all_book_dict[link_slug]
    #print(book)
    add_book(book)
    #break

for b in name_dict:
    if name_dict[b]>1:
        print(b)