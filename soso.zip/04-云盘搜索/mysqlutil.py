#-*- coding: UTF-8 -*- 
from __future__ import division, print_function, unicode_literals
from __future__ import unicode_literals
import numpy as np
from numpy import linalg as LA
import pymysql


class MySQLUtil():
    def connectDB(self, host, user, psw, db_name, charset='utf8'):
        self.db = pymysql.connect(host=host, user=user, password=psw, db= db_name, charset=charset)
    def colseDB(self):
        self.db.close()
        
    def execQuery(self, sql):
        
        try:
            # 执行SQL语句
            cursor = self.db.cursor()
            cursor.execute(sql)
            # 获取所有记录列表
            results = cursor.fetchall()
            return results
        except Exception as e:
            print(e)
            print ("Error: unable to fecth data")  
            return []
        
    def execSql(self, sql):
        cursor = self.db.cursor()

        # SQL 插入语句
        try:
            # 执行sql语句
            cursor.execute(sql)
            # 提交到数据库执行
            self.db.commit()
            cursor.close()
            return True
        except Exception as e:
            print(e)
            # 发生错误时回滚
            self.db.rollback()
        return False
    
    
    

                    