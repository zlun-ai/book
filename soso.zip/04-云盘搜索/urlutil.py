import sys
import io
import os
import shutil
import urllib.parse
from urllib.parse import urlparse, parse_qs

def urlencode(str):
  return urllib.parse.quote(str)


def urldecode(str):
  return urllib.parse.unquote(str)

def get_valid_link(link):
    if "%3A%2F%2F" in link or "%3A//" in link or ("%3F" in link and "%3D" in link):
        link = urldecode(link)
    if "\/" in link:
        link = link.replace("\/","/")
    return link

def isValidLink(link):

    if  not link.startswith("https://") and not link.startswith("http://"):
        return False
    return True

def isRootURL(url):
    url = url.lower()
    r = getRootURL(url)
    #print(r)
    rx = r[0].replace("/",'')
    rx = rx.lower()
    url = url.replace("/",'')
    if rx == url:
        return True
    return False
    #print(rx)
    #print(url)

def getRootURL(url):
    url_info = urllib.parse.urlparse(url)
    print(url_info)
    host = url_info.scheme+ "://" + url_info.netloc
    return host, url_info.netloc

def parse_url(url):
    # 1. 使用 urlparse 解析 URL
    parsed_url = urlparse(url)

    # 2. 获取查询参数部分（query）
    query_string = parsed_url.query  # 输出: 'name=John&age=30&hobby=reading&hobby=traveling'

    # 3. 使用 parse_qs 解析查询参数
    params = parse_qs(query_string)

    info = {}
    info["path"] = parsed_url.path
    info["param"] = params
    return info

#isRootURL('ftp://115.124.123.42/')
#='https://yunpan.360.cn/docviewer/Sourceviewer?nid=15634334422402061&type=py'
#print(parse_url(u))