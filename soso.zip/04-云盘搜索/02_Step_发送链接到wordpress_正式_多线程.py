# -*- coding:utf-8 -*-
import fileutil
import random
import os
import time
import netutil
import sys
import html
import stringutil
import re
import book_util
import htmlutil
import tabledb

import concurrent.futures
# connect MySQL
def getDataValue(content):
    if not content:
        return None
    pattern = r'<data>(.*?)</data>'

    matcher = re.findall(pattern, content, re.IGNORECASE)
    if not matcher:
        return None
    content = matcher[0]
    if not content:
        return None
    content = content.strip()
    if content == "":
        return None
    content = content.replace("<data>", "")
    content = content.replace("</data>", "")
    content = content.strip()
    if content == "":
        return None
    return content


def getWordPressContent(p):
    # post_title
    w = {}

    t = p['post_title']
    t = t.replace("\\'","'")
    p['post_title'] = t

    w['post_title'] = p['post_title']
    w['post_slug'] = p['post_slug']
    w['post_content'] = p['post_content']
    w['post_desc'] = p['post_desc'].strip()
    #w['post_isbn'] = p['post_isbn']

    #w['post_file_download'] = p['link_url']


    # meta: url,size, page
    pattern = re.compile(r'\n[ ]{2,}')
    w['post_title'] = re.sub(pattern, '', w['post_title'])

    return w

def get_psw(url):
    ux =url.split("?p=")
    if len(ux) == 2:
        return ux[1]
    return ""

def get_file_dot(file_name):
    #

    file_name = file_name.strip()

    arr = [".pdf",".epub",".mobi"]
    flag = False
    for a in arr:
        if file_name.lower().endswith(a):
            flag = True
            dot = a.replace(".","")
            return dot
    return ""

def convertoSafe(p):
    for key, value in p.items():
        p[key] = stringutil.urlsafe_b64encode(str(value))
    return p

all_invalid_links = fileutil.get_valid_links()
print(all_invalid_links)

max_upload_num = 500
sql = ''
table = 'yunpan_link'
keys = 'link_id, link_slug, link_url, file_name, file_category,file_size,file_time, userid, username,link_psw,file_tag'
data = {'link_send': 0}
all_links = tabledb.query(table, keys, data, orderby=" link_id asc ")
print(len(all_links))
uploaded = {}
wordpress_in = {}
#for link in all_links:
def process(link):
    p = {}
    link_id = link[0]
    link_slug = link[1]
    if link_slug in uploaded:
        return
    p['link_slug'] = link_slug
    p['link_url'] = link[2]
    p['file_name'] = book_util.get_valid_book_name(link[3])
    dot = get_file_dot(link[3])

    if dot == "":
        #continue
        return
    p['file_category'] = link[4]#htmlutil.filter_tags(p['link_desc'])
    if p['file_category'] == "":
        #continue
        return
    p['file_size'] = link[5]
    p['file_time'] = link[6]
    p['userid'] = link[7]
    p['username'] = link[8]
    p["link_psw"] = link[9]
    p["file_tag"] = link[10]
    if p["link_psw"] == "":
        pws = get_psw(p['link_url'])
        p["link_psw"] = pws
    url = p['link_url']

    # 去除isnb
    content = f"<p>[filesize]{p['file_size'] }[/filesize]</p>"
    content += f"<p>[cat]{p['file_category']}[/cat]</p>"
    content += f"<p>[tag]{p['file_tag']}[/tag]</p>"
    content += f"<p>[url]{p['link_url']}[/url]</p>"
    content += f"<p>[psw]{p["link_psw"]}[/psw]</p>"
    content += f"<p>[date]{p['file_time']}[/date]</p>"
    content += f"<p>[userid]{p['userid']}[/userid]</p>"
    content += f"<p>[username]{p['username']}[/username]</p>"
    content += f"<p>[format]{dot}[/format]</p>"

    wp = {}
    wp["post_content"] = content
    wp["post_title"] = p['file_name']
    wp["post_slug"] = p['link_slug']
    wp["post_desc"] = p['file_name']+" "+ p['file_category'] + " "+ p['file_tag'] # 生成分词

    p = getWordPressContent(wp)
    print(p)



    url = 'http://127.0.0.1/wp-link-search/wp-content/themes/rest-api/save-info/save-demo-bookinfo.php'
    #url = "https://www.booklibz.com/wp-content/themes/book-en-pro/save-info/save-bookinfo.php"

    data = convertoSafe(p)


    content = netutil.sendData(url, data, proxy=False)
    print('data response:')
    print(content)

    uid = getDataValue(content)
    print("file_upload_name =")
    print(uid)
    if uid and uid == link_slug:
        # pass
        where_data = {"link_slug": link_slug}
        update_data = {'link_send': 1}
        tabledb.update(table, update_data, where_data)
        uploaded[link_slug] = link_slug
        #max_upload_num -= 1
       # if max_upload_num <=0:
           # break

    else:
        # exit(0)
        time.sleep(4)
      #  continue
    # send image end-----------------------
    time.sleep(random.randint(1,3))
# send to wordpress

def main(items):
    # 要处理的列表
    # 方法1: 使用map处理（保持顺序）
    print("=== 使用map处理 ===")
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        # map保持输入顺序
        results = list(executor.map(process, items))



if __name__ == "__main__":
    main(all_links)