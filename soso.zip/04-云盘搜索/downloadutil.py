# -*- coding:utf-8 -*-
import urllib.request
import urllib.parse
import http.cookiejar
import os
import time
import random
import progressbar
import socket
import aria2downloadutil
import ssl
#from wrapt_timeout_decorator import *
download_max_time = float(90)
socket.setdefaulttimeout(download_max_time)
'''print(str(socket._GLOBAL_DEFAULT_TIMEOUT))
print(socket.getdefaulttimeout())
socket.s'''

class Monitor:
    pass
#

def getRootURL(url):
    url_info = urllib.parse.urlparse(url)
    #print(url_info)
    host = url_info.scheme+ "://" + url_info.netloc
    return host

def getRequestOpener(url, cookie = False):
    opener = None
    if cookie :
        cookie = http.cookiejar.CookieJar()
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie))
    else:
        context = ssl._create_unverified_context()
        sslHandler = urllib.request.HTTPSHandler(context=context)
        opener = urllib.request.build_opener(sslHandler)
        
    headers = []
    headers.append(('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'))
    headers.append(('Accept-Encoding', 'gzip, deflate, br'))
    headers.append(('Accept-Language', 'zh-CN,zh;q=0.9'))
    headers.append(('Cache-Control', 'max-age=0'))
    headers.append(('Referer', getRootURL(url)))
    headers.append(('User-Agent', 'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'))

    opener.addheaders = headers
    
    return opener
    

def download(url, local_filename, allow_types=['application/pdf','application/zip','application/octet-stream']):
    download_status = False
    download_try = 0
    download_max_timeout_try = 2
    flagx = aria2downloadutil.get_file_from_cmd(url, local_filename) 
    if flagx:
        return True, 0
    # 删除不必要的文件
    if os.path.exists(local_filename):
        os.remove(local_filename)
    if os.path.exists(local_filename+".aria2"):
        os.remove(local_filename+".aria2")

    #step 1. download direct
    print("download directly")
    download_status, download_try = downloadDirect(url, local_filename)
    #check is timeout
    if download_try == 2: #timeout
        for i in range(1,download_max_timeout_try):
            time.sleep(random.randrange(5,15))
            print("\nconnect time out, try=" + str(i))
            download_status, download_try = downloadDirect(url, local_filename)
            if download_status or download_try == 1:#cookie
                break
            if not download_status:
                continue
    #step 2. download with cookie 
    
    if download_try == 1 :
        print("download with cookie")
        download_status, download_try = downloadDirect(url, local_filename, True)
        
    return download_status, download_try
    

def downloadDirect(url, local_filename, withcookie = False, allow_types=['application/pdf','application/zip', 'application/octet-stream']):
    opener = None
    download_status = False
    file_check = False
    download_bar = None
    
    #
    download_try_cookie = 1 #cookie
    download_try_timeout = 2 #timeout
    #no any message print during downloading
    progressbar.printProgress(0, 100, prefix='Progress:', suffix='Complete', barLength=50)
    def Schedule(a,b,c):
        nonlocal opener
        nonlocal download_status
        nonlocal file_check
        nonlocal local_filename
        nonlocal download_bar
        if not file_check:
            # Initial call to print 0% progress
            pass
        if not file_check:
            if not os.path.exists(local_filename):
                file_check = True
                return
            size = os.path.getsize(local_filename)
            if size == c:
                print('local file exists not need download')
                download_status = True
                if not opener:
                    opener.close()
                return
            file_check = True
        if c == -1: # mask
            print('no total size detect')
            print(a,b,c)
            #download_status = False
            #if not opener:
                #opener.close()
            #return
        #print(a,b,c)
        ''''
        a: downloaded block number
        b: each block size
        c: the size of remote file
       '''
        per = 100.0 * a * b / c
        if per >= 100 or (a*b>=c) :
            per = 100
            download_status = True
            #print(download_status)
        #print('%.2f%%' % per)
        #download_bar.update(per)
        progressbar.printProgress(int(per), 100, prefix='Progress:', suffix='Complete', barLength=50)
    
    
    opener = getRequestOpener(url, withcookie)
    urllib.request.install_opener(opener)
    file_content_type = ''
    try:
        
        local_file, response_headers = urllib.request.urlretrieve(url,local_filename,Schedule)
        file_content_type = response_headers.get_content_type()
        print(file_content_type)
    except urllib.error.ContentTooShortError as shortError:
        print(shortError)
        print("content too short error")
        return download_status, download_try_timeout
    except urllib.error.HTTPError as e:
        error_code = e.code
        print(e)
        if error_code >= 403 or error_code >=500: #Not Found
            print("\n")
            print(e)
            print("fail to download!")
            download_status = False
            download_try = 0
            return download_status, download_try_cookie
    except urllib.error.URLError as ue: # such as timeout
        download_status = False
        print("fail to download!")
        return download_status, download_try_timeout
    except socket.timeout as se:
        download_status = False
        print(se)
        print("socket timeout")
        return download_status, download_try_timeout
    except Exception as ee:
        download_status = False
        print(ee)
        return download_status, download_try_timeout

    if file_content_type not in allow_types:
        print("\nthis file type is not allowed!")
        print("fail to download!")
        if os.path.exists(local_filename):
            os.remove(local_filename)
        return False, 0
    if not download_status:
        if os.path.exists(local_filename):
            os.remove(local_filename)
            return False, 1
    
        print(download_status)
        print("fail to download!")
        return False, 1 #try
    return True, 0
#url = 'https://www.packtpub.com/sites/default/files/downloads/GoogleVRUpdateGuideforCardbook.pdf'

#local = os.path.join('F:\\','test.pdf')
#download(url, local)