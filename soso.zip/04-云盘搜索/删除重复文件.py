#-*- coding: utf-8 -*-
import urllib.request
import urllib.parse
import json
import os
'''
jsonreq = {'jsonrpc':'2.0', 'id':'qwer', 'method':'aria2.addUri', 'params':[['http://example.org/file']]}
print(jsonreq)
print(type(jsonreq))
jsonreq = urllib.parse.urlencode(jsonreq).encode(encoding='utf-8')
req = urllib.request.Request(url='http://localhost:6800/jsonrpc', data=jsonreq)
c = urllib.request.urlopen(req)
print(c.read())'''

import os
import time
import sys
import subprocess
import fileutil

save_dir = r'F:\all-google-pdf\download'

files = fileutil.traverseDir(save_dir, file_type = '.pdf')
for fx in files:
    dirname, filename, extend = fileutil.getFilePathInfo(fx)
    for i in range(100):
        i = str(i)
        tag = "."+i+".pdf"

        if fx.endswith(tag):
            print(fx)
            os.remove(fx)