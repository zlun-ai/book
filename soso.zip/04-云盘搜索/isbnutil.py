import sys
import numpy as np
import os
import re
import isbnlib
import stringutil

#print(isbnlib.to_isbn10('9783333333335'))

def getCopyrightDate(data):
    
    pattern = re.compile('Copyright[ ]{0,}[\(\[]{1,}c[\)\]]{1,}', re.IGNORECASE)
    data = re.sub(pattern, '©', data)
    
    print(ord('©'))
    pattern='\xA9[ ]{0,}([0-9]{4,4})'
    matcher = re.findall(pattern, data, re.I)
    if not matcher:
        return ''
    print(matcher)
    res = []
    for d in matcher:
        d = int(d)
        if d>1000 and d<3000:
            d = str(d)
            if d not in res:
                res.append(d)
                if(len(res)>1):
                    break
    if not res:
        return ''
    #最大的一个
    res.sort(reverse=True)
    return res[0]
def isValidISBN(isbn):
    if len(isbn) < 5:
        return False
    for i in range(10):
        i = str(i)
        pattern = re.compile('['+i+']{5,}')
        isbn_temp = re.sub(pattern, '', isbn)
        if isbn_temp != isbn:
            return False
    return True
#print(isValidISBN('9783333333335'))
def get_valid_isbn_strict(content):
    content = content.upper()
    ctx = content.split("ISBN")
    isbn_data = []
    if len(ctx) <=1:
        return []

    for c in ctx[1:]:
        text = getStr(c)
        text = text[0: 35]
        isbn_list = getValidISBN(text)
        for isbn in isbn_list:
            if isbn not in isbn_data:
                isbn_data.append(isbn)
    return isbn_data

def getValidISBN(content):
    content = getStr(content)
    #print(content)
    isbn_like = isbnlib.get_isbnlike(content)
    isbn_list = []
    #print('isbn_like = ', end = '')
    #print(isbn_like)
    for isbn in isbn_like:
        isbn = isbnlib.canonical(isbn)
        isbn13 = ''
        if isbnlib.is_isbn10(isbn):
            isbn13 = isbnlib.to_isbn13(isbn)   
        elif isbnlib.is_isbn13(isbn):
            isbn13 = isbn
            
        if (isbn13) and (isbn13 not in isbn_list):
            #isbn13 = str(isbn13)
            if isValidISBN(isbn13):
                isbn_list.append(isbn13)
    return isbn_list
def getStr(content):
    content = content.replace("一", "")
    
    pattern = re.compile(r'[ ]{0,}-[ ]{0,}', re.IGNORECASE)
    out = re.sub(pattern, '', content)
    
    pattern = re.compile(r'isbn[ \-]{0,}13', re.IGNORECASE)
    out = re.sub(pattern, '', out)
    pattern = re.compile(r'isbn[ \-]{0,}10', re.IGNORECASE)
    out = re.sub(pattern, '', out)
    
    pattern = re.compile(r'[^\x00-\xff]{1,}', re.IGNORECASE)
    out = re.sub(pattern, '', content)
    
    pattern = re.compile(r'[ \-]{1,}')
    out = re.sub(pattern, '', out)
    out = out.replace(".","")
    out = out.replace("*","")
    out = out.replace("－", "")
    out = out.replace("-", "")
    out = out.replace("#", "")
    out = out.replace("唱", "")
    out = out.replace("一", "")
    return out
def extractNumber(content):
    pattern = re.compile(r'[0-9Xx]{10,13}')
    out = re.findall(pattern, content)
    return out

data = '''For general information on our other products and services, or how to create a custom For Dummies 
  book for your business or organization, please contact our Business Development Department in the 
  U.S. at 877‐409‐4177, contact info@dummies.biz, or visit www.wiley.com/go/custompub. For 
  information about licensing the For Dummies brand for products or services, contact 
  BrandedRights&Licenses@Wiley.com. 

  ISBN 978‐1‐119‐14983‐5 (pbk); ISBN 978‐1‐119‐14984‐2 (ebk) '''

#numbers = getValidISBN(data)

#print(numbers)