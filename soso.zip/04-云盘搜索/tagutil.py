import stringutil
import pymysql
import re

import dbutil
from _sqlite3 import Row
mysql = dbutil.mysql

SEP_IN_TAG_STR = '-xx-sep-xx-'
All_Tags = None
Global_tags = ['hackers','cyber risk','mvc','assembly language','paint.net','lumion','qlik sense','javaserver','gamification','iot','bootstrap','embedded systems','active directory','objective-c','data wrangling','opencv','robotics','leap motion','puppet','xna','jenkins','neural networks','gitlab','sas','go','gpu','parallel programming','sharepoint','maven','amazon','cuda','cybersecurity','memcache','cissp','cocos2d-x','web design','opencl','website','squarespace','pentaho','penetration testing','e-learning','objective-c','tableau','play framework','opengl','firebase','qlikview','facebook','unity','inkscape','react','odoo','e-commerce','html','css','ccnp','risk assessment','5G','direct3d','cherrypy','shell','computer vision','hacking','ccna','design patterns','node.js','network','spark','apache kafka','microsoft','mvvm pattern','test-driven','security','web services','reinforcement learning','mobile','software architecture','comptia','wordpress theme','responsive design','wordpress plugins','hacker','powershell','scratch','web scraping','bots','gui programming','qt','regular expressions','sqlite','corona','raspberry pi','ai applications','blender','ethereum','solidity','yii','pandas','data analysis','penetration testing','data mining','solaris','2d game','3d game','data structures','responsive web design','data visualization','kotlin','ansible','d3.js','lego','laravel','game ai','machine learning','scikit-learn','keras','tensorflow','mongodb','web development','artificial intelligence','arduino','nginx','jsf','aws','app','app development','scala','soa','deep learning','testing','google cloud','goole','big data','hadoop','express','node','functional programming','elixir','nosql','game engine','game','data mining','clojure','pattern recognition','machine learning','vim','clojure','shiny','data science','galileo','vue.js','kubernetes']

def getAllTags():
    global All_Tags
    global Global_tags
    if All_Tags:
        return
    sql = 'SELECT tag_name FROM `stackoverflow.com`.`all_tag` where tag_num > 1000 or tag_valid=1'
    All_Tags = mysql.execQuery(sql)
    m = [t[0] for t in All_Tags]
    All_Tags = m
    All_Tags.extend(Global_tags)   
    print('loading tags num = ' + str(len(All_Tags)))

def isvalidTag(tag):
    tags = tag.split()
    flag = True
    invalid_tags = ['pdf','book','ebook']
    # each word contains A-Z0-9
    for t in tags:
        #
        t = t.strip()
        lower_t = t.lower()
        if lower_t in invalid_tags:
            return False
        
        pattern = r'[^A-Z0-9]{1,}'
        temp = re.sub(pattern, "", t)
        temp = temp.strip()
        if len(temp) == 0:
            return False
    return True

def getTags(title):
    global All_Tags
    getAllTags()
    res = []
    invalid_tags = ['pdf','book','ebook']
    
    title =title.replace(":"," ")
    title =title.replace("&"," ")
    title =title.replace("'"," ")
    title =title.replace("\""," ")
    title =title.replace("("," ")
    title =title.replace(")"," ")
    title =title.replace("["," ")
    title =title.replace("]"," ")
    title =title.replace("%"," ")
    title =title.replace("<"," ")
    title =title.replace(">"," ")
    title =title.replace("/"," ")
    title =title.replace("\\"," ")
    title =title.replace("!"," ")
    title =title.replace("®"," ")
    
    title = " "+title+" "
    for t in All_Tags:
        #t = t[0]
        m = " "+t+" "
        rt = stringutil.getsubstrFromString(title, m)
        if not rt:
            continue
        rt = rt.strip() 
        if not isvalidTag(rt):
            continue
        restemp = [w.lower() for w in res]
        if rt.lower() not in restemp and rt.lower not in invalid_tags:
            res.append(rt)
    return res


title = 'web Application Development with Yii and PHP'
res = getTags(title)
print(res)