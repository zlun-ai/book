import urllib.parse
from bs4 import BeautifulSoup
import fileutil
import io
import sys
import re
import json
from unidecode import unidecode
import htmlutil
import docutil
import nltkutil


def getSearchKeywords(html):
    soup = BeautifulSoup(html, "html.parser")
    
    k = []
    tag = 'search?q='
    for link in soup.find_all('a'):
        href = link.get('href')
        if href and tag in href:
            ks = link.get_text()
            k.append(ks)
    return k
#-----------------------------

def isValidLink(link):
    if link.count('.google.com') > 0:
        return False
    if link.count('//google.com') > 0:
        return False
    return True
    
def removeHTMLTagName(soup, taglist=['script', 'style']):
    for i in taglist:
        [x.unwrap() for x in soup.find_all(i)]
    
    return str(soup)

def removeStyle(soup):
    [x.extract() for x in soup.find_all('style')]
    return soup

def removeScript(soup):
    [x.extract() for x in soup.find_all('script')]
    return soup

def removeHTMLTag(soup, taglist=['script', 'style']):
    for i in taglist:
        [x.extract() for x in soup.find_all(i)]
    
    return str(soup)

def getTableOfContents(html_doc):
    soup = BeautifulSoup(html_doc, 'html.parser')
    table_body = soup.find_all("div", "card")
    #print(table_body)
    return table_body
    
def getSearchResult(soup):   
    
    def has_a_characters(css_class):
        return css_class is not None and css_class == 'rc' and len(css_class) == 2

    results = soup.find_all("div", class_=has_a_characters)
    for r in results:
        print(r)
    return results
    
def parseEachItem(card):
    #print(card)
    card = str(card)
    #print(dir(card))
    soup = BeautifulSoup(card, "html.parser")
    
    #title,link,desc
    titles = soup.find_all("h3")
    if len(titles) < 1:
        return None
    title = titles[0].string
    
    link_a = titles[0].parent
    #print(link_a)
    if not link_a:
        return None
    link_a_name = link_a.name
    #print(link_a_name)
    if link_a_name != 'a':
        print('h3 parent is <a>')
        exit(0)
    link_url = link_a.get('href')
    
    #desc
    desc = ''
    descs = soup.find_all("span", "st")
    #print(descs)
    if len(descs) >= 1:
        desc = descs[0]
        #print(desc.get_text())
        desc = str(desc)
        
    return title, link_url, desc


    
    
#file = 'F:\\All-Books\\192a84d98b500f01cce7faaf12d99148.html'

def processFile(link_slug, file):
    content = fileutil.readFile(file)
    if not content:
        return
    #print(type(content))
    cards = getTableOfContents(content)
    #print(dir(cards))
    #print(len(cards))
    
    #print(type(cards))
    item={}
    for c in cards:
        #print(dir(c))
        #print(type(c))
        item_name, sub_item_name = parseEachItem(c) #<class 'bs4.element.Tag'>
        if len(item_name) > 2:
            item[item_name] = sub_item_name
    #if not item:
       # return
    print(item)
    item_string = json.dumps(item)
    print(type(item_string))
    print(item_string)
    item_self =  json.loads(item_string)
    
    print(type(item_self))
    print(item_self)
    
    crawldb.updateLinkInfo(link_slug, item_string)
    
def process(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    results = getSearchResult(soup)
    
    linkInfo = []
    for r in results:
        item = parseEachItem(r)
        title = docutil.getLinkTitle(item[0],item[2],item[1], doc_type='pdf')
        print(item)
        print(title)
        info={}
        info['title'] = title
        info['link'] = item
        linkInfo.append(info)
    return linkInfo
#content = fileutil.readFile('result.html')
#process(content)