import urllib.parse
from bs4 import BeautifulSoup
import googletextparser
import fileutil
import docutil
import stringutil
import htmlutil
import linkdb
import html
import re
import urlutil

def isValidLink(link_url):
    sites = ['.pinterest.com','.mobileread.mobi','.abebooks.com','.bol.com','.aliexpress.com','.ebook2share.com','ebookcore.com','browsedocs.com','ebook.stepor.com','.ebooks.com','.ebay.com','.researchgate.net','.semanticscholar.org','.dailymotion.com','.amazon.','archive.org','.youtube.','goodreads.com','.wikipedia.org','.imdb.com','.google.','//google.com','pdfavor.com','steporebook.com','freeaibook.com']
    for s in sites:
        if link_url.count(s) > 0:
            return False
    paths = ['url=','/image/','/images/','/video/','/search/','/tag/','/product/','/products/','/doi/','/shop/','/search?','q=','key=','s=']
    
    for s in paths:
        if link_url.count(s) > 0:
            return False
    arr = ['https://','http://','ftp://']
    flag = False
    for s in arr:
        if link_url.startswith(s):
            flag = True
    if not flag:
        return False
    #is root url
    if(urlutil.isRootURL(link_url)):
        return False
    return True

def removeCommonStr(text):
        text = text.lower()
        text = " "+text+" "
        arr=['novel','for',"free","download","and","online","ebook","e-book","book","by","books","ebooks","e-books",'a','an','the','of','to','in','at','on'];
        
        for a in arr:
            text = text.replace(" "+a+" ", " ")
        
        arr=['pdf','chm','epub','mobi','azw','azw3','azw6']
        for a in arr:
            text = text.replace(" "+a+" ", " ")
        text = stringutil.removeEmpty(text)
        return text

def fixLinkName(link_name):
    
    link_name = html.unescape(link_name)
    #remove blank
    pattern = re.compile(r'[ ]{2,}')
    link_name = re.sub(pattern, ' ', link_name)
    link_name = link_name.strip()
    
    link_name=link_name.replace("|"," - ")
    link_name=link_name.replace("⋙"," - ")
    link_name=link_name.replace(">>"," - ")
    link_name=link_name.replace("..."," - ")
    
    title_arr = link_name.split(" - ") 
    #get longest 
   
    t=""
    for title in title_arr:
        title_temp = removeCommonStr(title)
        t_temp = removeCommonStr(t)
        
        title_temp = stringutil.getStringSlug(title_temp)
        t_temp = stringutil.getStringSlug(t_temp)
        
        if len(title_temp) > len(t_temp):
            t = title
    return t
    
                
                    
        
     
def isBookDownloadLink(link_url, link_title, link_desc, book_name, dot = 'pdf'):
    if not isValidLink(link_url):
        return None
    flag = True
    if not book_name:
        flag = True
    else:
        flag = checkByRuleOne(link_url, link_title, link_desc, book_name, dot)
    
    if flag:
        print("check by rule two")
        flag = checkByRuleTwo(link_url, link_title, link_desc, book_name, dot)
        if not flag:
            print("check by rule 3")
            flag = checkByRuleThree(link_url, link_title, link_desc, book_name)
            
        if not flag:
                return None
        type = getDownloadType(link_url, link_title, link_desc)
        return type
     
    return None
    
def checkByRuleTwo(link_url, link_title, link_desc, book_name, dot):
    link_fixed_title = fixLinkName(link_title)
    link_title = stringutil.getStringSlug(link_fixed_title)
    link_title = link_title.lower()
    link_title = " " + link_title +" "
    print('link fix title in rule 2 = ' + link_title)
    formats = ['pdf','chm','epub','mobi','azw','azw3','azw6']
    for dotx in formats:
        dotx = " " + dotx +" "
        if link_title.count(dotx) > 0:
            return True
    
    if link_title.count(" download ") > 0:
        return True
    return False

def getDownloadType(link_url, link_title, link_desc):
    
    fomats = ['pdf','chm','epub','mobi','azw','azw3','azw6']
    link_desc = htmlutil.filter_tags(link_desc)
    link_desc = stringutil.getStringSlug(link_desc)
    link_desc = link_desc.lower()
    link_desc = " " + link_desc +" "
    
    link_fixed_title = fixLinkName(link_title)
    link_title = stringutil.getStringSlug(link_fixed_title)
    link_title = link_title.lower()
    link_title = " " + link_title +" "
    
    text = link_title + link_desc
    r=[]
    for d in fomats:
        if text.count(" " + d +" ") > 0:
            if d == 'azw3' or d == 'azw6':
                d = 'azw'
            if d not in r:
                r.append(d)
    return ','.join(r)
    
    

def checkByRuleThree(link_url, link_title, link_desc, book_name):
    
    link_desc = htmlutil.filter_tags(link_desc)

    link_desc = stringutil.getStringSlug(link_desc)
    link_desc = link_desc.lower()
    link_desc = " " + link_desc +" "

    if link_desc.count(" download ") > 0:
        formats = ['pdf','chm','epub','mobi','azw','azw3','azw6']
        for dot in formats:
            dot = " " + dot +" "
            if link_desc.count(dot) > 0:
                return True
    return False

def checkByRuleOne(link_url, link_title, link_desc, book_name, dot):
    #info = docutil.getLinkTitle(link_title,link_desc,link_url, doc_type= dot)
       
    link_fixed_title = fixLinkName(link_title)
    
    print(link_title+";"+link_fixed_title)
       
    book_name = book_name.lower()
    link_fixed_title = link_fixed_title.lower()  
    link_slug = stringutil.getStringSlug(link_fixed_title)
    book_slug = stringutil.getStringSlug(book_name)
    
    link_slug = removeCommonStr(link_slug)
    book_slug = removeCommonStr(book_slug)
    
    print(link_slug+";"+book_slug)
       
    link_slug_len = len(link_slug)

    if len(book_slug) > 60:
        book_slug = book_slug[0:60]
        book_slug = book_slug.strip()
        
    book_slug_len = len(book_slug)
    
    per = link_slug_len/book_slug_len
    print(per)
    if per < 0.4:
        return False
    
    '''if book_slug_len > link_slug_len:
        book_slug = book_slug[0:link_slug_len]
        book_slug = book_slug.strip()'''
    book_slug_len = len(book_slug)    
        
           
    common_str = stringutil.longest_Substring(link_slug, book_slug) 
    if not common_str:
        return False
    common_str = common_str.strip()
    print(common_str) 
    #repair
    e_in_book_slug = book_slug.count(" ")
    
    print("common blank = "+ str(common_str.count(" ")))
       
    
    if common_str.count(" ") <=1 :
        if e_in_book_slug > 2:
            return False
    if common_str.count(" ") < e_in_book_slug and e_in_book_slug <1:
        return False
      
    common_len=len(common_str)
    
    book_arr = book_slug.split(" ")
    link_arr = link_slug.split(" ")
    common_arr = common_str.split(" ")
    similar_book_num = 0
    similar_link_num = 0
    for c in common_arr:
        if c in book_arr:
            similar_book_num = similar_book_num+1
        if c in link_arr:
            similar_link_num = similar_link_num+1
    
    
    #per = common_len/book_slug_len
    book_per = similar_book_num / len(book_arr) 
    link_per = similar_link_num / len(link_arr) 
    
    print("common = "+str(per))
    print("book common = "+str(book_per)+"; link common="+str(link_per))
    if book_per >= 0.67 and link_per>=0.33:
        
        return True
    
    '''similar = stringutil.string_similar(link_slug, book_slug)
    print(similar)
    if similar > 0.7:
        return True'''
    return False
       
       

def getAbsoluteURL(base_url, relative_url):
    url = urllib.parse.urljoin(base_url, relative_url)
    ux = urllib.parse.urldefrag(url)
    return ux[0]

def getAllLinks(url, html_doc):
    soup = BeautifulSoup(html_doc, 'html.parser')
    
    links = []
    for link in soup.find_all('a'):
        l = link.get('href')
        l = getAbsoluteURL(url, l)
        if l not in links:
            if allowURL(l):
                links.append(l)
            
    return links

def removeScript(soup):
    [x.extract() for x in soup.find_all('script')]
    return soup

def removeStyle(soup):
    [x.extract() for x in soup.find_all('style')]
    return soup
def processLink(link_url, link_title, link_desc, book_name):
    print("link url = " + link_url)
    link_title = htmlutil.filter_tags(link_title)
    book_download_type = isBookDownloadLink(link_url, link_title, link_desc, book_name, dot = 'pdf')
    if not book_download_type:
        return
    print(book_download_type)
    #add book download link
    link_fix_name = fixLinkName(link_title)
    print(link_fix_name)
    #print(link_desc)
    linkdb.addLink(link_title, link_url, link_desc, link_fix_name, book_download_type)

    
def process(html_content, book_name):
    google_search_results = googletextparser.get_search_results(html_content)
    #print(google_search_results)
    for link in google_search_results:
        print("link url = " + link['url'])
        book_download_type = isBookDownloadLink(link['url'], link['title'], link['desc'], book_name, dot = 'pdf')
        if not book_download_type:
            continue
        print(book_download_type)
        #add book download link
        link_fix_name = fixLinkName(link['title'])
        
        linkdb.addLink(link['title'], link['url'], link['desc'], link_fix_name, book_download_type)

def processfile(file, book_name):
    content = fileutil.readFile(file)
    process(content,book_name)
    