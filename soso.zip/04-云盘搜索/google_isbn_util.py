import json

def get_book_info(json_text):
    data = json.loads(json_text)

    r = {}
    r["from"] = url
    r["标题"] = ''
    r["副标题"] = ''
    r["原标题"] = ''

    r["作者"] = ''
    r["译者"] = ''
    r["出版社"] = ''
    r["出版时间"] = ''
    r["页数"] = ''
    r["丛书"] = ''
    r["评分"] = ''
    r["ISBN"] = ''
    r["封面"] = ""

    r['简介'] = ''
    r['作者简介'] = []
    r['目录'] = []

