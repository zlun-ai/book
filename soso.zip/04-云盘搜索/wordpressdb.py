import stringutil
import pymysql


import dbutil
mysql = dbutil.mysql

def addPost(title, content, slug_text):
    md5 = stringutil.getMD5(slug_text)
    title = pymysql.escape_string(title)
    content = pymysql.escape_string(content)
    
    pid = getPost(md5)
    if pid:
        return True
    sql = "insert into `wp_posts` (post_author,post_title,post_name,post_content,post_status,post_type) values(1,'"+title+"','"+md5+"','"+content+"','draft','post')";
    flag = mysql.execSql(sql)
    return flag
def getNeedSearchLink():
    sql = "SELECT link_id ,link_domain ,link_alexa FROM all_link where  link_visit_time = '0000-00-00 00:00:00' order by link_id asc limit 0,1"
    result = mysql.execQuery(sql)
    
    return result

def getLinkbyURL(url):
    url = url.strip() #remove blank
    sql = "select * from all_link where link_domain = '"+ url +"'"
    row = mysql.execQuery(sql)
    if len(row) < 1:
        return None
    #print(row[0][0])
    if not row or not row[0][1]:
        return None
    return row[0]
    
def addLink(link_url):
    link = getLinkbyURL(link_url)
    if not link:
        link_url = link_url.strip() #remove blank
        sql = "insert into all_link (link_domain) values ('" + link_url +"')"
        print(sql,flush = True)
        flag = mysql.execSql(sql)
    else: # 
        return
    
def addLinks(links):
    for url in links:
        addLink(url)
        
def updateLinkInfo(id, info=None):
    if not info:
        return
    sql = "update all_link set "+info+" where link_id = "+str(id)
    flag = mysql.execSql(sql)  
def updateLink(id, isprocess = 1):
    sql = "update all_link set is_process = "+ str(isprocess)+" where link_id = "+str(id)
    flag = mysql.execSql(sql)   
    
'''def updateLinkInfo(slug, link_desc):
    link_desc = pymysql.escape_string(link_desc)
    sql = "update all_link set link_desc='"+link_desc+"' where link_slug='"+slug+"'"
    #print(sql,flush = True)
    flag = mysql.execSql(sql)   ''' 
    
def getAllLinks(keys='link_id, link_slug'):
    print('query all links in db')
    sql = "select " + keys +" from all_link  order by link_id asc"
    print(sql)
    row = mysql.execQuery(sql)  
    return row
    
def getPost(md5):
    sql = "select  ID from `wp_posts` where post_name='"+md5+"' or post_name='"+md5+"___trashed'"
    row = mysql.execQuery(sql)
    if len(row) < 1:
        return None
    return row[0][0]