import os
import netutil
import fileutil

def get_image_data(image_url):
    content = netutil.getcontentfromurl(image_url, proxy=False)
    if content:
        print(f"content len = {len(content)}")
        if len(content)<3000:
            return None
        return  content

def save_image_data(image_data, fx):
    if image_data is None:
        return
    if os.path.exists(fx):
        return
    fileutil.save_data(image_data, fx)