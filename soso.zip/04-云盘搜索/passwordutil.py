import hashlib
import base64
import pyzipper
from pymupdf.mupdf import pdf_get_widget_editing_state

import fileutil
import os
    
def getMD5(str):
    str = str.encode("utf-8")
    hash_obj = hashlib.md5(str)
    return hash_obj.hexdigest()

def get_password(text, num = 6):
    text = "YYYYY-"+text.strip()+"-"+"YYYYY"
    md5 = getMD5(text)
    return md5[0:num]

def compress(src_file, dest_file):
    dirname, filename, extend = fileutil.getFilePathInfo(src_file)
    with pyzipper.AESZipFile(dest_file, 'w', encryption=pyzipper.WZ_AES, compression=pyzipper.ZIP_LZMA) as zf:

        psw = get_password(filename)
        src_psw = psw
        print(f"psw = {psw}")
        #'中文密码'.encode('utf-8')
        psw = psw.encode("utf-8")
        zf.setpassword(psw)
        zf.write(src_file, arcname=os.path.basename(src_file))
        if os.path.exists(dest_file):
            return dest_file, src_psw
        return None, None