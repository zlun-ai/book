import re
import sys
import io
import urllib.parse
import html
import stringutil
import urlutil
from bs4 import BeautifulSoup

def getAllLinks(data, base_url = None):
    soup = BeautifulSoup(data, "html.parser")
    root = None
    if base_url is not None:
        base_root_url, scheme, root = urlutil.getRootURL(base_url)
    
    
    links = soup.find_all("a")
    arr=[]
    x = []
    for l in links:
        u = l.get('href')
        if root is None:
            if "//" in u:
                if root not in u:
                    continue
        t = str(l)
        #if t.count("<")>=3:
            #continue
        t = l.get_text()
        t = t.strip()
        if t == "" or len(t) < 3 or stringutil.containsNonAscii(t) or stringutil.isAllNumber(t):
            continue
        if not stringutil.containsEnglishChar(t):
            continue
        t = stringutil.removeEmpty(t, True)
        if t not in x:
            arr.append(t)
            x.append(t.lower())
    return arr
        
    
def getAbsoluteURL(base_url, relative_url):
    url = urllib.parse.urljoin(base_url, relative_url)
    ux = urllib.parse.urldefrag(url)
    return ux[0]
def getURLFromLocalFile(content):
    pattern = '<urlele[^>]*>([^<]*)<\s*/\s*urlele\s*>'
    
    matcher = re.findall(pattern, content, re.IGNORECASE)
    if matcher:
        return matcher[0]
    return None

def getTags(content, tag):
    pattern = '<\s*'+tag+'[^>]*>([^<]*)<\s*/\s*'+tag+'\s*>'
    
    matcher = re.findall(pattern, content, re.IGNORECASE)
    return matcher

#str='programming to cover some of <em>Java\'s</em> more <em>advanced</em> capabilit'
#print(getTags(str, tag='em'))

def filter_taglist(htmlstr, taglist=['td','a'], include_text = False):
    
    if include_text:
        for i in taglist:
            re_tag = re.compile('<\s*'+i+'[^>]*>.*?<\s*/\s*'+i+'\s*>',re.I)
            htmlstr = re_tag.sub("", htmlstr)
    else:
        for i in taglist:
            re_tag = re.compile('<\s*'+i+'[^>]*>',re.I)
            htmlstr = re_tag.sub("", htmlstr) 
            re_tag = re.compile('<\s*/\s*'+i+'\s*>',re.I)
            htmlstr = re_tag.sub("", htmlstr)   
    htmlstr = htmlstr.strip()
    return htmlstr

def get_clean_content(htmlstr):
    htmlstr = filter_tags(htmlstr)
    return filterBlank(htmlstr)
def filter_tags(htmlstr, seg = "", include_html_tag = True):
    htmlstr = htmlstr.strip()
    re_cdata=re.compile('//<!\[CDATA\[[^>]*//\]\]>',re.I) #匹配CDATA
    re_script=re.compile('<\s*script[^>]*>[^<]*<\s*/\s*script\s*>',re.I)#Script
    re_style=re.compile('<\s*style[^>]*>[^<]*<\s*/\s*style\s*>',re.I)#style
    re_br=re.compile('<br\s*?/?>')#处理换行
    if include_html_tag:
        re_h=re.compile('</?\w+[^>]*>')#HTML标签
    re_comment=re.compile('<!--[^>]*-->')#HTML注释
    blank_line=re.compile('\n+')

    #过滤匹配内容
    s=re_cdata.sub(seg,htmlstr)#去掉CDATA
    s=re_script.sub(seg,s) #去掉SCRIPT
    s=re_style.sub(seg,s)#去掉style
    s=re_br.sub('\n',s)#将br转换为换行
    if include_html_tag:
        s=re_h.sub(seg,s) #去掉HTML 标签
    s=re_comment.sub(seg,s)#去掉HTML注释
    s=blank_line.sub('\n',s)#去掉多余的空行

    return s
def filterBlank(str):
    b = re.compile(r'\s{2,}')
    str = b.sub('', str)
    return str
def getTitle(html_data):
    soup = BeautifulSoup(html_data, "html.parser")
    title = ''
    if soup.title is not None:            
        title = soup.title.string
        if title is None:
            title = ""
            title = title.strip()
    title = html.unescape(title)
    
    return title
def getDesc(html_data):
    desc = getMeta(html_data, 'description')
    if desc == "":
        desc = getMeta(html_data, 'og:description')
    if desc == "":
        desc = getMeta(html_data, 'twitter:description')
    desc = html.unescape(desc)
    return desc
def getMeta(html_data,name):
    pattern = r'<meta.*?>'
    #re.match(pattern, html, re.I)
    matcher = re.findall(pattern, html_data, re.I+re.S)
    #print(matcher)
    if matcher:
        for m in matcher:
            m = m.replace("property=",'name=')
            
            t1 = 'name="'+name+'"'
            t2 = 'name=\''+name+'\''
            if t1.lower() in m.lower() or t2.lower() in m.lower():
                text = m
                
                text = text.replace('Content=','content=')
                
                text = text.replace('content=\'','content="')
                 
                if 'content="' in text:
                    ts = text.split('content="')
                    text = ts[1]
                    
                    text = text.replace("'",'"')
                    if '"' in text:
                        ts = text.split('"')
                       # print(ts)
                        text = ts[0]
                        return text.strip()
    return ''

def isEnglishSite(data):
    #除去tag
    data = filter_tags(data)
    data = html.unescape(data)
    
    data = stringutil.removeEmpty(data, newline = True)
    
    #去除非英文
    pattern = re.compile(r'[\x00-\xff]{1,}', re.I+re.S)
    str = re.sub(pattern, '', data)
    str = str.strip()
    
    if len(str)<10:
        return True
    
    l1 = len(str)
    l2 = len(data)
    print(l1/l2)
    if l1/l2 > 0.15:
        return False
    return True