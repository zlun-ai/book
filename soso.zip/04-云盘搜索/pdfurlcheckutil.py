import netutil
import urllib.request


def isValidDownloadURL(url, proxy=False):
    response = getPdfDownloadResponse(url, proxy)
    return parseResponse(response)


def getPdfDownloadResponse(url, proxy=False):
    crawl_response = None
    try:
        crawl_response = netutil.getResponse(url, proxy)
    except urllib.error.HTTPError as exh:
        print(exh)
    except urllib.error.URLError as ex:
        print(ex)
    except Exception as e:
        print(e)
        crawl_response = None
    return crawl_response


def parseResponse(response):
    print(response)
    if response is None:
        return False, False, None, None

    try:
        response_code = response.getcode()
        print(response_code)
        if response_code == 404 or response_code == 403:
            return False, False, None, response_code
        if response_code == 200:
            # size = response.getheader("Content-Length") #None
            # print(size)
            message = response.info()
            content_type = message.get_content_type()
            print(dir(message))
            print(content_type)
            content_type = content_type.lower()
            print(message)
            content_lenth = -1
            size = response.getheader("Content-Length")
            if size is None:
                size = response.getheader("content-length")
            if content_type in 'application/force-download':
                return True, False, size, response_code

            if content_type in 'application/pdf' or content_type in 'application/octet-stream':
                return True, False, size, response_code
            if content_type == 'text/html':
                # content = response.read()
                return False, True, size, response_code

    except Exception as e:

        print(e)
    return False, False, None, response_code


url = 'https://www.programmer-books.com/wp-content/uploads/2018/12/Deep-Learning-with-Azure.pdf'
isValidDownloadURL(url)
