import time

import stringutil
import htmlutil
import json
import tabledb
import re
import book_util
import requests
from modelscope import AutoModelForCausalLM, AutoTokenizer
from collections import Counter
from openai import OpenAI
import concurrent.futures
import random
'''
llama-server -m D:\ProgramData\models\Qwen3-1___7B-GGUF\Qwen3-1.7B-Q8_0.gguf --jinja --ctx-size 2048  --predict 100 
'''
#from modelscope import AutoModelForCausalLM, AutoTokenizer
prompt = """
您擅长基于图书对应的文件名称对文件进行分类，并生成3-5个关键词。已知图书分类如下：
- 小说文学
- 经济管理
- 历史军事
- 计算机类
- 人文社科
- 艺术摄影
- 哲学宗教
- 医学健康
- 政治法律
- 自然科学
- 教材教辅
- 其他类型

## 输出格式：
- 文件名称=[输入文件名], 分类=[分类名称], 关键词=[关键词1，关键词2，关键词3，关键词4，关键词5]
- 分类和关键词的结果必须使用[]进行包括。
- 示例1：
文件名=[小儿推拿秘诀中国古医籍整理丛书张登本], 分类=[医学健康], 关键词=[儿童健康，医学，张登本]
- 示例2：
文件名=[趣读世界史共5册], 分类=[历史军事], 关键词=[世界历史，历史教育]

## 限制：
- 请直接输出输入的文件名称对应的最可能的一个的分类名称，当不确定文件属于哪个分类时，输出**其他类型**.
- 严格按照**输出格式**指定的格式输出最终答案。
- 注意：输出的分类名称必须在上面列举的分类名称中，不能输出其他的名称。
- 关键词要求：1.输出的关键词必须能够反映图书文件名的内涵。2.关键词尽可能不要在文件名中。3.关键词最好不要出现数字。

输入的文件名称为：{file}
            """
tokenizer = None
model = None
def get_llm_out(file_name):
    global  tokenizer, model

    model_name = r"C:\Users\余治伦\.cache\modelscope\hub\models\Qwen\Qwen3-1___7B"

    if tokenizer is None:
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype="auto",
            device_map="cpu"
        )



    # prepare the model input
    file_name = file_name[0:50]
    print(f"file_name = {file_name}")
    prompt = prompt.strip().replace("{file}", file_name)
    messages = [
        {"role": "user", "content": prompt}
    ]
    text = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=False  # Switches between thinking and non-thinking modes. Default is True.
    )
    model_inputs = tokenizer([text], return_tensors="pt").to(model.device)

    t = random.randint(60, 80)/100
    # conduct text completion
    generated_ids = model.generate(
        **model_inputs,
        temperature= 0.7,#0.6,#0.7,  # 控制生成随机性
        top_p= 0.8, #0.95, #0.8,  # 核采样参数
        top_k=20,  # 限制候选词数量
        min_p=0,  # 最小概率阈值
        max_new_tokens=8000,  # 生成的最大token数量
        do_sample=True  # 启用采样（必须设置为True才能使用上述参数）

    )
    output_ids = generated_ids[0][len(model_inputs.input_ids[0]):].tolist()

    # parsing thinking content
    try:
        # rindex finding 151668 (</think>)
        index = len(output_ids) - output_ids[::-1].index(151668)
    except ValueError:
        index = 0

    thinking_content = tokenizer.decode(output_ids[:index], skip_special_tokens=True).strip("\n")
    content = tokenizer.decode(output_ids[index:], skip_special_tokens=True).strip("\n")
    print(f"content={content}")
    return content
def get_llm_from_route(file_name):
    global prompt
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key="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",
    )
    llm_prompt = prompt.strip().replace("{file}", file_name)
    completion = client.chat.completions.create(
        extra_headers={
            "HTTP-Referer": "<YOUR_SITE_URL>",  # Optional. Site URL for rankings on openrouter.ai.
            "X-Title": "<YOUR_SITE_NAME>",  # Optional. Site title for rankings on openrouter.ai.
        },
        extra_body={},
        model="qwen/qwen3-14b:free",
        messages=[
            {
                "role": "user",
                "content": llm_prompt
            }
        ]
    )
    ctx = completion.choices[0].message.content
    print(completion.choices[0].message.content)
    return ctx
def get_request(file_name):
    url = " http://210.42.32.22:8100/v1/chat/completions"
    global  prompt
    headers = {
        "Content-Type": "application/json",
    }

    tprompt = prompt.strip().replace("{file}", file_name)
    data = {
        "model":"Qwen3-30B-A3B-Thinking-2507",
        "messages": [
          {"role": "system", "content": "你是一个乐于助人的助手。"},
          {"role": "user", "content": tprompt}
        ],
        "max_tokens": 12000,
        "temperature": 0.7,
       # "top_p": 0.95,
        "stream": False
    }
    #print(data)
    response = requests.post(url, headers=headers, json=data, stream=False)
    #print(response.choices[0].message.content)
    print(response)
    dict_obj = json.loads(response.content.decode('utf-8'))
    #print(dict_obj)
    ctx = dict_obj["choices"][0]["message"]["content"]
    #print(ctx)
    if "</think>" in ctx:
        ctx = ctx.split("</think>")[-1]
    return ctx

def get_book_cat(file_name):
    cats = ['小说文学','经济管理','历史军事','计算机类','人文社科','艺术摄影','哲学宗教','医学健康','政治法律','自然科学','教材教辅','其他类型']
    max = 1
    candi = []
    cname = ""
    ctag = []
    for i in range(max):
        try:
            out = get_request(file_name)
        except Exception as e:
            print(e)
            out = ""
            continue
        cat_text = stringutil.cut(out, "分类=","]")
        for c in cats:
            if c in cat_text:
                #candi.append(c)
                #return c
                cname = c
                break
    tags = stringutil.cut(out, "关键词=[","]")
    tags=tags.replace("，",',').split(",")
    for t in tags:
        t = t.strip()
        if len(t)>=2:
            ctag.append(t)
    ctag = "，".join(ctag)
    #if len(candi)<3:
        #return ""
    #c = Counter(candi).most_common(1)[0][0]
    return cname, ctag


def get_valid_file_name(file_name):
    dirname, filename, extend = fileutil.getFilePathInfo(file_name)
    filename = remove_date(filename)

    return filename
def get_all_links():
    all_links = []
    #遍历所有的链接
    table = "yunpan_link"
    keys = 'link_id, link_name, link_url, file_name, file_category'
    data= {'link_status':200}
    links = tabledb.query(table, keys, data, orderby = "link_id asc", num = None)

    for link in links:
        link_id = link[0]
        link_file_name = link[3].lower().strip()
        file_cat=link[4]
        if file_cat is not None and file_cat !="":
            continue

        link_name = link[1]
        if link_file_name =="":
            continue

        if book_util.is_book_name(link_file_name):
            print("book name=", book_util.get_valid_book_name(link_file_name))
            all_links.append((link_id, book_util.get_valid_book_name(link_file_name)))
    return all_links

all_links = get_all_links()
print(len(all_links))
#for link in all_links[0:1000]:
def process(link):
    time.sleep(1)

    link_id, link_file_name = link
    cname, ctag = get_book_cat(link_file_name)
    print(link_file_name, cname, ctag)

    #print(f"file = {link_file_name}, cat = {c}")
    if cname != "":
        tabledb.update("yunpan_link", update_data={'file_category': cname, "file_tag": ctag}, where_data={'link_id': link_id})

def main(items):
    # 要处理的列表
    # 方法1: 使用map处理（保持顺序）
    print("=== 使用map处理 ===")
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        # map保持输入顺序
        results = list(executor.map(process, items))



if __name__ == "__main__":
    main(all_links)