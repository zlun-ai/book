import sys, fitz
#import colorgram
import re
import numpy as np
import os
import fileutil
import isbnutil
import stringutil
import htmlutil
import time
import image2textutil
import json

HAS_COVER_NO_ISBN = 1
HAS_ISBN_NO_COVER = 2
HAS_ISBN_COVER = 3


def listToJson(lst):
    keys = [str(x) for x in range(len(lst))]
    list_json = dict(zip(keys, lst))
    str_json = json.dumps(list_json, indent=2, ensure_ascii=False)  # json转为string
    return str_json


def parseBookmar(bookmark_list):
    return listToJson(bookmark_list)


def isEncript(content):
    content = content.strip()
    if len(content) < 1:
        return False
    pattern = re.compile(r'[ \n\r\t]{1,}', re.IGNORECASE)
    content = re.sub(pattern, '', content)

    pattern = re.compile(r'[^a-z0-9\.]{1,}', re.IGNORECASE)
    content_temp = re.sub(pattern, '', content)

    l1 = len(content)
    l2 = len(content_temp)
    l1 = float(l1)
    l2 = float(l2)
    p = l2 / l1
    print('percent is = ' + str(p))
    if p > 0.5:
        return False
    return True

def is_norm_pdf(f):
    doc = None
    flag = False
    try:
        doc = fitz.open(f)
        flag = False
        if len(doc) == 0:
            flag = False  # 文件无页面
        flag = True
    except Exception as e:
        print(e)
        flag = False
    finally:
        if doc is not None:
            doc.close()
    return flag

def isFullPdf(f):
    if not is_norm_pdf(f):
        return False

    end_content = ''
    start_content = ''
    size = os.path.getsize(f)
    if size < 1024:
        return False

    with open(f, 'rb') as fin:  # 读取文本文件
        # start content
        fin.seek(0, 0)
        start_content = fin.read(1024)
        start_content = start_content.decode("ascii", 'ignore')

        fin.seek(-1024, 2)
        end_content = fin.read()
        end_content = end_content.decode("ascii", 'ignore')

    start_flag = False

    # %PDF
    if start_content.count('%PDF') > 0:
        start_flag = True

    if end_content.count('%%EOF') and start_flag > 0:
        return True
    eof = bytes([0])
    eof = eof.decode("ascii")
    print('s')
    print(eof)
    print('d')
    if end_content.endswith(eof) and start_flag:
        return True
    return False
    # pattern = re.compile(r'[\n\r\t\f\]{1,}', re.IGNORECASE)
    # content = re.sub(pattern, '', content)
    # content = content.strip()
    # content = content.replace('%%EOFNUL', '%%EOF')
    # if content.endswith('%%EOF'):
    # if content.count('startxref') > 0:
    # return True
    # return False


# f=r'F:\google-pdf\download\1589-Leap_Motion_Presenter_MQP_Final_Report.pdf'
# print(isFullPdf(f))
def getWH(image):
    pattern = 'width:([0-9]{1,})pt'
    matcher = re.findall(pattern, image, re.IGNORECASE)
    print(matcher)
    w = 0
    if matcher[0]:
        w = matcher[0]
    h = 0
    pattern = 'height:([0-9]{1,})pt'
    matcher = re.findall(pattern, image, re.IGNORECASE)
    if matcher[0]:
        h = matcher[0]
    return int(w), int(h)


def extractImage(html):
    tag = 'img'
    pattern = '<\s*' + tag + '[^>]*>'

    matcher = re.findall(pattern, html, re.IGNORECASE)
    return matcher


def deleteAllAnnotations(page):
    first_annotation = page.firstAnnot
    while first_annotation:
        page.deleteAnnot(first_annotation)
        first_annotation = page.firstAnnot
    return page


def getFirstPageContentByImage(current_page):
    image_matrix = fitz.Matrix(fitz.Identity)
    image_matrix.preScale(2.5, 2.5)

    pix = current_page.getPixmap(alpha=False, matrix=image_matrix)  # render page to an image
    image_name = stringutil.getUnique() + ".png"
    temp_image_file = image_name
    #
    #
    pix.writePNG(temp_image_file)
    # exit(0)
    # resizeImage(temp_image_file, basewidth = 1400)

    text = image2textutil.getImageText(temp_image_file)
    fileutil.deleteFile(temp_image_file)
    if not text:  # error, exception occur
        return None
    return text


def getFirstPageContentByText(current_page, max_words=200):
    text = current_page.getText()
    text = stringutil.removeEmpty(text)
    texts = text.split()
    tx = []
    for t in texts:
        if len(t) > 25 or t == '':
            continue
        tx.append(t)
        if len(tx) >= max_words:
            break
    return " ".join(tx)


def isFirstPDFBook(pages, max_words=150):
    first_page_status = {}
    first_page_status['is_cover'] = False
    first_page_status['delete'] = False
    if not pages:
        first_page_status['delete'] = True
        return first_page_status
    if len(pages) < 2:
        first_page_status['delete'] = True
        return first_page_status

    first_page = pages[0]
    # print(type(first_page))
    # get text
    # print(first_page)
    text = first_page.getText()

    # fileutil.save_to_file('pdftxt.txt', text)
    text = stringutil.removeEmpty(text)
    texts = text.split()
    # print(texts)
    print("text in first page is = " + str(len(texts)))
    max_try_words = 150
    # check is encript
    encript = isEncript(text)
    check_image_text = True
    if len(texts) >= max_words or encript:
        #
        html = ''
        if not encript:
            html = first_page.getText('html')
        # fileutil.save_to_file('pdftxt.html', html)

        if html.count('<img ') > 0:
            # extarct withd and height
            images = extractImage(html)
            for image in images:
                w, h = getWH(image)
                print("w = " + str(w))
                print("h = " + str(h))
                if w > 200 and w < h:
                    first_page_status['is_cover'] = True
                    first_page_status['delete'] = False
                    return first_page_status

        if check_image_text:
            # check text by image
            text = getFirstPageContentByImage(first_page)
            if not text:  # error
                print("get text from pdf image error")
                exit(0)
            text = stringutil.removeEmpty(text)
            # print(text)
            texts = text.split()
            print("text in first page image is = " + str(len(texts)))
            # temp_texts = [t for t in texts if len(t)>=2]
            # stringutil.isALLAZ(t) and
            temp_texts = [t for t in texts if len(t) >= 3]
            print(len(temp_texts))
            print(texts)
            if len(temp_texts) >= 50:
                first_page_status['is_cover'] = False
                first_page_status['delete'] = False
                # if len(temp_texts) > max_try_words:
                # first_page_status['delete'] = True
                first_page_status['delete'] = True

                return first_page_status
            else:
                first_page_status['is_cover'] = True
                first_page_status['delete'] = False
                return first_page_status

    first_page_status['is_cover'] = True
    first_page_status['delete'] = False
    return first_page_status


def isPDF(pdf_file, min_page=22):
    doc, pages = getAllPDFPages(pdf_file)
    print('len=' + str(len(pages)))
    if min_page > len(pages):
        return False
    i = 0
    w_total = 0.0
    h_total = 0.0
    num = 10  # open document
    for page in pages:
        # print(type(page))
        # rec = page.MediaBoxSize
        rec = page.rect
        # print(rec)
        w_total += rec.width
        h_total += rec.height
        i += 1
        if i > num:
            break
    print("w_total=" + str(w_total))
    print("h_total=" + str(h_total))
    # exit(0)
    if w_total > h_total:
        return False
    return True


def getImageMainColor(f):
    colormap = {}
    colormap['White'] = [255, 255, 255]
    colormap['Yellow'] = [255, 255, 0]
    colormap['Orange'] = [255, 153, 51]
    colormap['Red'] = [255, 51, 51]
    colormap['Gray'] = [204, 204, 204]
    colormap['Pink'] = [255, 153, 204]
    colormap['Purple'] = [153, 51, 153]
    colormap['Teal'] = [0, 136, 136]
    colormap['Green'] = [51, 204, 51]
    colormap['Blue'] = [51, 51, 204]
    colormap['Brown'] = [153, 102, 51]
    colormap['Black'] = [0, 0, 0]

    def getColorName(rgb, ColorMap):

        dict = {}
        for c_name, c_rgb in ColorMap.items():
            dist = np.linalg.norm(np.array(rgb) - np.array(c_rgb))
            dict[c_name] = dist
        dict = sorted(dict.items(), key=lambda d: d[1], reverse=False)
        return dict[0][0]

    def getColorMap(f, ColorMap):
        colors = colorgram.extract(f, 20)
        color_list = [(color.rgb, color.proportion) for color in colors]

        dict = {}
        for c in color_list:
            rgb = [c[0].r, c[0].g, c[0].b]
            c_name = getColorName(rgb, ColorMap)
            if c_name in dict:
                dict[c_name] += c[1]
            else:
                dict[c_name] = c[1]
        dict = sorted(dict.items(), key=lambda d: d[1], reverse=True)
        return dict

    dict = getColorMap(f, colormap)
    return dict


def convertWebP(img_png, delete_old=False):
    img = Image.open(img_png)
    image_new = img_png.replace(".png", '.webp')
    print("image_new=" + image_new)
    while True:
        try:
            if not os.path.exists(image_new):
                img.save(image_new, format="WebP", lossless=True)
            else:
                break
        except Exception as e:
            print(e)
    img.close()
    if delete_old:
        os.remove(img_png)
    return image_new


def resizeImage(f, fixed=None, basewidth=None, baseheight=None):
    img = Image.open(f)
    if fixed:
        img = img.resize((fixed[0], fixed[1]), Image.ANTIALIAS)
    elif basewidth:
        wpercent = (basewidth / float(img.size[0]))
        hsize = int((float(img.size[1]) * float(wpercent)))
        img = img.resize((basewidth, hsize), Image.ANTIALIAS)
    elif baseheight:
        hpercent = (baseheight / float(img.size[1]))
        wsize = int((float(img.size[0]) * float(hpercent)))
        img = img.resize((wsize, baseheight), Image.ANTIALIAS)
    img.save(f)
    img.close()
    return f


def checkISBN(pages):
    isbns, copyright_date = getPDFISBN(pages)
    print("isbn_result = ")
    print(isbns)
    ####
    if not isbns:
        return None, copyright_date
    return isbns, copyright_date


def checkPDFByFirstPageImage(pages, file):
    image_file = getPDFImage(pages, file)
    return checkPDFImage(image_file)


# return: pdf_status=
def checkPDFImage(image_file):
    pdf_status = {}
    pdf_status['is_book'] = False
    pdf_status['delete'] = False

    print(image_file)
    if not image_file:
        fileutil.deleteFile(image_file)
        pdf_status['is_book'] = False
        pdf_status['delete'] = True
        return pdf_status
    image_color = getImageMainColor(image_file)

    image_len = len(image_color)
    colors = ['Yellow', 'Orange', 'Red', 'Pink', 'Gray', 'Purple', 'Tea', 'Green', 'Blue', 'Brown']
    total = 0.0
    for c in image_color:
        c_name = c[0]
        if c_name in colors:
            total += c[1]
    if total > 0.15:
        fileutil.deleteFile(image_file)
        pdf_status['is_book'] = True
        pdf_status['delete'] = False
        return pdf_status

    first_main_color = image_color[0]
    print(image_file)
    print(image_color)
    print(first_main_color[0])
    print(first_main_color[1])
    if first_main_color[0] == 'White':
        if len(image_color) < 2 or first_main_color[1] >= 0.85:
            fileutil.deleteFile(image_file)
            pdf_status['is_book'] = False
            if first_main_color[1] >= 0.95:
                pdf_status['delete'] = True
            else:
                pdf_status['delete'] = False
            return pdf_status

        fileutil.deleteFile(image_file)
        second_main_color = image_color[1]
        print("second color = " + second_main_color[0])
        if second_main_color[0] != 'Black':
            if second_main_color[1] > 0.1:
                pdf_status['is_book'] = True
                pdf_status['delete'] = False
                return pdf_status

            if (first_main_color[1] + second_main_color[1]) > 0.7:
                pdf_status['is_book'] = True
                pdf_status['delete'] = False
                return pdf_status
        else:
            if first_main_color[1] < 0.75 and second_main_color[1] > 0.1:
                pdf_status['is_book'] = True
                pdf_status['delete'] = False
                return pdf_status

        pdf_status['is_book'] = False
        pdf_status['delete'] = False
        return pdf_status
    else:
        if first_main_color[0] == 'Black':
            if first_main_color[1] >= 0.25:
                fileutil.deleteFile(image_file)  # not save image
                pdf_status['is_book'] = True
                pdf_status['delete'] = False
                return pdf_status
            else:
                if len(image_color) > 1:
                    second_main_color = image_color[1]
                    if second_main_color[0] != 'White':
                        pdf_status['is_book'] = True
                        pdf_status['delete'] = False
                        return pdf_status

                pdf_status['is_book'] = False
                pdf_status['delete'] = False
                return pdf_status

        fileutil.deleteFile(image_file)  # not save image
        pdf_status['is_book'] = True
        pdf_status['delete'] = False
        return pdf_status
    # black


def getPDFBasicInfo(file, include_image = True):
    doc = None
    info = {}
    try:
        doc = fitz.open(file)
    except Exception as e:
        print(e)
        if doc or doc is not None:
            doc.close()
        doc = None
        return None
    info['page_num'] = doc.page_count
    if info['page_num'] <2:
        if doc or doc is not None:
            doc.close()
        doc = None
        return None
    if include_image:
        info["page_image"] = getFirstPageImage(doc, file)
    if doc or doc is not None:
        doc.close()
    doc = None
    return info


def getAllPDFPages(file):
    doc = None
    try:
        doc = fitz.open(file)
    except Exception as e:
        print(e)
        if doc or doc is not None:
            doc.close()
            doc = None
        return None, []
    pages = []
    #print(doc.pageCount)
    i = 0
    for i in range(len(doc)):
        try:
           # p = deleteAllAnnotations(doc[i])

            pages.append(doc[i])
        except Exception as e:
            print("page = " + str(i))
            print(e)
    return doc, pages


def getBookmark(doc):
    toc = pdfbookmarkutil.getBookmarkByPdfDoc(doc)
    bookmark = parseBookmar(toc)
    return bookmark


def checkPDFBookByFeature(string):
    feature = ['Table of Contents', 'ISBN10' 'ISBN', ""]


def getPageContentImageAfter(page):
    book_first_content = ''
    book_first_content = getFirstPageContentByText(page, max_words=500)
    if len(book_first_content) < 10:
        max_f = 3
        while max_f > 0:
            print("get content from page using image")
            if len(book_first_content) > 10:
                break
            # 错误返回None, 无内容是一传空格
            book_first_content = getFirstPageContentByImage(current_page=page)
            if not book_first_content or book_first_content == '':  # wrong ,eception
                max_f -= 1
                book_first_content = ''
                time.sleep(1)
                continue
            else:
                book_first_content = book_first_content.strip()
                break
    return book_first_content


def getPageContent(page):
    book_first_content = ''
    max_f = 3
    while max_f > 0:
        print("get content from page using image")
        if len(book_first_content) > 10:
            break
        # 错误返回None, 无内容是一传空格
        book_first_content = getFirstPageContentByImage(current_page=page)
        if not book_first_content or book_first_content == '':  # wrong ,eception
            max_f -= 1
            book_first_content = ''
            time.sleep(1)
            continue
        else:
            book_first_content = book_first_content.strip()
            break
    if book_first_content == '':
        book_first_content = getFirstPageContentByText(page)
        if len(book_first_content) > 10:
            return book_first_content
    return book_first_content


def getFirstContent(pages):
    t = ''
    pm = 0
    for p in pages:
        pm += 1
        print("start to get pm = " + str(pm))
        t = getPageContent(p)
        if len(t) > 10:
            break
    return t


def getPdfEbookInfo(file, min_page=40, strict=False, real_pdf_file_path=None):
    print(file)
    global HAS_COVER_NO_ISBN
    global HAS_ISBN_NO_COVER
    global HAS_ISBN_COVER

    # page,isbn,filename,image
    book_info = {}
    book_info['delete'] = False
    book_info['type'] = 0
    if real_pdf_file_path:
        doc, pages = getAllPDFPages(real_pdf_file_path)
    else:
        doc, pages = getAllPDFPages(file)

    print("total_num = " + str(len(pages)))
    if len(pages) < min_page:
        book_info['delete'] = True
        return book_info

    if not isPDF(pages):
        book_info['delete'] = True
        return book_info
    # 通过颜色来判断

    try:
        first_status = isFirstPDFBook(pages)
        if not first_status['is_cover']:
            print("text in first page is more.")
            book_info['delete'] = False
            if first_status['delete']:
                book_info['delete'] = True
            return book_info
            # 更加严格，如果
        if first_status['delete']:
            book_info['delete'] = True
            return book_info
    except:
        # book_info['delete'] = False
        # return book_info
        return None
    pdf_status = checkPDFByFirstPageImage(pages, file)
    if pdf_status['delete']:
        book_info['delete'] = True
        return book_info
    # get isbn in this pdf
    isbns, copyright_date = checkISBN(pages)
    book_mark = getBookmark(doc)

    book_first_content = getFirstContent(pages)
    book_first_content = stringutil.removeURL(book_first_content)
    book_first_content = stringutil.removeEmpty(book_first_content)

    isbn_count = 0
    if isbns:
        isbn_count = len(isbns)

    # 512

    if strict:
        if pdf_status['delete']:
            if isbn_count < 1:
                book_info['delete'] = True
                return book_info

        if not isbns:
            if pdf_status['is_book']:
                book_info['type'] = HAS_COVER_NO_ISBN
            # return book_info, 封面合法也处理了
        if isbn_count > 15:
            book_info['delete'] = True
            return book_info

        if isbn_count > 0:
            if not pdf_status['is_book']:
                book_info['type'] = HAS_ISBN_NO_COVER
                book_info['delete'] = True  # 只有isbn, 封面不合法，删除 不处理

        if pdf_status['is_book']:
            book_info['type'] = HAS_ISBN_COVER
            if not isbns:
                book_info['type'] = HAS_COVER_NO_ISBN
            # get image
            fileinfo = fileutil.getFilePathInfo(file)
            image_name = fileinfo[1] + ".png"
            absolute_image_name = "F:\\all-google-pdf\\images\\" + image_name
            absolute_image_name = getFirstPDFImage(pages, absolute_image_name)

            if not isbns:
                isbns = []
            book_info['isbn'] = ",".join(isbns)
            book_info['page'] = len(pages)
            book_info['size'] = fileutil.getfilesize(file)
            book_info['filename'] = fileinfo[1] + fileinfo[2]
            book_info['image'] = absolute_image_name
            book_info['copyright_date'] = copyright_date
            book_info['first_page'] = book_first_content
            book_info['bookmark'] = book_mark
            book_info['5_page'] = get5PagesContentByImage(pages)
        else:
            book_info['delete'] = True
        return book_info

    return book_info
    '''if len(pages) < min_page:
        return checkPDFByFirstPageImage(pages, file)

    if not isbns or isbn_count>=10:
        return checkPDFByFirstPageImage(pages, file)
    elif len(isbns)<1:
        return checkPDFByFirstPageImage(pages, file)
    #if not isbns:
        #os.remove(image_file)
        #return False
    return True'''


def get5PagesContentByImage(pages, max_page=5):
    print("----get book 5 page content start----")
    start = 0
    content = ""

    for page in pages:
        text = ''
        try:
            time.sleep(1)
            print("get text from page image...")
            text = getPageContentImageAfter(page)

        except Exception as e:
            return None

        content += " " + text
        start += 1
        if start >= max_page:
            break
    # content处理
    content = stringutil.removeURL(content)
    content = stringutil.removeSymbol(content)
    content = stringutil.removeEmpty(content, newline=True)
    content = content.lower()
    print("----get book 5 page content end----")
    return content


def getPagesContentByImage(pages, max_page=50, raiseexception=False):
    start = 0
    content = ""

    for page in pages:
        text = ''
        try:
            time.sleep(1)
            print("get text from page image...")
            text = getFirstPageContentByImage(page)
        except Exception as e:
            text = ''

        content += " " + text
        start += 1
        if start >= max_page:
            break
    return content


def getPagesContentByText(pages, max_page=50):
    start = 0
    content = ""

    for page in pages:
        text = ''
        try:
            text = page.get_text()
        except Exception as e:
            print(e)
            text = ''

        content += " " + text
        start += 1
        if start >= max_page:
            break
    return content


def getPDFISBNByImage(pages, max_page=20):
    content = getPagesContentByImage(pages, max_page)
    # only get isbn in from start
    isbns = isbnutil.getValidISBN(content)
    copyright_date = isbnutil.getCopyrightDate(content)

    return isbns, copyright_date


def getPDFISBNByText(pages, max_page=50):
    content = getPagesContentByText(pages, max_page)
    #print("content=",content)
    # only get isbn in from start
    isbns = isbnutil.getValidISBN(content)
    copyright_date = isbnutil.getCopyrightDate(content)
    '''total_page = len(pages)
    if not isbns:
        start = 0
        content = ""
        print(type(pages))
        pages = pages[::-1]
        for page in pages:
            text = page.getText("text")
            content += text
            start += 1
            if start >= max_page:
                break
        isbns = isbnutil.getValidISBN(content)'''
    return isbns, copyright_date

def getPDFISBN_Info(file, max_page = 10):
    doc, pages = getAllPDFPages(file)
    isbns,c  = getPDFISBN(pages, max_page)
    if doc or doc is not None:
        doc.close()
        doc = None
    return isbns

def getPDFISBN(pages, max_page=50):
    isbns, copyright_date = getPDFISBNByText(pages, max_page)
    # if not isbns or len(isbns) < 1:
    #if isEncript(getPagesContentByText(pages, max_page)):
        #print("----get book isbn from page image start----")
        #isbns, copyright_date = getPDFISBNByImage(pages, max_page=20)
        #print("----get book isbn from page image end----")
    return isbns, copyright_date


def extractFirstPDFImage(file, image_name):
    # image_name is webp
    doc, pages = getAllPDFPages(file)
    return getFirstPDFImage(pages, image_name)


def getFirstPDFImage(pages, image_name):
    i = 0
    try:
        for page in pages:
            # iterate through the pages
            pix = page.getPixmap(alpha=False)  # render page to an image
            temp_image_file = image_name
            pix.writePNG(temp_image_file)
            # change the size of image
            # temp_image_file = os.path.basename(pdf) + '-page-1.png'
            resizeImage(temp_image_file, basewidth=400)
            # temp_image_file = convertWebP(temp_image_file, True)
            return temp_image_file
    except Exception as e:
        print(e)
        return ""  # open document


def getFirstPageImage(doc, absolute_file):
    page = doc[0]
    pix = page.get_pixmap(alpha=False)
    fileinfo = fileutil.getFilePathInfo(absolute_file)
    image_name = fileinfo[1]
    temp_image_file = "temp\\"+image_name + '-page-1.png'
    pix.save(temp_image_file)
    return temp_image_file


def getPDFImage(pages, absolute_file, max_num=1):
    # get image
    fileinfo = fileutil.getFilePathInfo(absolute_file)
    image_name = fileinfo[1]
    i = 0  # open document
    for page in pages:
        # iterate through the pages
        pix = page.getPixmap(alpha=False)  # render page to an image
        temp_image_file = "temp\\"+image_name + '-page-1.png'
        pix.writePNG(temp_image_file)
        # change the size of image
        # temp_image_file = os.path.basename(pdf) + '-page-1.png'
        #resizeImage(temp_image_file, basewidth=512)

        return temp_image_file


'''files = traverseDir("F:\\D-ai-docs\\", filter_fun = filter)
print("get files = " + str(len(files)))
for file in files:
    #try:
    isBookCover(file)
    #except Exception as e:
        #print(e)
file = 'F:\\D-ai-docs\\36\\sinamics-s120-getting-started-with-the-starter-commissioning-tool-178401.pdf'
if isBookCover(file):
    print(file)'''