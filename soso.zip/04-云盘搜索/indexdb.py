import stringutil
import pymysql
import re
import nltkutil
import dbutil
mysql = dbutil.mysql



def initTable():
    prefix = 'abcdefghijklmnopqrstuvwxyz0123456789'
    for p in prefix:
        t = 'wp_all_tag'+'_'+p
        sql = '''CREATE TABLE IF NOT EXISTS `'''+t+'''` (
  `index_id` int(11) NOT NULL AUTO_INCREMENT,
  `index_slug` varchar(50) NOT NULL,
  `index_name` text NOT NULL,
  `index_links` mediumtext NOT NULL,
  `index_num` int(11) NOT NULL,
  `index_type` varchar(20) NOT NULL,
  PRIMARY KEY (`index_id`),
  UNIQUE KEY `index_slug` (`index_slug`,`index_type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8'''
        flag = mysql.execSql(sql)
#initTable()
def deleteIndexByLinkID(lid):
    sql = "delete from all_index where link_id="+str(lid)
    flag = mysql.execSql(sql)

def isValidWord(w):
    if len(w)<2:
        return False
    prefix = 'abcdefghijklmnopqrstuvwxyz0123456789'
    for p in prefix:
        pattern = r''+p+'{3,}'
        temp = re.sub(pattern, "", w)
        temp = temp.strip()
        if temp == "":
            return False
        
    for i in range(10):
        if w == str(i):
            return False
    arr=['or','and','with','to','by','of','but','in','free']
    if w in arr:
        return False
    arr = ['i','me','my','myself','we','our','ours','ourselves','you','your','yours','yourself','yourselves','he','him','his','himself','she','her','hers','herself','it','its','itself','they','them','their','theirs','themselves','what','which','who','whom','this','that','these','those','am','is','are','was','were','be','been','being','have','has','had','having','do','does','did','doing','a','an','the','and','but','if','or','because','as','until','while','of','at','by','for','with','about','against','between','into','through','during','before','after','above','below','to','from','up','down','in','out','on','off','over','under','again','further','then','once','here','there','when','where','why','how','all','any','both','each','few','more','most','other','some','such','no','nor','not','only','own','same','so','than','too','very','s','t','can','will','just','don','should','now','d','ll','m','o','re','ve','y','ain','aren','couldn','didn','doesn','hadn','hasn','haven','isn','ma','mightn','mustn','needn','shan','shouldn','wasn','weren','won','wouldn']
    if w in arr:
        return False
    return True

def addIndex(text,link_id,index_type, weight=1):
    words = getIndexWords(text)
    print(words)
    for w in words:
        if isValidWord(w):
            #print("add word "+w)
            addIndexItem(w, link_id, index_type,  weight)
        else:
            pass
            #print("invalid="+w)
def getIndexItem(table, word, index_type):
    #print(word)
    word = word[0:15] #最长单词为15个长度 
    word = pymysql.escape_string(word)
    
    sql = "select index_id, index_links from "+table+" where index_slug='"+word+"' and index_type='"+index_type+"'"
    #print(sql)
    row = mysql.execQuery(sql)
    if len(row) < 1:
        return None
    
    if not row:
        return None
    return row[0]
def getIndexTable(word):
    word = word.lower()
    if len(word)<1: 
        return None
    for w in word:
        if stringutil.startWithAZ(w):
            return "wp_all_tag_"+w.lower()
    return None
def addIndexItem(word, link_id, index_type, weight=1):
    index_table = getIndexTable(word)
    if index_table is None:
        return
    #print("table="+index_table)
    
    item = getIndexItem(index_table, word, index_type)
    if not item: #不存在，则增加
        #add
        word_slug = word[0:15]
        word = pymysql.escape_string(word)
        word_slug = pymysql.escape_string(word_slug)
        #print("insert")
        sql = "insert into "+index_table+" (index_slug, index_name,index_type, index_links) values('"+word_slug+"','"+word+"','"+index_type+"','"+str(link_id)+"')"
        flag = mysql.execSql(sql)
        return flag
    else: #存在
        t = ","+str(link_id)
        link_idx = str(t)*weight
        link_idx = link_idx[1:]
        
        
        link_text = item[1]
        index_id = item[0]
        link_text = link_text+","+link_idx
        #print("update")
        sql='update '+index_table+" set index_links='"+link_text+"' where index_id="+str(index_id)
        #print(sql)
        flag = mysql.execSql(sql)
        #print("end")
        return flag

def fixText(text):
    text = text.lower()
    pattern = re.compile('\[.*?\]')
    text = re.sub(pattern, ' ', text)
    text = text.strip()
    
    
    text = text.replace("c++",' cplus ')
    text = text.replace("c#",' csharp ')

    text = stringutil.removeSymbols(text,num=1)
    words = text.split(" ")
    
    v=[]
    for w in words:
        if stringutil.containsNonAscii(w):
            continue
        if stringutil.isAllNumber(w):
            if len(w) != 4:
                continue
            else:
                if w not in v:
                    v.append(w)
        if not stringutil.containsEnglishChar(w):
            continue
        #将超过
        
        if w not in v:
            v.append(w)
            
        #如果是标题符号
            
    return " ".join(v)
    
def getIndexWords(text):
    #获取词性还原的词
    #print("sssss")
    #text = stringutil.removeURL(text)
    #print("sss")
    
    
    print("nltk start")
    words = nltkutil.lemmatize_sentence(text)
    print("nltk end")
    words = " ".join(words)
    text = text + " , "+ words.lower()
    text = fixText(text)
    
    text = stringutil.getStringSlug(text)
    text = text.lower()
    #print(text)
    words = text.split(" ")
    words = set(words)
    words = list(words)
    return words

def isvalidTag(tag):
    if tag.strip() == "":
        return False
    tags = tag.split()
    flag = True
    invalid_tags = ['pdf','book','ebook']
    # each word contains A-Z0-9
    for t in tags:
        #
        t = t.strip()
        lower_t = t.lower()
        if lower_t in invalid_tags:
            return False
        
        pattern = r'[^A-Z0-9]{1,}'
        temp = re.sub(pattern, "", t)
        temp = temp.strip()
        if len(temp) == 0:
            return False
    return True