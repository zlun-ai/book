import urllib.parse
from bs4 import BeautifulSoup
import fileutil
import io
import sys
import re
import json
from unidecode import unidecode
import htmlutil

def isValid(url):
    arr=['stackoverflow.com',
         '/comments/',
         '.youtube.com',
         'medium.com',
         'reddit.com',
         'blogspot.com',
         'stackcodex.com',
         '/forum/',
         '/image/',
         '/images/',
         '/video/',
         '/videos/',
         '/search/',
         '/tag/',
         '/product/',
         '/products/',
         '/doi/',
         '/question/',
         '/shop/',
         '/search?keywords=',
         'quora.com']
    for a in arr:
        if a in url:
            return False
    return True
def isValidLink(link):
    if link.count('.google.com') > 0:
        return False
    if link.count('//google.com') > 0:
        return False
    if  not link.startswith("https://") and not link.startswith("http://"):
        print("invalid link")
        return False
    
    return True #isValid(link)
    
def removeHTMLTagName(soup, taglist=['script', 'style']):
    for i in taglist:
        [x.unwrap() for x in soup.find_all(i)]
    
    return str(soup)

def removeStyle(soup):
    [x.extract() for x in soup.find_all('style')]
    return soup

def removeScript(soup):
    [x.extract() for x in soup.find_all('script')]
    return soup

def removeHTMLTag(soup, taglist=['script', 'style']):
    for i in taglist:
        [x.extract() for x in soup.find_all(i)]
    
    return str(soup)

def getTableOfContents(html_doc):
    soup = BeautifulSoup(html_doc, 'html.parser')
    table_body = soup.find_all("div", "card")
    #print(table_body)
    return table_body
    
def getSearchResult(soup):   
    
    def has_a_characters(css_class):
        return css_class is not None and css_class == 'g' and len(css_class) == 1
    
    

    results = soup.find_all("div", class_=has_a_characters)
    if len(results) < 1:
        results = soup.find_all("div", class_= 'ZINbbc xpd O9g5cc uUPGi')
        
    for r in results:
        print(r)
    
        
    return results
    
def get_search_results(search_key, content):
    soup = BeautifulSoup(content, "html.parser")
    candidates = soup.find_all("a")
    cx = []
    for c in candidates:
        cs = str(c)
        if "<h3" in cs.lower():
            #print(c)
            cx.append(c)
    rx = []
    for t in cx:
        #
        url = t.get('href')
        if "&url=" in url:
            ux = url.split("&url=")
            url = ux[1]
            if "&" in url:
                ux = url.split("&")
                url = ux[0]
            
        if not isValidLink(url):
            print(url)
            continue
        x = {}
        x["url"] = url
        # 只获取h3
        soup_a = BeautifulSoup(str(t), "html.parser")
        candidates_h3 = soup_a.find_all("h3")
        if len(candidates_h3) != 1:
            print("h3 is error")
            exit(0)
            
        x['title'] = candidates_h3[0].text 
        
        #获取描述
        parent_box = t.parent # 
        #获取兄弟节点
        desc = ""
        desc_box = parent_box
        for i in range(7):
            try:
                desc_box = desc_box.next_sibling
                desc_text = desc_box.text
                if len(desc_text) > len(desc):
                    desc = desc_text
            except:
                continue
        #修复标题
        #title, status = #docutil.getLinkTitle(search_key, x['title'], desc, x["url"], doc_type='pdf')
        x['title'] = x['title']
        x['status'] = 0
        print("title=",x['title'])
        print("url=",x["url"])
        print("desc=",desc)
        x['desc'] = desc
        rx.append(x)
    print(rx)
    for x in rx:
        print(x)
    return rx

#content = fileutil.readFile('google-r-2.html')
#get_search_results("python deep learning",content)

#print(isValidLink("http://repository.radenfatah.ac.id/6212/1/Basic%2520Reading.pdf"))