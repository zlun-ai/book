import urllib.parse
from bs4 import BeautifulSoup
import fileutil
import io
import sys
import html
import re
import json
from unidecode import unidecode
import htmlutil
def process(html_content):
    if 'class="book-cover' not in html_content:
        print("no book-cover class")
        return None, None, None,None, None
    
    soup = BeautifulSoup(html_content, 'html.parser')
    #get book title
    h1 = soup.find_all("h1")
    if len(h1)< 1:
        return None
    title = h1[0].text
    title = html.unescape(title.strip())
    print(title)
    if title == 'Sell College Textbooks Online':
        return None, None, None, None, None
    
    #get book description
    desc = ""
    try:
        desc_box = soup.find(id='bookDescriptionBlock')
        
        #删除desc_box的子节点div
        px = desc_box.find_all("p")
        
        for p in px:
            desc += "<p>"+p.text+"</p>"
    except Exception as e:
        desc = ""
    
    #图片
    img_box = soup.find(attrs={'class':'book-cover'})
    #print(img_box)
    imgs = img_box.find_all("img")
    img_src = imgs[0].get('src')
    
    # 获取类别
    cat = ''
    x = soup.find_all("a")
    for xe in x:
        u = xe.get("href")
        if u is None:
            continue
        if "https://booksrun.com/college-textbooks/" in u and not u.endswith("/"):
            cat = xe.text.strip()
            cat = html.unescape(cat)
            break
    author = getcats(soup)
    print(title, img_src, desc, cat, author)
    return title, img_src, desc, cat, author

def getcats(soup):
    divs = soup.find_all("div", attrs={"class" : "d-none d-md-block"})
    if len(divs) < 1:
        return ""
    author = []
    for d in divs:
        x = d.find_all("a")
        for xe in x:
            u = xe.get("href")
            if "/author/" in u:
                astr = xe.text.strip()
                if astr not in author:
                    author.append(astr)
    return ", ".join(author)
    
content = fileutil.readFile('google-r.html')
process(content)