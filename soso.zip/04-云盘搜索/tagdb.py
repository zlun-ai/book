import stringutil
import pymysql
import dbutil
mysql = dbutil.mysql

def getBookTemp():
    sql="SELECT book_name ,book_author, book_content FROM  `enbook`.`book_all` where book_id>=10000 and book_id<30000 and book_name not like '%...%'"
    print(sql)
    posts = mysql.execQuery(sql)
    return posts

def canStartUpload():
    sql="select book_title, count(*) as t from all_books group by book_title having t >1"
    print(sql)
    posts = mysql.execQuery(sql)
    if not posts:
        return True
    for px in posts:
        if px:
            return False
    return True
def updateUploadBookInfo(bid, info=None):
    if not info:
        return
    sql = "update all_books  set "+info+" where book_id = "+str(bid)
    flag = mysql.execSql(sql)
def updateUploadBookInfoByUnique(uid, info=None):
    if not info:
        return
    sql = "update all_books  set "+info+" where book_unique = '"+ uid+"'"
    flag = mysql.execSql(sql)

def getAllNeedUploadBooks(condition ='', num = 100):
    need_posts = []
    sql="select book_id, book_unique,book_date,book_title,book_desc,book_tag,book_isbn,book_size,book_file,book_image,book_page,book_url,book_bookmark,book_parent_id from all_books where "+condition+" order by book_id asc "
    print(sql)
    posts = mysql.execQuery(sql)
    if not posts:
        return None
    for px in posts:
        p={}
        p['post_id'] = px[0]
        p['post_title'] = px[3]
        p['post_desc'] = px[4]
        
        p['post_size'] = px[7]
        p['post_page'] = px[10]
        p['post_isbn'] = px[6]
        p['post_date'] = px[2]
        
        #tag
        p['post_tag']= px[5]
        p['post_cat']= "Books"
        
        p['post_meta_unique'] = px[1]
        p['post_meta_file_name'] =  px[8]
        p['post_meta_file_download'] = px[11] 
        
        #
        p['post_bookmark'] = px[12]
        p['post_parent_id'] = px[13]
          
        need_posts.append(p)
        
    return need_posts 
def isExistBookByISBNAndPageAndDate(isbn, page, date):
    if date =="" or isbn == "" or page <1:
        return None
    isbn = isbn.strip() #remove blank
    isbn = pymysql.escape_string(isbn)
    
    date = date.strip() #remove blank
    date = pymysql.escape_string(date)
    
    
    sql = "select book_id from all_books where book_isbn = '"+ isbn +"' and book_date='"+date+"' and book_page = " + str(page)
        
    row = mysql.execQuery(sql)
    if len(row) < 1:
        return None
    #print(row[0][0])
    if not row or not row[0][0]:
        return None
    return row[0]

def getExistBookByPageAnd5Content(page, content_5):
    page_scope = 50
    start_page = int(page) -page_scope
    end_page = int(page) + page_scope
    
    sql = ''
    sql = "select book_id, book_5_content from all_books where book_page >= "+str(start_page)+" and book_page <= "+str(end_page)+""
   
    row = mysql.execQuery(sql)
    if len(row) < 1:
        return None
    #similar book
    ids = []
    for b in row:
        bid = b[0]
        
        sim = stringutil.string_similar_strict(content_5, b[1])
        print(str(bid) + " similar = " + str(sim))
        if sim[0] > 0.80 and sim[1] > 0.80:
            return bid
    
    return None

def getNeedSearchBook():
    
    sql = "select book_id,book_name from book where book_status = 0 order by book_id asc limit 0,1"
    row = mysql.execQuery(sql)
    if len(row) < 1:
        return None
    
    if not row:
        return None
    return row[0]

def getBookbyCondition(where):
    
    sql = "select book_id from all_books where "+where
    row = mysql.execQuery(sql)
    if len(row) < 1:
        return None
    #print(row[0][0])
    if not row or not row[0][0]:
        return None
    return row[0]

def getTagByNameAndType(tag_name,type):
    tag_name = tag_name.strip() #remove blank
    md5 = stringutil.getMD5(tag_name)
    md5 = pymysql.escape_string(md5) 
    
    
    sql = "select tag_id, tag_num from all_tag where tag_slug = '"+ md5 +"' and tag_type='"+type+"'"
    print(sql)
    row = mysql.execQuery(sql)
    if len(row) < 1:
        return None
    #print(row[0][0])
    if not row or not row[0][0]:
        return None
    return row[0]
    
def addTagToWordPress(tag_name):
    tag_name = tag_name.strip() #remove blank
        
    md5 = stringutil.getMD5(tag_name.lower())
    md5 = pymysql.escape_string(md5) 
        
    tag_name = pymysql.escape_string(tag_name)
        
        #print(link_search_title, link_url, link_desc, link_title, link_title_status)
    sql = "insert into `pdf-search-wordpress`.`wp_terms` (name, slug, term_group) values('"+tag_name+"','"+md5+"',0)"
    print(sql,flush = True)
    flag = mysql.execSql(sql)
    
    sql = "select  term_id from `pdf-search-wordpress`.`wp_terms` where slug = '"+ md5 +"'"
    #print(sql)
    row = mysql.execQuery(sql)
    if len(row) < 1:
        return None
    #print(row[0][0])
    if not row or not row[0][0]:
        return None
    tid = row[0][0]
    
    sql = "insert into `pdf-search-wordpress`.`wp_term_taxonomy` (term_id,taxonomy,parent,count) values("+str(tid)+",'post_tag',0,0)"
    print(sql,flush = True)
    flag = mysql.execSql(sql)
    

    #插入    
    sql = "select "
def addTag(tag_name,type):
    
    if True:
        tag_name = tag_name.strip() #remove blank
        
        md5 = stringutil.getMD5(tag_name.lower())
        md5 = pymysql.escape_string(md5) 
        
        t = getTagByNameAndType(tag_name.lower(),type)
        
        if not t:
            pass
        else:
            tid = t[0]
            tnum = t[1]
            tnum += 1
            sql = 'update all_tag set tag_num='+str(tnum)+' where tag_id='+str(tid)
            print(sql)
            flag = mysql.execSql(sql)
            return flag
        tag_name = pymysql.escape_string(tag_name)
        
        #print(link_search_title, link_url, link_desc, link_title, link_title_status)
        sql = "insert into all_tag (tag_slug, tag_name,tag_type,tag_num) values('"+md5+"','"+tag_name+"','"+type+"',1)"
        #print(sql,flush = True)
        flag = mysql.execSql(sql)
        #addTagToWordPress(tag_name)
        return flag
    else:
        sql = ""
    
    return True
def addLinks(links):
    for url in links:
        addLink(url)

def updateNeedSearchBook(id, info):
    if not info:
        return
    sql = "update book set "+info+" where book_id = "+str(id)
    flag = mysql.execSql(sql)   
def updateLinkInfo(id, info=None):
    if not info:
        return
    sql = "update all_link set "+info+" where link_id = "+str(id)
    flag = mysql.execSql(sql)  
def updateLink(id, isprocess = 1):
    sql = "update all_link set is_process = "+ str(isprocess)+" where link_id = "+str(id)
    flag = mysql.execSql(sql)   
    
'''def updateLinkInfo(slug, link_desc):
    link_desc = pymysql.escape_string(link_desc)
    sql = "update all_link set link_desc='"+link_desc+"' where link_slug='"+slug+"'"
    #print(sql,flush = True)
    flag = mysql.execSql(sql)   ''' 
    
def getAllLinks(keys='link_id, link_slug'):
    print('query all links in db')
    sql = "select " + keys +" from all_link where link_desc='' and is_process != 0 order by link_id asc"
    print(sql)
    row = mysql.execQuery(sql)  
    return row
    
def getLink():
    print("get crawl url")
    sql = "select link_id, link_url, link_title from all_link where is_process = 0 and link_title_status = 100 and link_url not like '%link.spring%' order by visit_date_time asc limit 0,1"
    row = mysql.execQuery(sql)
    if len(row) < 1:
        return None
    return row[0][0], row[0][1], row[0][2]