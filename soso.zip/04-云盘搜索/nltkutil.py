import nltk
#nltk.download('wordnet')
#nltk.download('punkt')
from nltk.stem import WordNetLemmatizer
from nltk import word_tokenize, pos_tag
from nltk.corpus import wordnet

def get_wordnet_pos(treebank_tag):
    if treebank_tag.startswith('J'):
        return wordnet.ADJ
    elif treebank_tag.startswith('V'):
        return wordnet.VERB
    elif treebank_tag.startswith('N'):
        return wordnet.NOUN
    elif treebank_tag.startswith('R'):
        return wordnet.ADV
    else:
        return None

def sentence_pos(sentence):
    return pos_tag(word_tokenize(sentence))
#nnp 专有名词，单数形式 NNPS 复数形式
#常用名词 单数形式NN
#can:MD 情态助动词
s  ='ASP.NET Webs Developerses guide,i likes it understanding'
#s = 'jQury can speed up your site developoment'
print(sentence_pos(s))
    
def lemmatize_sentence(sentence):
    res = []
    lemmatizer = WordNetLemmatizer()
    # get word and its pos
    for word, pos in pos_tag(word_tokenize(sentence)):
        wordnet_pos = get_wordnet_pos(pos) or wordnet.NOUN
        res.append(lemmatizer.lemmatize(word, pos=wordnet_pos))

    return res

#print(lemmatize_sentence(s))