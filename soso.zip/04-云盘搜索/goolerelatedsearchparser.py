import urllib.parse
from bs4 import BeautifulSoup
import fileutil
import io
import sys
import re
import json
from unidecode import unidecode
import htmlutil
import docutil
import stringutil
import html
import nltkutil

def fixBookKeyword(text):
    text = text.lower()
    ends = ['online free','free pdf','books free pdf','book download','pdf free download','books pdf free download','pdf download free','free download','pdf']

    for e in ends:
        e = " "+e
        if text.endswith(e):
            l = len(e)
            end = len(text) - l
            text = text[0:end]
    return text
def isValidKeyword(text):
    text = text.lower()
    
    if stringutil.isAllNumber(text):
        return False
    if not stringutil.endsWithAZ(text, False):
        return False
    
    if not stringutil.startWithAZ(text, False):
        return False
    title_arr = text.split(" ")
    if len(title_arr) < 2:
        return False
    
    if len(title_arr[-1]) < 2:
        return False
    
    invalid_arr=[',',"isbn",'read','download','docs','document','documents','ebook','e-book','ebooks','e-books','book','books',"online","free","paper","papers"]
    for invalid in invalid_arr:
        if invalid in title_arr:
            return False
    invalid_arr=['tutorial',"free",'download','full','text','file','fulltext','view',"kb","mb","[","]","epub","book","mobi","chm",'read','find','online',"document","click","now","right","pdf","word","txt", "xls","ppt","doc","pptx","docx","xlsx","epub","mobi"]
   
    for invalid in invalid_arr:
        if invalid in title_arr:
            return False
    if not stringutil.endsWithAZ(text):
        return False 
    if stringutil.containsNonAscii(text):
        return False
    ends_arr = ['.',"'s"]
    for e in ends_arr:
        if text.endswith(e):
            return False
    ends_arr = ['about',
    'above',
    'across',
    'after',
    'against',
    'among',
    'around',
    'at',
    'before',
    'behind',
    'below',
    'beside',
    'between',
    'by',
    'down',
    'during',
    'for',
    'from',
    'in',
    'inside',
    'into',
    'near',
    'of',
    'off',
    'on',
    'out',
    'over',
    'through',
    'to',
    'toward',
    'under',
    'up',
    'with',
    'aboard',
    'along',
    'amid',
    'as',
    'beneath',
    'beyond',
    'but',
    'concerning',
    'considering',
    'despite',
    'except',
    'following',
    'like',
    'minus',
    'next',
    'onto',
    'opposite',
    'outside',
    'past',
    'per',
    'plus',
    'regarding',
    'round',
    'save',
    'since',
    'than',
    'till',
    'underneath',
    'unlike',
    'until',
    'upon',
    'versus',
    'via',
    'within',
    'without']
    for e in ends_arr:
        if text.endswith(" "+e):
            return False
    return docutil.isValidTitle(text, word_min_num=2)
    
def removeHTMLTagName(soup, taglist=['script', 'style']):
    for i in taglist:
        [x.unwrap() for x in soup.find_all(i)]
    
    return str(soup)

def removeStyle(soup):
    [x.extract() for x in soup.find_all('style')]
    return soup

def removeScript(soup):
    [x.extract() for x in soup.find_all('script')]
    return soup

def removeHTMLTag(soup, taglist=['script', 'style']):
    for i in taglist:
        [x.extract() for x in soup.find_all(i)]
    
    return str(soup)

def getTableOfContents(html_doc):
    soup = BeautifulSoup(html_doc, 'html.parser')
    table_body = soup.find_all("div", "card")
    #print(table_body)
    return table_body

def getEMResult(html_content):
    x = getAllEntity()
    for t, c in x.items():
        html_content = html_content.replace(t,c)
        
    html_content = html_content.replace("</em>.<em>",".")
    html_content = html_content.replace("</em>-<em>","-")
    
    soup = BeautifulSoup(html_content, 'html.parser')
    results = soup.find_all('em')
    x = []
    for r in results:
        t = r.get_text()
        t = html.unescape(t)
        if not isValidKeyword(t):
            continue
        
        t = t.lower()
        t = t.title()
        print(t)
        if t not in x:
            x.append(t)
    return x
    
def getSearchResult(soup):   
    
    #def has_a_characters(css_class):
        #return css_class is not None and css_class == 'card-section'
    def has_class_but_no_id(tag):
        return not tag.has_attr('class') and not tag.has_attr('id')

    results = soup.select("p > a")
    res = []
    
    for r in results:
        text = r.get_text()
        text = html.unescape(text)
        text = fixBookKeyword(text)
        if stringutil.containsNonAscii(text):
            continue
        if not isValidKeyword(text):
            continue
        text = stringutil.removeEmpty(text)
        text = text.lower()
        if text not in res:
            res.append(text)
    return res
def process(html_content):
    
    soup = BeautifulSoup(html_content, 'html.parser')
    res = getSearchResult(soup)
    print(res)
    return res

def getAllEntity():
    x = {}
    for i in range(32, 247):
        t = "&#3"+str(i)+";"
        b = html.unescape(t)
        x[t] = b
    return x
    
#ctx = fileutil.readFile("s-3.txt")
#print(html.unescape("&#39;"))
#print(html.escape("'"))
#getEMResult(ctx)
    
    
