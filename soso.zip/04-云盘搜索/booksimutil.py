import hashlib
import base64
import re
import time
import random
import html
import difflib
from difflib import SequenceMatcher
import stringutil

def is_book_title(title):
    title = remove_invalid(title)
    link_fix_name_slug = stringutil.removeSymbols(title, num=1)
    link_x = [m for m in link_fix_name_slug.split() if len(m) > 3]
    print("link_x=", link_x)
    if len(link_x) > 2:
        temp_x = " ".join(link_x)
        temp_x = temp_x.strip()
        if len(temp_x) < 15:
            return False
        return True
    return False

def remove_invalid(sen):
    #移除{}，[],()
    sen = sen.strip()
    pattern = re.compile(r'\(.*?\)')
    sen = re.sub(pattern, '', sen)

    pattern = re.compile(r'\[.*?\]')
    sen = re.sub(pattern, '', sen)

    pattern = re.compile(r'{.*?}')
    sen = re.sub(pattern, '', sen)

    sen = sen.replace("+","")
    sen = sen.replace("%", "")
    sen = sen.replace("edition", "")
    sen = sen.replace("third", "")
    sen = sen.replace("first", "")
    sen = sen.replace("second", "")
    sen = sen.replace("fourth", "")
    sen = sen.replace("fifth", "")
    sen = sen.replace("sixth", "")
    sen = sen.replace("seventh", "")


    sen = stringutil.removeSymbol(sen)
    sen = stringutil.removeEmpty(sen)

    sx = sen.split(" ")

    invalid = ["pdf", "epub", "text","book","ebook","download","Novel"]
    invalid+= ["a", "the","an","®"]
    x = [s for s in sx if s not in invalid and len(s)>1]
    sen = " ".join(x)
    sen = sen.strip()
    return sen






def get_clean_sen(sen):
    sen = sen.lower()
    sen = remove_invalid(sen)
    return sen

#sen2:book title
def get_sim(sen1, sen2, min_word = 2):
    s1 = get_clean_sen(sen1)
    s2 = get_clean_sen(sen2)
    sx1 = s1.split(" ")
    if len(sx1) < min_word:
        return -1, len(s1)
    sx2 = s2.split(" ")
    if len(sx2) < min_word:
        return -1, len(s2)

    if s1 in s2 or s2 in s1:
        return 100, len(s1)
    l1 = len(s1)
    l2 = len(s2)

    if l1 > l2:
        s1 = s1[0:l2]
    else:
        s2 = s2[0:l1]
    #sim
    print("s1 = ", s1)
    print("s2 = ", s2)
    sim = stringutil.string_similar_strict(s1, s2)
    return (sim[0] + sim[1])/2, len(s1)