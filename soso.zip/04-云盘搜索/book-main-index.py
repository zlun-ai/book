# -*- coding:utf-8 -*-
import netutil
import fileutil
import indexdb
import googletextparser
import googlebookutil
import linkdb
import urllib
import netdetect
import time
import stringutil
import random
import sys
import htmlutil
import html
import dbutil
mysql = dbutil.mysql

sql = "select ID,post_title  from wp_posts where ID>40000 order by ID asc"

row = mysql.execQuery(sql)
for link in row:
    link_id = link[0]
    print(link_id)
    link_title = link[1]
    #link_content = link[2]
    #if link_content is None:
        #link_content = ''
    
    indexdb.addIndex(link_title,link_id,index_type = 'book',weight=1)
   
    #link_content = htmlutil.filter_tags(link_content)
    #link_content = html.unescape(link_content)
    #print(link_content)
    #indexdb.addIndex(link_content,link_id,index_type = 'book',weight=1)
    sql = "update wp_posts set comment_count = -1 where ID="+str(link_id)
    #mysql.execQuery(sql)
    #print("add end")

