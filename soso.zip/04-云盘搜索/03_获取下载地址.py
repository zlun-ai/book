# -*- coding:utf-8 -*-
import fileutil
import pdfutil
import isbnutil
import random
import os
import time
import dbutil
import sys
import stringutil
import re
import htmlutil
import html
import tabledb
import downloadutil
import fileutil
import datetimeutil
import concurrent.futures, threading

def hasDownload(filename):
    dirs = [r'D:\ProgramData\BookDataset\02-城通']
    
    for d in dirs:
        f = d+"\\"+filename
        if fileutil.fileexist(f):
            return True
    return False
MAX_FREE_SPACE = 1024 * 1024 * 1024

def init():
    global MAX_FREE_SPACE
    free_space = fileutil.getDiskFreeSpaceByte('D:\\')
    if free_space < MAX_FREE_SPACE:
        return None
    #
    #遍历所有的链接
    table = "yunpan_link"
    keys = 'link_id, file_name, file_download_url'
    data= {'file_is_download':0}
    links = tabledb.query(table, keys, data,  num = None)

    lx = len(links)
    all_data = [{"link_id": x[0], "file_name":x[1], "file_download_url":x[2]} for x in links]
    print(f"all_data={len(all_data)}")
    print("start")
    for d in all_data:
        u = d["file_download_url"]
        if u is None:
            continue
        if u == "":
            continue
        print(u)
init()