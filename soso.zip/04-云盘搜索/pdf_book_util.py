import sys, fitz
import stringutil
import re
import fileutil
import math
import os
import time
import htmlutil
import isbnutil
import isbnlib

def can_move(pdf_file, all_save_info):
    page_count, filesize = get_page_filesize(pdf_file)
    for filename in all_save_info:
        pdf_basic_info = all_save_info[filename]
        pdf_page = pdf_basic_info["pdf_page"]
        pdf_size = pdf_basic_info["pdf_size"]
        pdf_fx = pdf_basic_info["pdf_file_name"]
        min_size = pdf_size - 50*1024
        max_size = pdf_size + 50*1024
        min_page = pdf_page-10
        max_page = pdf_page+10

        if page_count>=min_page and page_count<=max_page:
            if filesize>=min_size and filesize<= max_size:
                return -1, -1

    return page_count, filesize



def get_page_filesize(pdf_file):
    filesize = os.path.getsize(pdf_file)
    page_count, texts = get_pdf_info(pdf_file)
    return page_count, filesize
def check_is_book(pdf_file, all_book_info):
    print(pdf_file)
    try:
        page_count, texts = get_pdf_info(pdf_file) # texts为原始的文本
    except Exception as e:
        print(e)
        return False, "", 0
    pdf_isbn_list = check_book_by_isbn(texts)
    if len(pdf_isbn_list) == 0:
        return False, "", page_count
    for pdf_isbn in pdf_isbn_list:
        if pdf_isbn not in all_book_info:
            return False, "",page_count
        #[data[d]["页数"], data[d]["作者"], data[d]["标题"]
        d = all_book_info[pdf_isbn]
        page =d["页数"]
        author = d["作者"]
        title = d["标题"]

        print(f"pdf page={page_count}, page = {page}, author={author}, title={title}, fx={pdf_file}")

        flag = is_book(page_count, page, texts, author, title)
        if flag:
            return True, pdf_isbn, page_count
    return False, "", page_count


def is_book(pdf_page, page, texts, author, title):

    if not is_book_by_page(pdf_page, page):
        return False
    author_flag = is_book_by_author(texts, author)
    if author_flag:
        return True
    title_flag = is_book_by_title(texts, title)
    if title_flag:
        return True
    return False

def is_book_by_author(texts, author):
    print(f"author src = {author}")
    author_text = stringutil.getStringSlug(author)
    print(f"author mod = {author_text}")
    author_text = list(set(author_text.split(" ")))
    authors = [x.strip() for x in author_text if len(x.strip()) > 1]
    if len(authors) == 0:
        return False
    authors.append("中国版本图书馆")
    return is_book_by_must_texts(texts, authors)

def is_book_by_title(texts, title):
    print(f"title src = {title}")
    title_text = stringutil.getStringSlug(title)
    print(f"author mod = {title_text}")
    title_text = list(set(title_text.split(" ")))
    titles = [x.strip() for x in title_text if len(x.strip()) > 1]
    if len(titles) == 0:
        return False
    titles.append("中国版本图书馆")
    return is_book_by_must_texts(texts, titles)

def check_book_by_isbn(texts):
    isbn_list = []
    for text in texts:
        isbn_list = isbnutil.getValidISBN(text)
        if len(isbn_list)>0:
            print(isbn_list)
        if len(isbn_list) > 2:
            isbn_list = isbnutil.get_valid_isbn_strict(text)
        if len(isbn_list)> 0 and len(isbn_list) <= 2:
            return isbn_list

    return []


def is_book_by_isbn(texts, isbn):
    for text in texts:
        isbn_list = isbnutil.getValidISBN(text)
        if len(isbn_list)> 0 and len(isbn_list) != 1:
            return False
    if len(isbn_list) != 1:
        return False
    pdf_isbn = isbn_list[0]
    #
    if isbnlib.is_isbn10(isbn):
        isbn13 = isbnlib.to_isbn13(isbn)
    elif isbnlib.is_isbn13(isbn):
        isbn13 = isbn
    if isbn == pdf_isbn or isbn13 == pdf_isbn:
        return True
    return False
def is_book_by_must_texts(texts, must_contain):
    m=[]

    for text in must_contain:
        text = stringutil.getStringSlug(text)
        pattern = re.compile(r'[\r\n\t\f ]{1,}')
        text = re.sub(pattern, '', text)
        m.append(text.lower())


    for text in texts:
        text = stringutil.getStringSlug(text)
        pattern = re.compile(r'[\r\n\t\f ]{1,}')
        text = re.sub(pattern, '', text)
        text = text.lower()
        num = 0
        for t in m:
            if t in text:
                num += 1
        sim = num/len(m)
        if sim >=0.5:
            return True
    return False





def is_book_by_page(pdf_page, book_page):
    try:
        book_page = int(book_page)
    except:
        print(f"{book_page} is invalid")
        return False
    sep = int(book_page*0.2)
    if sep < 50:
        sep = 50
    max_page = book_page+sep
    min_page = book_page-sep
    if pdf_page>=min_page:
        return True
    return False


def get_pdf_info(pdf_file, page_num = 10):
    doc = None
    info = {}
    try:
        doc = fitz.open(pdf_file)
    except Exception as e:
        print(pdf_file, e)
        if not doc.is_closed:
            doc.close()
        doc = None
        return ""
    # 获取页数
    page_count = doc.page_count

    # 获取文本
    texts = []
    for page in doc:
        texts.append(page.get_text())
        page_num -= 1
        if page_num < 1:
            break

    if not doc.is_closed:
        doc.close()
    doc = None
    return page_count, texts

#_____________________
def pureLine(line_text):
    #remove all html tags
    text = htmlutil.filter_tags(line_text)
    
    return text.strip()
def getAllLeftPt(ptext):
    pattern = r'left:([0-9\.]{1,20})pt'
    ptexts = ptext.split(">")
    ptext = ptexts[0]
    #re.match(pattern, html, re.I)
    matcher = re.findall(pattern, ptext, re.I)  
   
    sizes = []
    if not matcher:
        return None  
    #print(matcher)
    sizes = [float(i) for i in matcher]
    return list(set(sizes))
    
def isBookMarkPage(page_html, per = 0.6):
    
    arr = ['......', '------']
    lines = page_html.split("\n")
    m = []
    i = 0
    total_line = 0
    for l in lines:
        l = pureLine(l)
        if l == "":
            continue
        total_line += 1
        for a in arr:
            if a in l:
                i += 1
    if total_line < 1:
        return False
    #print(i / total_line)
    if (i / total_line) > 0.6:
        return True
    return False
def getMarkLeft(doc):
    left = []
    max = 50
    for page in doc:
        max -= 1
        print(max)
        if max < 0:
            break
        page_html = page.getText('html')
        if not isBookMarkPage(page_html):
            continue
        cat_tag = '####new####'
        pattern = re.compile(r'[\.\-]{6,}')
        page_html = re.sub(pattern, cat_tag, page_html)
        soup = BeautifulSoup(page_html, 'html.parser')
        p = soup.find_all("p")

        for px in p:
            pstr = str(px)
            if cat_tag not in pstr:
                continue
            #print(pstr)
            left_list = getAllLeftPt(pstr)
            if left_list:
                left.extend(left_list)
    left_list = list(set(left))
    #sort
    return sorted(left_list)
def getMarksByPage(page, markleft):
    if len(markleft) < 1:
        return []
    page_html = page.getText('html')
    if not isBookMarkPage(page_html):
        return []
    #print(page_html)
    cat_tag = '####new####'
    pattern = re.compile(r'[\.\-]{6,}')
    page_html = re.sub(pattern, cat_tag, page_html)
    soup = BeautifulSoup(page_html, 'html.parser')
    p = soup.find_all("p")
    cats = []
    for px in p:
        phtml = str(px)
        
        mtext = px.getText()
        if cat_tag not in mtext:
            continue
        left = getAllLeftPt(phtml)
        
        xs = mtext.split(cat_tag)
        mtext = xs[0]
        mtext = stringutil.removeEmpty(mtext, True)
        mtext = mtext.strip()
        if mtext == "":
            continue
        cat_type = 0
        if left:
            left_dist = float(left[0])
            left_dist = float(left_dist)
            if left_dist not in markleft:
                continue
            cat_type = markleft.index(left_dist) + 1
        if cat_type > 0:
            cats.append((cat_type, mtext, 0))
    return cats
#______________________________
def isUpperStart(text_list, per =0.6):
    n = 0
    for str in text_list:
        #remove all
        pattern = re.compile(r'[^A-Za-z]{1,}', re.IGNORECASE)
        str = re.sub(pattern, '', str)
        str = str.strip()
        #
        if str == "":
            continue
        first = str[0]
        if ord(first) >= ord('A') and ord(first) <= ord('Z'): 
            n += 1
    px = n / len(text_list)
    if px < per:
        return False
    return True
def isValidMark(text_list):
    #propcess
    check_data = []
    for t in text_list:
        t = t.strip()
        if len(t) < 1:
            continue
        if t not in check_data:
            check_data.append(t)
    text_list = check_data
    if len(text_list) < 5:
        return False
    if not isUpperStart(text_list):
        return False
    # can not contain
    arr = ['..','https://','http://']
    for text in text_list:
        for a in arr:
            if a in text.lower():
                return False
    for text in text_list:
        text = text.strip()
        if text.endswith("."):
            n = ''.count(". ")
            if n >= 1:
                return False   
    
    end_invalid = 2
    arr = [',', '-',' a',' the', ' are', ' is', ' and', ' to', ' been']
    # all is upper 
    #['T', 'M', 'N', 'T', 'E']
    i = 0
    for text in text_list:
        lx = len(text)
        i += lx
    if i <= len(text_list):
        return False
    #['— # —', '— $ —', '— . —', '— 1 —', 
    
    # number 
    max_number = 1
    i = 0
    for text in text_list:
        flag = stringutil.isAllNumber(text)
        if flag:
            i += 1
    if i>= max_number:
        return False
    #contain a-z
    for text in text_list:
        text = text.strip()
        if len(text) >= 1: #排除空值
            flag = stringutil.containsEnglishChar(text)
            if not flag:
                return False
    #['Me c h a n i c a l E n g i n e e r i n gR e p o r t 2 0 0 5 / 1 6P 
    max_a_len = 10
    for text in text_list:
        tx = text.split()
        i = 0
        for t in tx:
            if len(t) == 1:
                i += 1
        if i>= max_a_len:
            return False    
    return True
