from  PIL import  Image
#import pytesseract
#import  cv2 as cv
 
#pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

IMAGE_EMPTY_TEXT = '     '

#image big 
def getImageText(image):
    global IMAGE_EMPTY_TEXT
    
    text = ""
    try:
        text=pytesseract.image_to_string(Image.open(image))
        if len(text)< 10:
            return IMAGE_EMPTY_TEXT
        return text
    except:
        return None
    