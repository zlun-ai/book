# -*- coding:utf-8 -*-
import urllib.request
import brotli
import http.cookiejar
import re
import ssl
import socks
import socket
print (ssl.OPENSSL_VERSION)

def setSocksProxy(ip = '127.0.0.1', port = 1080, user =None, psw =None, encode =''):
    socks.set_default_proxy(proxy_type=socks.SOCKS5, addr=ip, port=port, rdns=True, username=user, password=psw)
    socket.socket = socks.socksocket 
    

def getcontent(crawl_response):
    #print(crawl_response.getheaders())
    content = crawl_response.read()
    
    encoding = crawl_response.getheader("Content-Encoding")
    #charest and content_type
    message = crawl_response.info()
    content_type = message.get_content_type()
    print(content_type)
    print("encoding=", encoding)
    if content_type != 'text/html' and content_type !="application/xml" and content_type!="text/xml" and content_type !="application/json":
        return content
    
    if not encoding:
        pass

    try:
        if encoding == 'br':
            import brotli
            content = brotli.decompress(content)
            
        if encoding == 'gzip':
            import gzip
            content = gzip.decompress(content)
    except Exception as e:
        print(e)
        
        #charset
    charset = None
    charset = message .get_content_charset(None)
    if not charset:
        charset = message.get_charsets(None)
        if not charset:
            import chardet
            result=chardet.detect(content)
            charset=result['encoding']
        else:
            charset = charset[0]
    if not charset: # default set utf-8
        charset = 'utf-8'    
       # print(content)

       
    content = content.decode(charset)

    print(charset)
    print(type(content))
        
    if charset != 'utf-8':# convert utf-8
        content = content.encode('utf-8', errors='ignore').decode("utf-8")
    #check by content with google
    if content.count("/sorry/") > 0:
        return None
    return content

def getRequestOpener(proxy = False):
    
    context=ssl._create_unverified_context()  
    sslHandler = urllib.request.HTTPSHandler(context=context)
    #proxy
    proxies = {'https': 'https://127.0.0.1:10086', 'http': 'http://127.0.0.1:10086'}
    proxies_processor = urllib.request.ProxyHandler(proxies)
    
    #cookie
    cookie = http.cookiejar.CookieJar()
    cookie_processor = urllib.request.HTTPCookieProcessor(cookie)
    if proxy:
        opener = urllib.request.build_opener(proxies_processor, sslHandler)
    else:
        opener = urllib.request.build_opener(sslHandler)

    headers = []
    headers.append(('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'))
    headers.append(('Accept-Encoding', 'gzip, deflate, br'))
    headers.append(('Accept-Language', 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7'))
    headers.append(('Cache-Control', 'no-cache'))
    headers.append(('Referer', 'https://www.google.com/'))
    headers.append(('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'))
    #headers.append(('cookie', 'DUP=Q=wbcqycWLnFHB360gxzWe2g2&T=388415889&A=2&IG=C8DD528919DA4FE2B0F6D4AAA1BA6351; SRCHD=AF=NOFORM; MUID=0D8A054364666A6B31040D0E606669CF; _ITAB=STAB=REC; _IREC=SEETEXT=1; fbar=imgfbar=1; imgv=lodlg=2; _UR=MC=1; MUIDB=0D8A054364666A6B31040D0E606669CF; SRCHUID=V=2&GUID=C1ED4529928D4BAFAC8A6882D69058C9&dmnchg=1; ANON=A=E58833A8E04775B990D293E1FFFFFFFF&E=17e5&W=1; _EDGE_S=mkt=zh-cn&SID=220AB97ECE6C6FD32A79B7CFCF426E9A; BPF=X=1; SNRHOP=I=&TS=; _SS=SID=220AB97ECE6C6FD32A79B7CFCF426E9A&bIm=933358; ENSEARCH=BENVER=1; SerpPWA=reg=1; ULC=P=A4EC|31:@24&H=A4EC|31:24&T=A4EC|31:24:4; SRCHUSR=DOB=20181112&T=1587561489000&POEX=W; ipv6=hit=1587565092403&t=4; SRCHHPGUSR=CW=1366&CH=242&DPR=1&PR=1&UTC=480&WTS=63723158289&HV=1587561491'))
    opener.addheaders = headers

    return opener

def getResponse(url, proxy = False):
    opener = getRequestOpener(proxy)
    crawl_response = opener.open(url, timeout = 30)
    return crawl_response
    
    
def getcontentfromurl(url, proxy = False):
    #if proxy:
        #setSocksProxy()
    #opener每次都不相同
    ctx_info = {}
    ctx_info["content"] = ""
    ctx_info["final_url"] = ""
    opener = getRequestOpener(proxy)
    crawl_response = None
    try:
        #ignore ssl        
        crawl_response = opener.open(url, timeout = 30)
        final_url = crawl_response.geturl()
        ctx_info["final_url"] = final_url
        print(f"final url = {final_url}")
    except urllib.error.HTTPError as exh:
        print("exh=", exh)
        et = str(exh)
        if "404" in et:
            ctx_info["content"] = "404: Not Found"
            return ctx_info
        if "403" in et:
            ctx_info["content"] = "HTTP Error 403: Forbidden"
            return ctx_info
        print(exh)
    except urllib.error.URLError as ex:
        print("ex=", ex)
        print(ex)
    except Exception as e:
        print("e=",e)
        print(e)
    print("crawl_response",crawl_response)
    if crawl_response is None:
        return None
    crawl_response_code = crawl_response.getcode()
    print(f"crawl_response_code = {crawl_response_code}")

    if crawl_response_code in [200, 202]:
        try:     
            content = getcontent(crawl_response)
            ctx_info["content"] = content
            return ctx_info
        except Exception as ex:
            print(ex)
    if crawl_response_code in [404, 403]: #不存在
        ctx_info["content"] = "404: Not Found"
        return ctx_info

    return None
def sendData(url, data, opener = None, proxy = False):
    '''
    data = {'log':username, 'pwd':psw, 
        'wp-submit':'Log In', 
        'redirect_to':'https://www.tutorialexample.com/wp-admin/'}
post_data = urllib.parse.urlencode(data).encode('utf-8')
    '''
    #print(url)
    post_data = urllib.parse.urlencode(data).encode('utf-8')
    if opener is None:
        opener = getRequestOpener(proxy)
    crawl_response = None
    try:
        #ignore ssl        
        crawl_response = opener.open(url, data= post_data, timeout = 120)
    except Exception as e:
        print(e)
        crawl_response = None
    if not crawl_response:
        return None
    crawl_response_code = crawl_response.getcode()
    if crawl_response_code == 200:        
        content = getcontent(crawl_response)
        return content
    return None

#url = 'https://www.google.com/search?safe=strict&source=hp&ei=YdllXfP5J6Ht9APKwaOgCQ&q=java&oq=java&gs_l=psy-ab.3...120010.120762..121294...0.0..0.0.0.......0....1..gws-wiz.&ved=0ahUKEwizrunBtaTkAhWhNn0KHcrgCJQQ4dUDCAc&uact=5'
#url = 'https://www.baidu.com'
#content = getcontentfromurl(url, proxy = True)
#print(content[0:500])