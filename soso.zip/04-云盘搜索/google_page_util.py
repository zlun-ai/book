import asyncio
import random
import time
from http.cookiejar import Cookie

from pyppeteer import launch
import fileutil

params = {
    'headless': True,          # 关闭无头浏览器
    'dumpio': True,             # 防止浏览器卡主
    "executablePath":r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    #'userDataDir': r'D:\ProgramData\PDF-Spider',     # 用户文件地址
    'args': [
        '--disable-infobars',           # 关闭 自动化提示框
        '--window-size=1920, 1080',     # 窗口大小
        '--log-level=30',               # 日志保存等级，建议设置越小越好，否则生成的日志占用空间很大 30为 warning级别
        '--user-agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
        '--no-sandbox',                 # 关闭 沙盒模式
        '--start-maximized',            # 窗口 最大化 模式
        '--disable-blink-features=AutomationControlled'
        #'--proxy-server=http://127.0.0.1:7890'  # 代理
    ]
}

GOOGLE_BROWSER = None
PAGE = None
# get cooke
cdata = fileutil.get_content("data/cookie.txt")
cdata = cdata.strip()

COOKIE = "SID=g.a000xwhEpezuX8-PucbXPXL45uHhN1P3YttLb4jT2dg9_YZcNohWWcZRq5W3wNl8MqSXFpDELwACgYKAbsSARISFQHGX2MieK2zpdzPS5Cip0mxh_RL4xoVAUF8yKqotEhlkS1HBgJYf4Tl3xaZ0076; __Secure-1PSID=g.a000xwhEpezuX8-PucbXPXL45uHhN1P3YttLb4jT2dg9_YZcNohWh2ZOy_9E9HmTqGnJzYTHOQACgYKAeASARISFQHGX2MiO-crdmvXL-zZB8OLtMmYzhoVAUF8yKrT61UmVnHOfF1wePvDyFw80076; __Secure-3PSID=g.a000xwhEpezuX8-PucbXPXL45uHhN1P3YttLb4jT2dg9_YZcNohWc0zranNdAOQpK263kMD1zgACgYKATESARISFQHGX2Mirl-rypLwp3OpgMmo5LHysBoVAUF8yKq04dA0hfkc5Xw7c-Ugo0Px0076; HSID=AEjf0I4oQmmUBYelU; SSID=AZT7P2LgL-4BXAcUJ; APISID=sJfAX3FO0NJGHR4-/ALvdgrh4S-iwU90bC; SAPISID=wF_URsM54xcZcnHk/A2vGGujB8VA6gE5Kp; __Secure-1PAPISID=wF_URsM54xcZcnHk/A2vGGujB8VA6gE5Kp; __Secure-3PAPISID=wF_URsM54xcZcnHk/A2vGGujB8VA6gE5Kp; AEC=AVh_V2jKbL36amebmBTbN_c4eOHWrsEgrr-0G_xTQZiFEK_zABAzqTMIo2I; NID=524=Rh7wKQPtq2WUfeuwiNd3tmLi1PZAyKy76qWxQNkNuHPbslcBIuAWaVhreAsLadaEREp29AafQsKYLX_f25HbASATIIjywSdWCkNR2gcOJ20bvcZ6DoIuB1ZZYeyI_ENvjpLms_xeevyp9V6EhhIvaYlF_Dsy1gGxhD54Hq5K0Nh_C2IXuuM36CHYs8_WpYshg3U-MQYDlm8LEoYYozO3ZoxeVA9gKXBwk1hnPBxgHEDvtlX72mft5pVDkOzirPc9BoxuYTGvuGGEdptgq8VbPs_4bGL8R9t4_AcDmB08ocZvb9kIwTcgokl4XLuFR_nX3yb7YJd27pq-GTFCr2XF4gikiBBqBx9oxXRt3joLK_nhyjlW3V-yk5Ya0NCdnTH8EmPG-hikoz9p9DmBmfdale9-1O9rYURPWaTwHyqBGOo5RBFVD5uEeiYCmL1AzpCIyWvhgfF9tfXrt_2DfAaP00XoPKHKISybek_qYhSm3fKiRmx5mm65KCDoM4AOhSgurZkOTF1FXfE8Jg1a3sBFceLviVZA10G3zndiPGqPLEZMyXDqyWGFIpv6HxSWsdgW-0GwwDRx-sNM7Pt8He4KASA7oKzzhUAKmH8UP0ma4fUYlkWe7Xg1BYPCgUpt3v6exIz4xlhxhEx3RJSdCk233KDTS2zVQcmlZKAKWg-pjWYJaE6TEjIBY4pvuC97ptadP7E6pjK-ROiT3CnGwt45tcPszvMfF-MKcfzolNdIZ0Y1fevaWwzG6Xa5CcPMEvEX8W6ijDxxMUHXJSKVSawuj282wIAiVxRGqbY_4ywU; __Secure-1PSIDTS=sidts-CjIB5H03P6SR-eYeM1nSbahBr2AqNy8d9lx-B6AdCdsQSbBj17Asxg_Xz3XCML3YwORpoxAA; __Secure-3PSIDTS=sidts-CjIB5H03P6SR-eYeM1nSbahBr2AqNy8d9lx-B6AdCdsQSbBj17Asxg_Xz3XCML3YwORpoxAA; DV=I1D4-IWd2ikp8DWt3o2g3zJT0c1-d1lgcat4Aaz4mwAAAAA; SIDCC=AKEyXzU08CUnQGCuLXgzPW8d2sk5zSH8ZBWTmX3qfmPVp-9Q4cKc-K8j498MQOMeNvsyn5dHHg; __Secure-1PSIDCC=AKEyXzWF5bhAHi3oUb6Oh7Bjgkbn4CPAERifOw-60U8xbZp1NxFba0XIJa0UvoFdvsJJhGOxsXg; __Secure-3PSIDCC=AKEyXzWoC2IERP4lx4R_SbZoqtnd4pnrdBpbhZembuahpFSNGoxB-12tcG9il8neQZP0Vil8og"
if cdata != "":
    COOKIE = cdata

async def main(url, reset_cookie):
    global GOOGLE_BROWSER,PAGE, COOKIE
    if reset_cookie:
        cdata = fileutil.get_content("data/cookie.txt")
        cdata = cdata.strip()
        if cdata != "":
            COOKIE = cdata

    # 启动一个浏览器
    # browser = await launch(headless=False, args=['--disable-infobars', '--window-size=1920, 1080'])
    if GOOGLE_BROWSER is None:
        GOOGLE_BROWSER = await launch(**params)

    browser = GOOGLE_BROWSER
    except_status = False
    # 创建一个页面
    if PAGE is None:
        page = await browser.newPage()
        PAGE = page
        # 设置页面视图大小

        await page.setViewport({'width': 1000, 'height': 600})
        await page.evaluate("() => delete navigator.__proto__.webdriver")  # 隐藏自动化特征
        await page.evaluateOnNewDocument('''
            () => {
                delete navigator.__proto__.webdriver
            }
        ''')
        await page.setUserAgent("Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36")  # 替换为实际 UA

    page = PAGE

    await page.setExtraHTTPHeaders({
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
        "Cache-Control": "no-cache",
        "Referer": "https://www.google.com/",
        "authority": "www.google.com",
        "Sec-Fetch-Mode":"navigate",
        "Sec-Fetch-Dest":"document",
        "cookie": COOKIE
    })

    # 跳转到百度
    await page.goto(url)
    # 输入要查询的关键字 (select, 内容)
    #await page.type('#kw', '有勇气的牛排')
    # 点击提交按钮 click 通过 selector点击指定的元素
    #await page.click('#su')

    # 获取 Cookie
    #cookies = await page.cookies()

    time.sleep(random.randint(15,25))

    try:
        content = await page.content()
        time.sleep(random.randint(10, 15))
        #等待相关元素载入后才获取cookie
        #await page.waitForSelector("#result-stats")
        cookie = await page.cookies()
        temp = ""
        if len(cookie) > 0:
            key = ["AEC","NID"]
            d = {}
            for c in cookie:
                d[c["name"]] = c["value"]
            if "AEC" in d:
                temp += f"AEC={d["AEC"]}"
            if "NID" in d:
                temp += "; "+f"NID={d["NID"]}"
            #if temp != "":
                #COOKIE = temp

            COOKIE = temp#cookie[0]["value"]
            COOKIE = COOKIE.strip()
            fileutil.save_to_file("data/cookie.txt", COOKIE)

        print("cookie=", cookie)
        #await page.close()
        #print(content)
        ###########
        #await browser.close()
        #del browser
        #GOOGLE_BROWSER = None
       # PAGE = None
        ###################

        #fileutil.save_to_file('google-r-2.html', content)
    except Exception as e:
        print(e)
        reset_cookie = True
        except_status = True
    finally:
        if reset_cookie:
            time.sleep(random.randint(20,30))
            await browser.close()
            del browser
            GOOGLE_BROWSER = None
            PAGE = None
        if except_status:
            return None
    time.sleep(random.randint(20,30))
    return content

def get_google_page(url, reset_cookie):
    return asyncio.get_event_loop().run_until_complete(main(url, reset_cookie))

urlx = ["https://www.google.com/search?q=filetype%3Apdf+%22ISBN%22+%22All+right+reserved%22+python%E7%BC%96%E7%A8%8B&hl=en&num=30&start=0&newwindow=1&safe=strict",
        "https://www.google.com/search?q=filetype%3Apdf+%22ISBN%22+%22All+right+reserved%22+java%E7%BC%96%E7%A8%8B&hl=en&num=30&start=0&newwindow=1&safe=strict"]
#for u in urlx:
    #get_google_page(u)