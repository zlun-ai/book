# -*- coding:utf-8 -*-
import fileutil
import pdfutil
import isbnutil
import random
import os
import time
import netutil
import sys, fitz
import stringutil
import pdftitleutil
import re


#
'''dir = "F:\\3.pdf"
base_title = 'Face Recognition by Humans: Nineteen Results All Computer ...'
title = pdftitleutil.getPdfTitleWithBased(dir, base_title)
print(title)'''

dir = r'F:\google-pdf\1664-Apress.Pro.dotNET.4.Parallel.Programming.in.CSharp.May.2010.pdf'

dir = r'F:\google-pdf\3971-oakland15_uideception.pdf'


full = pdfutil.isFullPdf(dir)
print(full)
exit(0)

#dir = r'F:\google-pdf\download\2741-SQL%20Injection%20Attacks%20and%20Defense.pdf'
dir = "F:\\PDF-Documents\\Standard-Books\\"
dir = "F:\\google-pdf\\download\\" 
files = fileutil.traverseDir(dir)
print("files="+str(len(files)))
files_bad=[]
for f in files:
    full = pdfutil.isFullPdf(f)
    
    if not full:
        files_bad.append(f)
print(files_bad)
exit(0)
#pdfinfo = pdfutil.getPdfEbookInfo(dir, strict = True)
#print(pdfinfo)

doc, pages = pdfutil.getAllPDFPages(dir)

print(doc.needsPass)
#content = pdfutil.getPagesContent(pages)
#pdfutil.isFirstPDFBook(pages, max_words = 150)
#content = pdfutil.getFirstPageContentByImage(pages[0])
info = pdfutil.getPDFISBN(pages, max_page = 50)
print(info)