import pymysql
import stringutil

from mysqlutil import MySQLUtil

mysql = None
def connect():
    global mysql
    
    if not mysql:
        print("connect db")
        mysql = MySQLUtil()
        mysql.connectDB(host='127.0.0.1', user='root', psw='Pass@1234', db_name="yunpan")
        print("connect db success")
connect()
