# -*- coding:utf-8 -*-
import os.path
import jieba
import netutil
import fileutil
import urllib
import time
import random
import stringutil
import htmlutil
import json
import tabledb
import re
import book_util
#-----------
def remove_date(text):
    pattern = re.compile(r'[0-9\-/]{5,}', re.IGNORECASE)
    text = re.sub(pattern, '', text)
    text = text.strip()
    return text
def get_valid_file_name(file_name):
    dirname, filename, extend = fileutil.getFilePathInfo(file_name)
    filename = remove_date(filename)

    return filename

def get_books(file_name, num = 10):
    ori_file = file_name
    valid_file_name = get_valid_file_name(file_name)
    file_name = book_util.get_clean(valid_file_name)
    if file_name == "":
        return None

    sql = f"SELECT book_id, book_slug, book_name,book_author, book_ori_author, book_isbn, book_content, book_info FROM `all_book` WHERE match(book_content) against('{file_name}') limit  {num}"
    #print(sql)
    books = tabledb.query_sql(sql)
    book_ids = []
    if books is not None:
        for book in books:
            book_id = book[0]
            book_slug = book[1]
            book_name = book[2]
            book_author = book[3]
            book_ori_author = book[4]
            book_authors = book_author + " "+ book_ori_author
            book_isbn = book[5]
            flag = book_util.is_book(file_name, book_name, book_authors, book_isbn)
            if flag:
                print(f"文件：{ori_file}《=》 图书：{book_name}, 作者：{book_authors}")
                book_ids.append(book_id)
    return book_ids



def is_book_type(text):
    text = text.strip()
    text = text.lower()
    arr = [".pdf",".epub",".mobi", ".zip",".rar",".txt",".docs",".chm",".azw",".azw3",".azw6"]
    for a in arr:
        if text.endswith(a):
            return True
    return False
def get_all_links():
    #遍历所有的链接
    table = "yunpan_link"
    keys = 'link_id, link_url, file_name'
    data= {'link_status':200}
    links = tabledb.query(table, keys, data, orderby = "link_id asc", num = None)

    lx = len(links)
    all_data = [{"link_id": x[0], "link_url":x[1], "file_name":x[2]} for x in links if is_book_type(x[2])]
    print(f"all_data={len(all_data)}")
    print("start")
    return all_data

all_book_links = get_all_links()

for link in all_book_links:
    get_books(link["file_name"])


