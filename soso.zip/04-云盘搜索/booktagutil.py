import urllib.parse
from bs4 import BeautifulSoup
import fileutil
import stringutil
import htmlutil
import linkdb
import html
import re
import urlutil

ends = ['pdf', 
        'download free pdf',
        'pdf download', 
        'books download pdf', 
        'book download pdf', 
        'ebooks download pdf', 
        'ebook download pdf', 
        'e-books download pdf', 
        'e-book download pdf', 
        'tutorial download pdf', 
        'tutorials download pdf']
def getCheckTag(text):
    global ends
    text = text.lower()
    if stringutil.containsNonAscii(text):
        return False
    
    flag = False
    for e in ends:

        if text.endswith(e):
            l = len(e)
            text = text[0:-l]
            flag = True
            break
        else:
            e = "free "+e
            if text.endswith(e):
                l = len(e)
                text = text[0:-l]
                flag = True
                break
    text = text.strip()
    
        
    if not flag:
        return ""
    if text.count(" ") > 1 and len(text) > 8:
        return text.strip()
    return ""
def isValidTag(text):
    text = text.lower()
    
    
    arr=['text','paper','papers','textbook','novel',"free","download","online","ebook","e-book","book","books","ebooks","e-books"];
    
    for a in arr:
        if a in text:
            return False
    
    arr=['pdf','chm','epub','mobi','azw','azw3','azw6']
    for a in arr:
        if a in text:
            return False
    return True

def getBookTag(text):
    t = getCheckTag(text)
    if t == "":
        return ""
    if isValidTag(t):
        return t

text = 'the aa group pdf'
text_tag = getBookTag(text)
print(text_tag)