from datetime import datetime
import time
import random

def getCurrent():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S') 

