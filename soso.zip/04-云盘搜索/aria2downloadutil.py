#-*- coding: utf-8 -*-
import urllib.request
import urllib.parse
import json
import os
'''
jsonreq = {'jsonrpc':'2.0', 'id':'qwer', 'method':'aria2.addUri', 'params':[['http://example.org/file']]}
print(jsonreq)
print(type(jsonreq))
jsonreq = urllib.parse.urlencode(jsonreq).encode(encoding='utf-8')
req = urllib.request.Request(url='http://localhost:6800/jsonrpc', data=jsonreq)
c = urllib.request.urlopen(req)
print(c.read())'''

import os
import time
import sys
import subprocess
import fileutil

save_dir = r'F:\all-google-en-pdf\download'


def get_file_from_cmd(url, out_filename):
    if fileutil.fileexist(out_filename):
        return True
    dirname, filename, extend =fileutil.getFilePathInfo(out_filename)
    out_filename = filename+".pdf"
    cmd = r'D:\ProgramData\aria2\aria2c.exe -t 300 -x 8 -d '+ dirname +' -m 5 -o ' + out_filename + " "+ url
    #print(cmd)
    #msg = os.popen(cmd)
    #obj = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    #stdout, stderr = obj.communicate()
    #s = subprocess.check_output(cmd, shell=True)
    try:
        p1=subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE)
        print("---start---")
        msg_content = ''
        for line in p1.stdout:
            print(line)
            l = line.decode(encoding="utf-8", errors="ignore")
            msg_content += l
        p1.wait()
        #print("---end---")
        #msg_content = msg_content.decode("utf-8", 'ignore')
        #msg_content = msg.read()
        #print("---msg---")
        #print(s)
        #print(stdout)
        #print(obj.stdout.readlines())
        #print("---msg---")
        if '(OK):download completed' in msg_content:
            print("download by aira2 successfully.")
            return True
        return False
    except Exception as e:
        print(e)
        return False

    
#url = 'http://www.ascd.org/ASCD/pdf/siteASCD/publications/books/principals%20guide-to-special-education-sample-chapters.pdf'   
#url = 'http://www.al-edu.com/wp-content/uploads/2014/05/TheMotivationalHandbook.pdf'
#get_file_from_cmd(url, 'godoq.pdf') 
#print("end")