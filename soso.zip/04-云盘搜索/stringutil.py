import hashlib
import base64
import re
import isbnutil
import time
import random
import html
import difflib
from difflib import SequenceMatcher
import jieba
#from cairosvg.text import text

def removeURL(text):
    pattern=r'(?i)\b((?:[a-z][\w-]+:(?:/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’]))';
    match = re.findall(pattern, text)
    #print(match)
    for m in match:
        url = m[0]
        text = text.replace(url, '')
    return text
def longest_Substring(s1,s2): 
  
     seq_match = SequenceMatcher(None,s1,s2) 
     match = seq_match.find_longest_match(0, len(s1), 0, len(s2)) 
     # return the longest substring 
     if (match.size!=0): 
          return s1[match.a: match.a + match.size]
     else: 
          None
def string_similar(s1, s2):
    return difflib.SequenceMatcher(None, s1, s2).quick_ratio()

def string_similar_strict(s1, s2):
    seq_match = SequenceMatcher(None,s1,s2)
    blocks = seq_match.get_matching_blocks()
    print(blocks)
    long_size = 0
    for m in blocks:
        s = s1[m.a: m.a + m.size] # contain blank
        s = s.strip()
        if s.count(" ") > 1:
            long_size += len(s)
    p1 = long_size / len(s1)
    p2 = long_size / len(s2)
    return p1, p2

def getUnique():
    return str(time.time())+"-"+str(random.randint(1,10000))    

def containISBN(str):
    isbn = isbnutil.getValidISBN(str)
    if not isbn:
        return False
    if len(isbn)> 1:
        return True
    return False
def endsWithAZ(str, allow_num = True):
    str=str.strip()
    last = str[::-1][0]
    last = ord(last)
    if last >= ord('a') and last <= ord('z'):
        return True
    if last >= ord('A') and last <= ord('Z'):
        return True
    if allow_num:
        if last >= ord('0') and last <= ord('9'):
            return True
    return False
def startWithAZ(str, allow_num = True):
    str=str.strip()
    last = str[0]
    last = ord(last)
    if last >= ord('a') and last <= ord('z'):
        return True
    if last >= ord('A') and last <= ord('Z'):
        return True
    if allow_num:
        if last >= ord('0') and last <= ord('9'):
            return True
    return False
def getsubstrFromString(str, substr):
    pattern = re.escape(substr)
    matcher = None
    matcher = re.findall(pattern, str, re.I)
    #print(matcher)    
    if not matcher:
        return None
    if len(matcher)> 0:
        return matcher[0]

    
def replace(old, new, str, caseinsentive = False):
    if caseinsentive:
        return str.replace(old, new)
    else:
        return re.sub(re.escape(old), new, str, flags=re.IGNORECASE)

def removeSymbol(str):
    str =str.replace(":"," ")
    str =str.replace("-"," ")
    str =str.replace("&"," ")
    str =str.replace("_"," ")
    str =str.replace("."," ")
    str =str.replace("("," ")
    str =str.replace(")"," ")
    str =str.replace("["," ")
    str =str.replace("]"," ")
    str =str.replace("%"," ")
    str =str.replace("'"," ")
    str =str.replace("\""," ")
    str =str.replace("!"," ")
    str =str.replace("?"," ")
    str =str.replace("/"," ")
    str =str.replace("\\"," ")
    str = str.replace(",", " ")
    return str


def containsNonAscii(str):
    regexp = re.compile(r'[^\x00-\xff]')
    if regexp.search(str):
        return True
    return False

def removeSymbols(text, num = 3):
    text = text.strip()
    pattern = re.compile(r'[^a-zA-Z0-9]{'+str(num)+',}')
    str_temp = re.sub(pattern, ' ', text)
    str_temp = str_temp.strip()
    return str_temp

def containsEnglishChar(str):
    str = str.strip()
    pattern = re.compile(r'[a-zA-Z]{1,}')
    str_temp = re.sub(pattern, '', str)
    str_temp = str_temp.strip()
    if len(str_temp) == len(str):
        return False
    return True
def onlyRemainAZ(str):
    pattern = re.compile(r'[^A-Za-z0-9]{1,}', re.IGNORECASE)
    str = re.sub(pattern, '', str)
    str = str.strip()
    return str
def isALLAZ(str):
    pattern = re.compile(r'[A-Za-z]{1,}', re.IGNORECASE)
    str = re.sub(pattern, '', str)
    str = str.strip()
    if str == '':
        return True
    return False
def remove_non_ascii(text, replace):
    """去除字符串中的所有非ASCII字符"""
    return re.sub(r'[^\x00-\x7F]', replace, text)

def count_chinese_characters(text):
    """统计字符串中中文汉字的个数"""
    # 使用正则表达式匹配所有汉字
    chinese_chars = re.findall(r'[\u4e00-\u9fa5]', text)
    return len(chinese_chars)
def isAllNumber(str):
    pattern = re.compile(r'[0-9]{1,}')
    str = re.sub(pattern, '', str)
    str = str.strip()
    if str == '':
        return True
    return False

#d = 'this is a 7+ a xx5 4r'
#dx = [i for i in d.split() if isALLAZ(i)]
#print(dx)

#return string
def urlsafe_b64encode(data, type='string'):
    if type == 'string':
        data = data.encode("utf-8")
    data = base64.b64encode(data)
    data = data.decode("utf-8")
    data = data.replace("+",'-')
    data = data.replace("/",'_')
    data = data.replace("=",'')
    return data
#input is string,
def urlsafe_b64decode(data, type = 'string'):
    data = data.replace("-",'+')
    data = data.replace("_",'/')
    mod4 = len(data) % 4
    if(mod4):
        temp = '===='
        data += temp[0:mod4]
    data = base64.b64decode(data.encode("utf-8"))
    if type =='string':
        return data.decode("utf-8")
    return data # return byte

def base64_encode(str):
    byte_str = str.encode()
    base64_str= base64.b64encode(byte_str)
    base64_str = base64_str.decode()
    return base64_str
def removeEmpty(text, newline = False):
    if newline:
        pattern = re.compile(r'[\r\n\t]{1,}')
        text = re.sub(pattern, ' ', text)
    pattern = re.compile(r'[ ]{2,}')
    text = re.sub(pattern, ' ', text)
    
    return text.strip()

def base64_decode(base64_str):
    byte_str = base64_str.encode()
    str = base64.b64decode(byte_str)
    str = str.decode()
    return str


def remove_punctuation_and_special_chars(text, sep=""):
    # 使用正则表达式匹配非中文、字母、数字的字符，并替换为空字符串
    pattern = r'[^\u4e00-\u9fa5a-zA-Z0-9]'  # 保留中文、英文字母、数字
    cleaned_text = re.sub(pattern, sep, text)
    return cleaned_text


def getStringSlug(text):
    text = html.unescape(text)
    pattern = re.compile(r'[\x7B-\xff]')
    text = re.sub(pattern, ' ', text)

    pattern = re.compile(r'[\x5B-\x60]')
    text = re.sub(pattern, ' ', text)

    pattern = re.compile(r'[\x3A-\x40]')
    text = re.sub(pattern, ' ', text)

    pattern = re.compile(r'[\x00-\x2F]')
    text = re.sub(pattern, ' ', text)

    text = remove_punctuation_and_special_chars(text, " ")
    text = removeEmpty(text)
    return text
    
def getMD5(str):
    str = str.encode("utf-8")
    hash_obj = hashlib.md5(str)
    return hash_obj.hexdigest()

def cut(text, start, end):
    text = text.split(start)
    if len(text) < 2:
        return ""
    text = text[1]
    text = text.split(end)
    if len(text) < 1:
        return ""
    text = text[0]
    return text

def get_fenci(ctx):
    ctx = getStringSlug(ctx)
    seg_list = jieba.cut(ctx, cut_all=False)
    seg_list = [x.strip() for x in seg_list if x.strip() != ""]
    seg = " ".join(seg_list)
    seg = seg.strip()
    return seg