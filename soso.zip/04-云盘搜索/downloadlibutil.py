# -*- coding:utf-8 -*-
import urllib.request
import urllib.parse
import http.cookiejar
import os
import time
import random
import progressbar
import socket
import download as downloadlib
#from wrapt_timeout_decorator import *
download_max_time = float(60.0)
'''socket.setdefaulttimeout(download_max_time)
print(str(socket._GLOBAL_DEFAULT_TIMEOUT))
print(socket.getdefaulttimeout())
socket.s'''

class Monitor:
    pass
#get url file size
def get_size(url, opener):
    content_length = -2
    crawl_response = None
    try:
        #ignore ssl        
        crawl_response = opener.open(url, timeout = 30)
    except urllib.error.HTTPError as exh:
        print(exh)
    except urllib.error.URLError as ex:
        print(ex)
    except Exception as e:
        print(e)
        crawl_response = None
    if not crawl_response:
        content_length = crawl_response.getheader("Content-Length")
        if not content_length:
            return -1    
        return int(content_length)
    return content_length

def get_readable_size(size):
        if size < 0:
            return "Unknown"
        units = ["Byte", "KB", "MB", "GB", "TB", "PB"]
        unit_index = 0
        while size >= 1024:
            size = size / 1024
            unit_index += 1
        return "%.2f %s" % (size, units[unit_index])

def getRootURL(url):
    url_info = urllib.parse.urlparse(url)
    #print(url_info)
    host = url_info.scheme+ "://" + url_info.netloc
    return host

def getRequestOpener(url, cookie = False):
    opener = None
    
    class CustomAbstrctHandler(urllib.request.AbstractHTTPHandler):
        def do_request_(self,req):
            req.timeout = 60
            super().http_open(req)
    customAbstract = CustomAbstrctHandler()
    if cookie :
        cookie = http.cookiejar.CookieJar()
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie))
    else:
        opener = urllib.request.build_opener()
        
    headers = []
    headers.append(('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'))
    headers.append(('Accept-Encoding', 'gzip, deflate, br'))
    headers.append(('Accept-Language', 'zh-CN,zh;q=0.9'))
    headers.append(('Cache-Control', 'max-age=0'))
    headers.append(('Referer', getRootURL(url)))
    headers.append(('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'))

    opener.addheaders = headers
    
    return opener
    

def download(url, local_filename, allow_types=['application/pdf','application/zip']):
    download_status = False
    download_try = 0
    download_max_timeout_try = 5
    #step 1. download direct
    print("download directly")
    
    fpath = downloadlib.download(url, local_filename, progressbar=True, timeout=download_max_time)
    
    
    download_status, download_try = downloadDirect(url, local_filename)
    #check is timeout
    if download_try == 2: #timeout
        for i in range(1,download_max_timeout_try):
            time.sleep(random.randrange(5,15))
            print("\nconnect time out, try=" + str(i))
            download_status, download_try = downloadDirect(url, local_filename)
            if download_status or download_try == 1:#cookie
                break
            if not download_status:
                continue
    #step 2. download with cookie 
    
    if download_try == 1 :
        print("download with cookie")
        download_status, download_try = downloadDirect(url, local_filename, True)
        
    return download_status, download_try
    

def downloadDirect(url, local_filename, withcookie = False, allow_types=['application/pdf','application/zip']):
    opener = None
    download_status = False
    file_check = False
    download_bar = None
    
    #
    download_try_cookie = 1 #cookie
    download_try_timeout = 2 #timeout
    #no any message print during downloading
    
    opener = getRequestOpener(url, withcookie)
    urllib.request.install_opener(opener)
    file_content_type = ''
    try:
        crawl_response = opener.open(url, timeout = 30)
        #local_file, response_headers = urllib.request.urlretrieve(url,local_filename,Schedule)
        file_content_type = response_headers.get_content_type()
        print(file_content_type)
    except urllib.error.HTTPError as e:
        error_code = e.code
        print(e)
        if error_code >= 403 or error_code >=500: #Not Found
            print("\n")
            print(e)
            print("fail to download!")
            download_status = False
            download_try = 0
            return download_status, download_try
    except urllib.error.URLError as ue: # such as timeout
        download_status = False
        print("fail to download!")
        return download_status, download_try_timeout
    except Exception as ee:
        download_status = False
        print(ee)
        return download_status, download_try_timeout

    if file_content_type not in allow_types:
        print("\nthis file type is not allowed!")
        print("fail to download!")
        if os.path.exists(local_filename):
            os.remove(local_filename)
        return False, 0
    if not download_status:
        if os.path.exists(local_filename):
            os.remove(local_filename)
            return False, 1
    
        print(download_status)
        print("fail to download!")
        return False, 1 #try
    return True, 0
#url = 'https://www.packtpub.com/sites/default/files/downloads/GoogleVRUpdateGuideforCardbook.pdf'

#local = os.path.join('F:\\','test.pdf')
#download(url, local)