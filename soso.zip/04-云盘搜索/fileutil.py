import json
import sys
import io
import os
import shutil
from unidecode import unidecode
import ctypes
import platform


def get_valid_links():
    data = {}
    with open("invalid_links.txt", 'r', encoding="utf-8") as fin:  # 读取文本文件
        for line in fin:
            line = line.strip()
            if line == "":
                continue
            data[line] = line
    return data

def createDirs(d):
    if not os.path.exists(d):
        os.makedirs(d)
def isUsedByOtherApp(f):
    try:
        new = f+"_"
        # if file is used by others, it can not be renamed
        os.rename(f,new)
        os.rename(new,f)
        return False
    except:
        return True
#f = r'F:\google-pdf\download\1325-Data%20Structures%20And%20Problem%20Solving%20Using%20C++%202nd%20ed%20-%20Mark%20Weiss.pdf'
#print(isUsedByOtherApp(f))

def formatSize(bytes):
    try:
        bytes = float(bytes)
        kb = bytes / 1024
    except:
        return ""

    if kb >= 1024:
        M = kb / 1024
        if M >= 1024:
            G = M / 1024
            return "%.2fG" % (G)
        else:
            return "%.2fM" % (M)
    else:
        return "%.2fKB" % (kb)

def getDiskFreeSpace(disk):
    """ Return disk free space (in bytes)
    """
    if platform.system() == 'Windows':
        free_bytes = ctypes.c_ulonglong(0)
        ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(disk), None, None, ctypes.pointer(free_bytes))
        return formatSize(free_bytes.value)
    else:
        st = os.statvfs(disk)
        return formatSize(st.f_bavail * st.f_frsize)
    
def getDiskFreeSpaceByte(disk):
    usage = shutil.disk_usage(disk)
    return usage[2]   
def fileexist(f):
    return os.path.exists(f)

#sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf8')
def readFile(file_name):
    if not fileexist(file_name):
        return None
    with open(file_name, 'rb') as fin:  #读取文本文件
        content = fin.read()
        content = content.decode("utf-8")
        content= unidecode(content)
        return content    
def save_to_file(file_name, contents):
    
    fh = None
    ok = False
    try:
        fh = open(file_name, 'w', encoding="utf-8")
        fh.write(contents)
        ok = True   
        print("save ok!", flush = True)
    except IOError as e:
        print(e)
        ok = False
        print("save fail!", flush = True)
    finally:
        print(type(fh))
        try:
            if fh:
                fh.close()
        except:
            ok = False
    return ok

def getFilePathInfo(absolute):
    
    dirname = os.path.dirname(absolute)
    basename = os.path.basename(absolute)
    info = os.path.splitext(basename)
    filename = info[0]
    extend = info[1]
    if extend.count("?"):
        extends = extend.split("?")
        extend = extends[0]
    
    return dirname, filename, extend #.pdf

#url='12.pdf'
#print(getFilePathInfo(url))
def deltorecyclebin(filename):
    if not os.path.exists(filename):
        return True
    res= shell.SHFileOperation((0,shellcon.FO_DELETE,filename,None, shellcon.FOF_SILENT | shellcon.FOF_ALLOWUNDO | shellcon.FOF_NOCONFIRMATION,None,None))
    if not res[1]:
        os.system('del '+filename) 
def deleteFile(file, to_recyclebin = False ):
    if to_recyclebin:
        return deltorecyclebin(file)
    if os.path.exists(file):
        try:
            os.remove(file)
            return True
        except Exception as e:
            print(e)
        return False
    return True 


        
def copyFile(src, dst):
    return shutil.copy(src, dst)
def moveFile(src, dst):
    dirname, filename, extend = getFilePathInfo(dst)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return shutil.move(src, dst)
 

    
def getfilesize(file_path):
    size = os.path.getsize(file_path)
    return formatSize(size)
    
def move(src, dest):
    shutil.move(src, dest)
    
def createDir(dir):
    if not os.path.exists(dir):
        os.mkdir(dir)

def filter(file, file_type='.pdf'):
    if file.endswith(file_type):
        return True
    return False

def traverseDir(dir, file_type = '.pdf'):
    files = []
    for entry in os.scandir(dir):
        if entry.is_dir():
            files_temp = traverseDir(entry.path, file_type)
            if files_temp:
                files.extend(files_temp)
        elif entry.is_file():
            path = entry.path
            
            if path.endswith(file_type):
                files.append(entry.path)
    return files
#1.dpf
def getFileNameByURL(link_id, link_url, extend=".pdf"):
    info = getFilePathInfo(link_url)
    fname = info[1]
    
    fname =fname.replace(":","-")
    fname =fname.replace("*","-")
    fname =fname.replace("<","-")
    fname =fname.replace(">","-")
    fname =fname.replace("?","")
    fname =fname.replace("\"","-")
    fname=fname.replace("|","-")
    fname =fname.replace("/","-")
    fname =fname.replace("\\","-")
    filename = str(link_id)+"-"+fname+extend
    return filename

def save_data(data, fx):
    with open(fx, "wb") as fin:
        fin.write(data)
def save_json(data, fx):
    text = json.dumps(data, ensure_ascii=False)
    with open(fx, "w", encoding="utf-8") as f:
        f.write(text)

def read_json(fx):
    with open(fx, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data

def get_lines(fx):
    with open(fx, "r", encoding="utf-8") as f:
        return f.readlines()
def get_content(fx):
    lines = get_lines(fx)
    return "".join(lines)