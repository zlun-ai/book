import asyncio
import random
import time
from http.cookiejar import Cookie

from pyppeteer import launch
import fileutil

params = {
    'headless': True,          # 关闭无头浏览器
    'dumpio': True,             # 防止浏览器卡主
    "executablePath":r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    'userDataDir': r'D:\ProgramData\PDF-Spider',     # 用户文件地址
    'args': [
        '--disable-infobars',           # 关闭 自动化提示框
        '--window-size=1920, 1080',     # 窗口大小
        '--log-level=30',               # 日志保存等级，建议设置越小越好，否则生成的日志占用空间很大 30为 warning级别
        '--user-agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36',
        '--no-sandbox',                 # 关闭 沙盒模式
        '--start-maximized',            # 窗口 最大化 模式
        '--disable-blink-features=AutomationControlled'
        #'--proxy-server=http://127.0.0.1:7890'  # 代理
    ]
}
GOOGLE_BROWSER = None
PAGE = None
async def create_brower():
    global GOOGLE_BROWSER, PAGE
    if GOOGLE_BROWSER is None:
        GOOGLE_BROWSER = await launch(**params)

    return GOOGLE_BROWSER

async def create_page():
    global GOOGLE_BROWSER, PAGE
    browser = await create_brower()
    if PAGE is None:
        #print(f"browser=", browser)
        context = await  browser.createIncognitoBrowserContext()
        page = await context.newPage()
        PAGE = page
        # 设置页面视图大小

        await page.setViewport({'width': 1000, 'height': 600})
        await page.evaluate("() => delete navigator.__proto__.webdriver")  # 隐藏自动化特征
        await page.evaluateOnNewDocument('''
            () => {
                delete navigator.__proto__.webdriver
            }
        ''')
        await page.setUserAgent("Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36")  # 替换为实际 UA

    await page.setExtraHTTPHeaders({
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
        "Cache-Control": "no-cache",
        "Referer": "https://www.google.com/",
        "authority": "www.google.com",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Dest": "document",
       # "cookie": COOKIE
    })
    # 存储所有请求URL
    return page


async def set_page_req():
    global PAGE
    await PAGE.setUserAgent(
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36")  # 替换为实际 UA

    await PAGE.setExtraHTTPHeaders({
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
        "Cache-Control": "no-cache",
        "Referer": "https://www.google.com/",
        "authority": "www.google.com",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Dest": "document",
        # "cookie": COOKIE
    })
async def go(url):
    global PAGE


    all_requests = []

    # 定义请求监听器
    def request_handler(req):
        all_requests.append(req.url)
        req.continue_()

    PAGE.on('request', request_handler)
    # 导航到目标URL
    await PAGE.goto(url, waitUntil=['domcontentloaded'])
    time.sleep(10)
    print("请求的url=", all_requests)
    return all_requests





# get cooke
#cdata = fileutil.get_content("data/cookie.txt")
#cdata = cdata.strip()

async def main(url):
    global PAGE
    page = await create_page()
    print(page)

    try:
        await set_page_req()
        await go(url)

    finally:
        if PAGE is not None:
            await PAGE.close()
            PAGE = None


    time.sleep(random.randint(15,25))



def get_google_page(url):
    return asyncio.get_event_loop().run_until_complete(main(url))

urlx = ["https://www.google.com/search?q=filetype%3Apdf+%22ISBN%22+%22All+right+reserved%22+python%E7%BC%96%E7%A8%8B&hl=en&num=30&start=0&newwindow=1&safe=strict",
        "https://www.google.com/search?q=filetype%3Apdf+%22ISBN%22+%22All+right+reserved%22+java%E7%BC%96%E7%A8%8B&hl=en&num=30&start=0&newwindow=1&safe=strict"]
for u in urlx:
    get_google_page(u)