# -*- coding:utf-8 -*-
import os
import sys
sys.path.append("../")

import netutil
import fileutil
import urllib
import netdetect
import time
import random
import stringutil
import htmlutil
import isbnutil
import tabledb
import google_page_util
import googletextparser_simple
import chengtong_util
import book_util
'''
本程序为根据关键词得到pdf文档链接
'''
table = '`yunpan_link`'
like = " and (file like '%.%') "

#每次获取一个
data = tabledb.query(table, keys='link_id, file_name', data={'link_status': 200})
# 全文搜索
#SELECT * FROM `all_book` WHERE match(book_content) against('蜜糖 与 盐巴') limit 10
