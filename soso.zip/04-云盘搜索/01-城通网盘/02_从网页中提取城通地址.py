# -*- coding:utf-8 -*-
import os
import sys
sys.path.append("../")

import netutil
import fileutil
import urllib
import netdetect
import time
import random
import stringutil
import htmlutil
import isbnutil
import tabledb
import google_page_util
import googletextparser_simple
import chengtong_parese_util
'''
本程序为根据关键词得到pdf文档链接
'''
reset_cookie = True
def startSearch():
    global reset_cookie
    # 获取要下载的链接
    table = '`link`'
    like = None  # " and (book_title like '%python%' or book_title like '%java%' or book_title like '%programming%' ) "

    #每次获取一个
    key = tabledb.query(table, keys='link_id, link_url, link_status', data={'link_status': 0}, like=like, num=1)
    # key = [[0, "python deep learning"]]
    print(key)
    if not key:
        link_id = 0
        link_url = "https://t.me/s/dianzhishu?after=11741"
        link_status = 0
        time.sleep(30)
        return
    else:
        #exit(0)
        link_id = key[0][0]
        link_url = key[0][1]
        link_status = key[0][2]
    link_status += 1
    print(link_url)
    if link_url.endswith(".pdf"):
        ctx_info = None
    else:
        ctx_info = netutil.getcontentfromurl(link_url)

    print("**********************")
    #print(content)
    if ctx_info:
        content = ctx_info["content"]
        if isinstance(content, bytes):
            tabledb.update(table, update_data={'link_status': link_status}, where_data={'link_id': link_id})
            return

        reset_cookie = True
        contentx = htmlutil.filter_tags(content)
        print("content len=" + str(len(contentx)))
        #if len(contentx) < 5000:
            #time.sleep(random.randint(1, 5))
            #return
        updated = True
        linkInfo = chengtong_parese_util.get_chengtong_file_url(content)
        for info in linkInfo:

            link_url = info['url']
            link_psw = info['psw']


            link_slug = stringutil.getMD5(link_url)
            data = {
                    "link_slug":link_slug,
                    "link_name":'',
                    "link_url": link_url,
                    "link_desc": '',
                    "link_psw":link_psw
            }
            tabledb.insert("yunpan_link", data)

        if updated:
            print("更新")
            # tabledb.update(table, update_data={'doc_status':1}, where_data={'doc_id':key_id})
            tabledb.update(table, update_data={'link_status': link_status}, where_data={'link_id': link_id})
        else:
            print("不更新")
    else:
        #pass
        tabledb.update(table, update_data={'link_status': link_status}, where_data={'link_id': link_id})

# url = 'https://www.baidu.com'
# startSearch()
def mainRun():
    isOnline = False
    while True:
        if not isOnline:
            isOnline = netdetect.networkIsOnline()
            if not isOnline:
                print("network is offline")
                time.sleep(random.randint(10, 20))
                continue
        if isOnline:
            startSearch()
            time.sleep(random.randint(3, 5))


##----
mainRun()
