# -*- coding:utf-8 -*-
import os
import sys
sys.path.append("../")

import netutil
import fileutil
import urllib
import netdetect
import time
import random
import stringutil
import htmlutil
import isbnutil
import tabledb
import google_page_util
import googletextparser_simple
import chengtong_util
'''
本程序为根据关键词得到pdf文档链接
'''
reset_cookie = True
def startSearch():
    global reset_cookie
    # 获取要下载的链接
    table = '`yunpan_link`'
    like = " and (file_name like '%.pdf') "

    #每次获取一个 data={'file_is_download': 0},
    all_links = tabledb.query(table, keys='link_id, userid, file_id, file_chk, file_download_url', data = {"1":1},like=like)
    # key = [[0, "python deep learning"]]
    print(len(all_links))
    for key in all_links:
        link_id = key[0]
        userid = key[1]
        file_id = key[2]
        file_chk = key[3]
        file_download_url = key[4]
        print(file_download_url)
        if file_download_url is not None:
            if file_download_url != "":
                continue

        print(userid, file_id, file_chk)
        if file_chk == "" or file_chk is None:
            continue

        file_download_meta = chengtong_util.get_file_download_url(userid, file_id, file_chk)
        if file_download_meta is not None:
            file_info, code = file_download_meta
            print(code)
            if code != "200":
                tabledb.update("yunpan_link", update_data={'file_is_download': code}, where_data={'link_id': link_id})
            else:
                durl = file_info["downurl"]
                tabledb.update("yunpan_link", update_data={'file_download_url': durl}, where_data={'link_id': link_id})
        time.sleep(random.randint(5, 10))

import tornado.ioloop
import tornado.web

class MainHandler(tornado.web.RequestHandler):
    def get(self):

        userid = self.get_argument("userid", "")
        file_id = self.get_argument("file_id","")
        file_chk = self.get_argument("file_chk","")
        print(userid)
        if userid =="" or file_id=="" or file_chk=="":
            self.write("参数为空")
            return

        file_download_meta = chengtong_util.get_file_download_url(userid, file_id, file_chk)
        if file_download_meta is not None:
            file_info, code = file_download_meta
            #print(code)
            if code != "200":
                self.set_status(code)
                #pass
                #tabledb.update("yunpan_link", update_data={'file_is_download': code}, where_data={'link_id': link_id})
            else:
                durl = file_info["downurl"]
                self.redirect(durl)
                #tabledb.update("yunpan_link", update_data={'file_download_url': durl}, where_data={'link_id': link_id})

def make_app():
    return tornado.web.Application([
        (r"/", MainHandler),
    ])

if __name__ == "__main__":
    app = make_app()
    app.listen(9000)
    tornado.ioloop.IOLoop.current().start()