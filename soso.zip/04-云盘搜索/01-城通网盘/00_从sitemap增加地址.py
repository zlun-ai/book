# -*- coding:utf-8 -*-
import os
import sys
sys.path.append("../")

import netutil
import fileutil
import urllib
import netdetect
import time
import random
import stringutil
import htmlutil
import isbnutil
import tabledb
import google_page_util
import re
def extract_urls(text):
    pattern = r'http[:0-9a-zA-Z\-_\.%\?=/\\]{10,}'
    x = re.findall(pattern, text)
    return x
'''
本程序为根据关键词得到pdf文档链接
'''
reset_cookie = True
def startSearch():
    link_url = 'https://http561856124.wordpress.com/sitemap.xml'

    ctx_info = netutil.getcontentfromurl(link_url)

    print("**********************")
    # print(content)
    if ctx_info:
        content = ctx_info["content"]
        if isinstance(content, bytes):

            return

        reset_cookie = True
        all_links = extract_urls(content)
        for link_url in all_links:
            print("add:", link_url)
            link_slug = stringutil.getMD5(link_url)
            data = {
                "link_slug":link_slug,
                "link_name":"",
                "link_url": link_url,
                "link_desc": "",
                "isbn_list":'',
                "content_length_kb":0
            }
            try:
                #pass
                # 判断是否存在
                tabledb.insert("link", data)
            except Exception as ex:
                    print(ex)


# url = 'https://www.baidu.com'
startSearch()
