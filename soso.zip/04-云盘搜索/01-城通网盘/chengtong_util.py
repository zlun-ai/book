import os
import random
import sys
sys.path.append("../")
import urlutil
import netutil
import json

def get_dir_info_req_url(url, password = ""):
    #https://url61.ctfile.com/d/12483661-56490181-35997d?p=3333
    info = urlutil.parse_url(url)
    fp = ""
    if "path" in info:
        fp = info["path"]
        fps = fp.split("-")
        if len(fps) != 3:
            return None
    if fp == "":
        return None
    fp = fp.replace("/d/", "d=")
    print(info)
    psw = ""
    if "param" in info:
        if "p" in info["param"]:
            psw = info["param"]["p"][0]
    if psw == "":
        psw = password
    if psw == "":
        return None

    req_url = f"https://webapi.ctfile.com/getdir.php?path=d&{fp}&folder_id=undefined&passcode={psw}&token=0&r=0.07088486041963449"
    return req_url

def get_file_info_req_url(url, password = ""):
    #https://url64.ctfile.com/f/2447364-977150860-3688b0?p=2171
    #https://webapi.ctfile.com/getfile.php?path=f&f=2447364-977150860-3688b0&passcode=2171&token=0&r=0.07088486041963449
    info = urlutil.parse_url(url)
    fp = ""
    if "path" in info:
        fp = info["path"]
        fps = fp.split("-")
        if len(fps) != 3:
            return None
    if fp == "":
        return None
    fp = fp.replace("/f/","f=")
    print(info)
    psw = ""
    if password !="":
        psw = password
    if "param" in info and psw == "":
        if "p" in info["param"]:
            psw = info["param"]["p"][0]
    if psw == "":
        return None

    req_url = f"https://webapi.ctfile.com/getfile.php?path=f&{fp}&passcode={psw}&token=0&r=0.07088486041963449"
    return req_url



def get_dir_info(url):
    req_url = get_dir_info_req_url(url)
    print(f"req_url=", req_url)
    if req_url is None:
        return None
    ctx_info = netutil.getcontentfromurl(req_url, proxy=False)
    if ctx_info is None:
        print("ctx_info is none,", req_url)
        return
    if ctx_info:
        content = ctx_info["content"]
        final_url = ctx_info["final_url"]
        if "404: Not Found" == content:
            #table = "all_links"
            #tabledb.update(table, update_data={'link_status': 1}, where_data={'link_id': link_id})
            return None
        print(content)
        get_dir_meta_info(content)

def get_dir_meta_info(req_contet):
    data = json.loads(req_contet)
    print(data)
    code = data["code"]
    if code != 200:
        print(f"code = {code}")
        return None
    meta = data["file"]
    file_info = {}
    file_info["folder_name"] = meta["folder_name"]

    file_info["folder_time"] = meta["folder_time"]  # 上传时间

    file_info["userid"] = meta["userid"]
    file_info["username"] = meta["username"]
    file_info["folder_id"] = meta["folder_id"]
    print(file_info)
    return file_info

def get_file_info(url, password = ""):
    req_url = get_file_info_req_url(url, password)
    print(f"req_url=", req_url)
    if req_url is None:
        return None
    ctx_info = netutil.getcontentfromurl(req_url, proxy=False)
    if ctx_info is None:
        print("ctx_info is none,", req_url)
        return None
    if ctx_info:
        content = ctx_info["content"]
        final_url = ctx_info["final_url"]
        if "404: Not Found" == content:
            #table = "all_links"
            #tabledb.update(table, update_data={'link_status': 1}, where_data={'link_id': link_id})
            return None
        print(content)
        return get_file_meta_info(content)

def get_file_meta_info(req_contet):
    data = json.loads(req_contet)
    print(data)
    code = data["code"]
    if code != 200:
        print(f"code = {code}")
        return None, code

    meta = data["file"]
    file_info = {}
    file_info["file_name"] = meta["file_name"]
    file_info["file_size"] = meta["file_size"]
    file_info["file_time"] = meta["file_time"] #上传时间
    if "" in meta:
        file_info["file_dir"] = meta["file_dir"] # #/d/2447364-39636383-1751681409-7e90790e53002f78 所在目录
    else:
        file_info["file_dir"] = ''
    file_info["userid"] = meta["userid"]
    file_info["username"] = meta["username"]
    file_info["file_id"] = meta["file_id"]
    file_info["file_chk"] = meta["file_chk"]
    print(file_info)
    return file_info, str(code)

def get_file_download_url(uid, fid, file_chk,):
    rd = random.random()

    #https://webapi.ctfile.com/get_file_url.php?uid=19101858&fid=507744983&file_chk=965b0c74af24b51e857f2fdbe36dbdd8&app=0&acheck=2&rd=0.1629115526084972
    req_url = f"https://webapi.ctfile.com/get_file_url.php?uid={uid}&fid={fid}&file_chk={file_chk}&app=0&acheck=2&rd={rd}"

    ctx_info = netutil.getcontentfromurl(req_url, proxy=False)
    if ctx_info is None:
        print("获取下载地址 is none,", req_url)
        return None
    if ctx_info:
        content = ctx_info["content"]
        final_url = ctx_info["final_url"]
        if "404: Not Found" == content:
            # table = "all_links"
            # tabledb.update(table, update_data={'link_status': 1}, where_data={'link_id': link_id})
            return None
        print(content)
        return get_file_download_meta_info(content)
    return None

def get_file_download_meta_info(req_contet):
    data = json.loads(req_contet)
    print(data)
    code = data["code"]
    if code != 200:
        print(f"code = {code}")
        return None, code

    meta = data
    file_info = {}
    file_info["file_name"] = meta["file_name"]
    file_info["file_size"] = meta["file_size"]
    file_info["downurl"] = meta["downurl"] #上传时间
    print(file_info)
    return file_info, str(code)

#get_dir_info("https://url71.ctfile.com/d/64764571-68351698-5bf66a?p=9111")
#get_file_info("https://url64.ctfile.com/f/2447364-506314534-779463", "2172")
#et_file_download_url("19101858","507744983","965b0c74af24b51e857f2fdbe36dbdd8")

#get_file_info("https://url64.ctfile.com/f/2447364-977150860-3688b0?p=2171")
