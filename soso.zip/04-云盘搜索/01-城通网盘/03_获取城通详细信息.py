# -*- coding:utf-8 -*-
import os
import sys
sys.path.append("../")

import netutil
import fileutil
import urllib
import netdetect
import time
import random
import stringutil
import htmlutil
import isbnutil
import tabledb
import google_page_util
import googletextparser_simple
import chengtong_util
'''
本程序为根据关键词得到pdf文档链接
'''
reset_cookie = True
def startSearch():
    global reset_cookie
    # 获取要下载的链接
    table = '`yunpan_link`'
    like = " and (link_url like '%/f/%') "

    #每次获取一个
    key = tabledb.query(table, keys='link_id, link_url,link_psw', data={'link_status': 0}, like=like, num=1)
    # key = [[0, "python deep learning"]]
    print(key)
    if not key:
        exit(0)
    link_id = key[0][0]
    link_url = key[0][1]
    link_psw = key[0][2]
    print(link_url)

    link_url = link_url.replace("\\","")
    info = chengtong_util.get_file_info(link_url, link_psw)
    print("inf0=",info)
    if info is None:
        tabledb.update("yunpan_link", update_data={'link_status': 1}, where_data={'link_id': link_id})
        return

    print("**********************")
    #print(content)
    file_info, file_status = info
    if file_info is None:
        tabledb.update("yunpan_link", update_data={'link_status': file_status}, where_data={'link_id': link_id})
        return
    if file_info:

        data = {
                    "file_name":file_info["file_name"],
                    "file_size":file_info["file_size"],
                    "file_time":file_info["file_time"],
                    "file_dir":file_info["file_dir"],
                    "userid":file_info["userid"],
            "username": file_info["username"],
            "file_id": file_info["file_id"],
            "link_status":file_status,
            "file_chk": file_info["file_chk"]
        }
        tabledb.update("yunpan_link", update_data=data, where_data={'link_id': link_id})




# url = 'https://www.baidu.com'
# startSearch()
def mainRun():
    isOnline = False
    while True:
        if not isOnline:
            isOnline = netdetect.networkIsOnline()
            if not isOnline:
                print("network is offline")
                time.sleep(random.randint(10, 20))
                continue
        if isOnline:
            startSearch()
            time.sleep(random.randint(5, 10))


##----
mainRun()
