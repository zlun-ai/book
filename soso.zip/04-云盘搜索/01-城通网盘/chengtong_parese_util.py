import os
import sys
sys.path.append("../")
import urlutil
import netutil
import json
import re
import stringutil
import fileutil
import urlutil
import htmlutil
import html

def extract_urls(text):
    pattern = r'http[:0-9a-zA-Z\-_\.%\?=/\\]{10,}'
    x = re.findall(pattern, text)
    return x

def is_valid_psw_url(url):
    if "p=" in url:
        return True
    return False

def get_password(temp_ctx):
    temp_ctx += ">"
    # 去除html
    temp_ctx = htmlutil.filter_tags(temp_ctx, "", True)
    # 还原
    temp_ctx = html.unescape(temp_ctx)
    print("temp ctx=", temp_ctx)

    print("----")
    temp_ctx = temp_ctx.replace("\n","|")
    temp_ctx = temp_ctx.replace("（", "|")
    temp_ctx = temp_ctx.replace("）", "|")
    temp_ctx = temp_ctx.replace("【", "|")
    temp_ctx = temp_ctx.replace("】", "|")
    temp_ctx = temp_ctx.replace("(", "|")
    temp_ctx = temp_ctx.replace(")", "|")
    temp_ctx = temp_ctx.replace("[", "|")
    temp_ctx = temp_ctx.replace("]", "|")
    temp_list = temp_ctx.split("|")
    print(temp_list)
    pass_text = ""
    for temp_ctx in temp_list:
        arr = ["码", "口令", "钥匙", "指令", "碼", "令"]
        flag = False
        for a in arr:
            if a in temp_ctx:
                flag = True
                pass_text += temp_ctx
        if not flag:
            if pass_text == "":
                continue
            else:
                pass_text += temp_ctx

        pattern = "[0-9a-zA-Z]{4,10}"
        all_psw = re.findall(pattern, pass_text)
        if len(all_psw) == 0:
            continue
        if len(all_psw) == 1:
            return all_psw[0]
        for pws in all_psw:
            if len(pws) == 4:
                if stringutil.isAllNumber(pws):
                    return pws

        for pws in all_psw:
            if stringutil.isAllNumber(pws):
                return pws

        for pws in all_psw:
            if len(pws) == 4:
                return pws
        return all_psw[0]
    return ""
def extract_password(content, url):
    tx = content.split(url)
    if len(tx) <=1:
        return ""
    tx = tx[1:]
    for t in tx:
        mx = t.split("http") # 在下一个http之间
        text = mx[0]
        print(text)
        psw = get_password(text)
        if psw != "":
            return psw
    return ""



def pre_content(content):
    content = content.replace("=http", " = http")
    return content
def get_chengtong_file_url(content):
    content = pre_content(content)
    # 提取所有的连接
    ux = [".ctfile.com/f/", ".ctfile.com/d/"]

    links = extract_urls(content)
    print(links)

    all_data = []
    for link in links:
        data = {}
        data["url"] = ""
        data["psw"] = ""
        valid_link = urlutil.get_valid_link(link)
        if not urlutil.isValidLink(valid_link):
            continue
        print("link=",link)
        print(valid_link)
        for u in ux:
            if u in valid_link and " " not in valid_link:
                if is_valid_psw_url(valid_link):
                    data["url"] = valid_link
                    all_data.append(data)
                else:
                    psw = extract_password(content, link)
                    if psw != "":
                        if "?" not in valid_link:
                            valid_link = valid_link+"?p="+psw
                        else:
                            if "p=" not in valid_link:
                                valid_link = valid_link + "&p=" + psw
                        data["url"] = valid_link
                        data["psw"] = psw
                        all_data.append(data)
    print(f"城通链接数量={len(all_data)}")
    return all_data

data = fileutil.get_content("data/test.txt")
print(get_chengtong_file_url(data))
