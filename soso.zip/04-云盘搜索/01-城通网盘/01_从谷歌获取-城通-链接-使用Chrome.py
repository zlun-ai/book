# -*- coding:utf-8 -*-
import os
import sys
sys.path.append("../")

import netutil
import fileutil
import urllib
import netdetect
import time
import random
import stringutil
import htmlutil
import isbnutil
import tabledb
import google_page_util
import googletextparser_simple

'''
本程序为根据关键词得到pdf文档链接
'''
reset_cookie = True
def startSearch():
    global reset_cookie
    # 获取要下载的链接
    table = '`book`'
    like = None  # " and (book_title like '%python%' or book_title like '%java%' or book_title like '%programming%' ) "

    #每次获取一个
    key = tabledb.query(table, keys='book_id, book_name', data={'book_status': 0}, like=like, num=1)
    # key = [[0, "python deep learning"]]
    print(key)
    if not key:
        exit(0)
    key_id = key[0][0]
    key_name = key[0][1]
    print(key_name)
    if key_name == "" or len(key_name) < 3:
        tabledb.update(table, update_data={'book_status': 1}, where_data={'book_id': key_id})
        return
    ori_key_name = key_name
    key_name = urllib.parse.quote(key_name)

    proxy_url = 'http://wordpress.alternativelist.com/api/proxy/index.php?u='
    # proxy_url = 'https://static.tpsort.com/api/proxy/index.php?u='

    # proxy_url = 'https://www.notehope.com/wp-content/uploads/proxy/index.php?u='
    search_key = ''
    url = "https://www.google.com/search?q=%22.ctfile.com%2Ff%2F%22+" + key_name + "&lr=lang_zh-CN&num=30&start=0&newwindow=1&safe=strict"
    google_url = url
    print(google_url)
    #google_url = 'https://www.google.com/search?q=filetype%3Apdf+%22ISBN%22+%22All+right+reserved%22+python%E7%BC%96%E7%A8%8B&hl=en&num=30&start=0&newwindow=1&safe=strict&sca_esv=f5357ae72790bb1e&hl=en&ei=HZ5KaIP4D5G-5OUPkffoiAY&ved=0ahUKEwjD-oeZyeuNAxURH7kGHZE7GmEQ4dUDCBA&uact=5&oq=filetype%3Apdf+%22ISBN%22+%22All+right+reserved%22+python%E7%BC%96%E7%A8%8B&gs_lp=Egxnd3Mtd2l6LXNlcnAiNWZpbGV0eXBlOnBkZiAiSVNCTiIgIkFsbCByaWdodCByZXNlcnZlZCIgcHl0aG9u57yW56iLSPgeUABYAHACeACQAQCYAQCgAQCqAQC4AQPIAQCYAgCgAgCYAwCIBgGSBwCgBwCyBwC4BwDCBwDIBwA&sclient=gws-wiz-serp'
    # return
    # googlebookutil.processfile("test.html", book_name = "Cybersecurity: Methods of Protection (Blue Team Activity)")
    # return
    proxy = False
    if proxy:
        url = stringutil.urlsafe_b64encode(url)
        google_url = proxy_url + url
    print(google_url)
    # time.sleep(1000)

    content = google_page_util.get_google_page(url, reset_cookie)
    print("**********************")
    print(content)
    if content:
        reset_cookie = True
        contentx = htmlutil.filter_tags(content)
        print("content len=" + str(len(contentx)))
        if len(contentx) < 5000:
            time.sleep(random.randint(30, 50))
            return
    if content:
        reset_cookie = False
        fileutil.save_to_file('google-r-2.html', content)
        # print(content[0:500])

        linkInfo = googletextparser_simple.get_search_results(ori_key_name, content)
        h3_num = len(linkInfo)
        updated = True
        if h3_num < 1:
            updated = False
        print(linkInfo)
        if 'did not match any documents' in content.lower():
            updated = True
        updated = True
        save_key = False
        for info in linkInfo:

            link_url = info['url']
            link_desc = info['desc']

            if googletextparser_simple.isValidLink(link_url):

                link_search_name = ori_key_name

                title = info['title']
                link_fix_name = title
                link_fix_name_status = str(info['status'])

                dirname, filename, extend = fileutil.getFilePathInfo(link_url)
                #if not extend.lower() == ".pdf":
                    #continue

                save_key = True

                content_length_kb = ""
                print("add:", link_url, title)
                link_slug = stringutil.getMD5(link_url)
                data = {
                    "link_slug":link_slug,
                    "link_name":stringutil.removeSymbol(link_fix_name).strip(),
                    "link_url": link_url,
                    "link_desc": stringutil.removeSymbol(info["desc"]).strip(),
                    "isbn_list":'',
                    "content_length_kb":0
                }
                try:
                    # 判断是否存在
                    tabledb.insert("link", data)
                except Exception as ex:
                    print(ex)

        if updated:
            print("更新")
            # tabledb.update(table, update_data={'doc_status':1}, where_data={'doc_id':key_id})
            tabledb.update(table, update_data={'book_status': 1}, where_data={'book_id': key_id})
        else:
            print("不更新")


# url = 'https://www.baidu.com'
# startSearch()
def mainRun():
    isOnline = False
    while True:
        if not isOnline:
            isOnline = netdetect.networkIsOnline()
            if not isOnline:
                print("network is offline")
                time.sleep(random.randint(5, 10))
                continue
        if isOnline:
            startSearch()
            time.sleep(random.randint(10, 15))


##----
mainRun()
