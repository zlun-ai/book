import re

def r(file_name):
    pattern = re.compile(r'^[0-9]{1,3}[ ] {0,}[\.。，、\-：]{1,}', re.IGNORECASE)
    file_name = re.sub(pattern, '', file_name)
    file_name = file_name.strip()

    return file_name

x = "122fileadf234df"
print(r(x))

x = "122.fileadf234.df"
print(r(x))

x = "122 fileadf234.df"
print(r(x))

x = "122 - fileadf234.df"
print(r(x))