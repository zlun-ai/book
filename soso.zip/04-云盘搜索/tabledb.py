import stringutil
import pymysql
from pymysql.converters import escape_string

import dbutil

mysql = dbutil.mysql

def query_sql(sql):
    row = mysql.execQuery(sql)
    if len(row) < 1:
        return None
    return row

def insert(table, data):
    sql = "insert into " + table + " "

    keys = []
    vls = []

    for k, v in data.items():
        keys.append(k)
        if isinstance(v, str):
            v = "'" + escape_string(v) + "'"
        else:
            v = str(v)
        vls.append(v)

    k = ",".join(keys)
    v = ",".join(vls)
    sql = sql + "(" + k + ") values (" + v + ")"
    # print(sql,flush = True)
    flag = mysql.execSql(sql)
    return flag


def isExist(table, data):
    sql = "select * from " + table + " where "
    keys = []
    vls = []
    w = ''
    for k, v in data.items():
        if isinstance(v, str):
            v = "'" + escape_string(v) + "'"
        else:
            v = str(v)
        if w == "":
            w += k + "=" + v
        else:
            w += " and " + k + "=" + v

    sql = sql + w
    # print(sql)
    row = mysql.execQuery(sql)
    if len(row) < 1:
        return False
    return True


def query(table, keys, data, like = None, orderby=None, num=None):
    sql = "select " + keys + " from " + table + " where "
    keys = []
    vls = []
    w = ''
    for k, v in data.items():
        if isinstance(v, str):
            v = "'" + escape_string(v) + "'"
        else:
            v = str(v)
        if w == "":
            w += k + "=" + v
        else:
            w += " and " + k + "=" + v

    sql = sql + w
    if like is not None:
        sql = sql + "  " + like
    if orderby is not None:
        sql = sql + " order by " + orderby
    if num is not None:
        sql = sql + " limit 0, " + str(num)
    #print(sql)
    row = mysql.execQuery(sql)
    if len(row) < 1:
        return None
    return row



def delete(table, where_data):
    sql = "delete from " + table + " "
    w = ''
    for k, v in where_data.items():
        if isinstance(v, str):
            v = "'" + escape_string(v) + "'"
        else:
            v = str(v)
        if w == "":
            w += " where " + k + "=" + v
        else:
            w += " and " + k + "=" + v
    sql = sql + w
    print(sql, flush=True)
    flag = mysql.execSql(sql)
    return flag


def update(table, update_data, where_data):
    sql = "update " + table + " set "
    w = ''
    for k, v in update_data.items():
        if isinstance(v, str):
            v = "'" + escape_string(v) + "'"
        else:
            v = str(v)
        if w == "":
            w += k + "=" + v
        else:
            w += " ," + k + "=" + v
    sql = sql + w
    w = ''
    for k, v in where_data.items():
        if isinstance(v, str):
            v = "'" + escape_string(v) + "'"
        else:
            v = str(v)
        if w == "":
            w += " where " + k + "=" + v
        else:
            w += " and " + k + "=" + v
    sql = sql + w
    print(sql, flush=True)
    flag = mysql.execSql(sql)
    return flag

# table = 'link'
# data={'link_name':'good', 'link_url':'baidu', 'type':0}

# query(table, 'ss,ee', data)