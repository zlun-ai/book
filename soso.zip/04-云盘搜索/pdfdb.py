import pymysql

import dbutil
mysql = dbutil.mysql

def buildPost():
    p = {}
    p['post_title'] = post_title
    p['post_content'] = post_content
    p['post_tag']= post_tag
    p['post_cat']= post_cat
    
    #meta
    p['post_meta_unique'] = post_meta_unique
    p['post_meta_file_name'] = post_meta_file_name
    p['post_meta_file_download'] = post_meta_file_download
    
    return

def getAllDraftPosts(num=100):
    publis_posts = []
    sql="select ID ,post_content ,post_title from wp_posts where post_status not like '%i.onlineimage.com%' and  post_status='draft' and post_type='post' order by ID desc"
    posts = mysql.execQuery(sql)
    return posts

def getAllPublishedPosts(num=100):
    publis_posts = []
    sql="select ID ,post_content ,post_title from wp_posts where post_status='publish' and post_type='post' order by post_modified desc"
    posts = mysql.execQuery(sql)
    if not posts:
        return None
    for px in posts:
        p={}
        p['post_title'] = px[2]
        p['post_content'] = px[1]
        
        #tag
        '''
        SELECT t2.term_id,t2.name, t1.taxonomy FROM `wp_term_taxonomy` t1 inner join wp_terms t2 on t1.term_id = t2.term_id
        '''
        #object_id    term_taxonomy_id    term_order    term_taxonomy_id    name    taxonomy
        sql_2 = "select * from wp_term_relationships t4 left join (SELECT t1.    term_taxonomy_id,t2.name, t1.taxonomy FROM `wp_term_taxonomy` t1 inner join wp_terms t2 on t1.term_id = t2.term_id) t3 on t4.term_taxonomy_id = t3.term_taxonomy_id where t4.object_id="+str(px[0])
        terms = mysql.execQuery(sql_2)
        p['post_tag']= ""
        p['post_cat']= ""
        if terms:
            for t in terms:
                taxonomy = t[5]
                if taxonomy == 'category':
                    if p['post_cat'] =="":
                        p['post_cat'] = t[4]
                    else:
                        p['post_cat'] += ","+t[4]
                if taxonomy == 'post_tag':
                    if p['post_tag'] =="":
                        p['post_tag'] = t[4]
                    else:
                        p['post_tag'] += ","+t[4]
        #meta
        sql_3 = "SELECT * FROM  `wp_postmeta` where post_id="+str(px[0])
        metas = mysql.execQuery(sql_3)
        p['post_meta_unique'] = ''
        p['post_meta_file_name'] = ''
        p['post_meta_file_download'] = ''
        
        if metas:
            for m in metas:
                if m[2] == 'File_Name':
                    p['post_meta_file_name'] = m[3]
                if m[2] == 'UniqueID':
                    p['post_meta_unique'] = m[3]
                if m[2] == 'File_Download_Link':
                    p['post_meta_file_download'] = m[3]   
        publis_posts.append(p)
        
    print(publis_posts)
    return publis_posts            
             
def hasTag(tag_name):
    meta_key = pymysql.escape_string(meta_key)
    meta_value = pymysql.escape_string(meta_value)
    sql = "select post_id from wp_postmeta where meta_key ='"+meta_key+"' and meta_value='"+meta_value+"'"
    result = mysql.execQuery(sql)
    if not result:
        return False
    if len(result)>0:
        return True
    
def addTag(tag_name):  
    if hasMeta(pid,meta_value, meta_key):
        print("exist")
        return True
    meta_key = pymysql.escape_string(meta_key)
    meta_value = pymysql.escape_string(meta_value)
    sql="insert into wp_postmeta (post_id, meta_key, meta_value) values("+str(pid)+",'"+meta_key+"','"+meta_value+"')"
    print(sql)
    return mysql.execSql(sql)
def getNeedDownloadLinks():
    sql = """
    SELECT post_id, meta_value FROM `wp_postmeta` where meta_key='File_Name' and `post_id` not in (select t.post_id from wp_postmeta t where t.meta_key='File_download_link'  )
      """
    result = mysql.execQuery(sql)
    return result
def fixPostImage(content,ID):
    content = pymysql.escape_string(content)
    sql="update wp_posts set post_content='"+content+"' where ID="+str(ID)
    print(sql)
    
    mysql.execSql(sql)        
#getNeedDownloadLinks()