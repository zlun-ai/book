# -*- coding:utf-8 -*-
import os.path

import netutil
import fileutil
import urllib
import time
import random
import stringutil
import htmlutil
import isbnutil
import tabledb

# 将图书标题写入到db
def add_book(book_name):
    book_name = book_name.lower().strip()
    slug = stringutil.getMD5(book_name)

    table = "book"
    data = {"book_slug":slug, "book_name":book_name}
    tabledb.insert(table, data)

book_json = r"D:\04-个人项目\00-图书\书籍信息\book.douban.com-data-20250610.json"
book_data = fileutil.read_json(book_json)
for slug in book_data:
    item = book_data[slug]
    book_name = item["标题"].strip()
    book_subname = item["副标题"].strip()
    book_name = stringutil.removeSymbol(book_name).strip()
    book_subname = stringutil.removeSymbol(book_subname).strip()
    #不能是英文
    if not stringutil.containsNonAscii(book_name):
        continue
    if book_subname == "" and len(book_name) < 3:
        continue
    try:
        add_book(book_name)
    except:
        pass
    if book_subname != "":
        book_long_name = book_name+"："+book_subname
        try:
            add_book(book_long_name)
        except:
            pass

