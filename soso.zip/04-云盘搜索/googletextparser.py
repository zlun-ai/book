import urllib.parse
from bs4 import BeautifulSoup
import fileutil
import io
import sys
import re
import json
from unidecode import unidecode
import htmlutil
import docutil
import nltkutil

def isValidLink(link):
    if link.count('.google.com') > 0:
        return False
    if link.count('//google.com') > 0:
        return False
    if  not link.startswith("https://") and not link.startswith("http://"):
        return False
    return True
    
def removeHTMLTagName(soup, taglist=['script', 'style']):
    for i in taglist:
        [x.unwrap() for x in soup.find_all(i)]
    
    return str(soup)

def removeStyle(soup):
    [x.extract() for x in soup.find_all('style')]
    return soup

def removeScript(soup):
    [x.extract() for x in soup.find_all('script')]
    return soup

def removeHTMLTag(soup, taglist=['script', 'style']):
    for i in taglist:
        [x.extract() for x in soup.find_all(i)]
    
    return str(soup)

def getTableOfContents(html_doc):
    soup = BeautifulSoup(html_doc, 'html.parser')
    table_body = soup.find_all("div", "card")
    #print(table_body)
    return table_body
    
def getSearchResult(soup):   

    #Gx5Zad fP1Qef xpd EtOod pkphOe
    #Gx5Zad fP1Qef xpd EtOod pkphOe
    def has_a_characters(css_class):
        return css_class is not None and ("Gx5Zad" in css_class or "fP1Qef" in css_class or "xpd" in css_class)

    results = soup.find_all("div", class_=has_a_characters)
    links = []
    for r in results:
        text = str(r)
        if "<a " in text and "<h3 " in text:
            links.append(r)
    
    print(links)
    return links
    
def parseEachItem(card):
    #print(card)
    card = str(card)
    #print(dir(card))
    soup = BeautifulSoup(card, "html.parser")
    
    #title,link,desc
    titles = soup.find_all("h3")
    if len(titles) < 1:
        return None
    title = titles[0].string
    
    ##link_a = titles[0].parent #
    #print(link_a)
    #if not link_a:
        #return None
    #link_a_name = link_a.name
    #print(link_a_name)
    #if link_a_name != 'a':
        #print('h3 parent is <a>')
        #exit(0)
        #return None
    links = soup.find_all("a")
    if len(links) > 1:
        return None
    link_a = links[0]
    url = link_a.get('href')
    if "&url=" in url:
        ux = url.split("&url=")
        url = ux[1]
        if "&" in url:
            ux = url.split("&")
            url = ux[0]

    if not isValidLink(url):
        print(url)
        return None
    
    #desc
    #BNeawe s3v9rd AP7Wnd

    # 获取描述
    parent_box = t.parent  #
    # 获取兄弟节点
    desc = ""
    desc_box = parent_box
    for i in range(7):
        try:
            desc_box = desc_box.next_sibling
            desc_text = desc_box.text
            if len(desc_text) > len(desc):
                desc = desc_text
        except:
            continue
    #desc = ''
    #descs = soup.find_all("span", "st")
    #print(descs)
    #if len(descs) >= 1:
        #desc = descs[0]
        #print(desc.get_text())
        #desc = str(desc)
        
    return title, link_url, desc

txt = '''
<div class="g"><div data-hveid="CKsBEAA" data-ved="2ahUKEwii8dSYivzyAhWDGFkFHduYDGMQFSgAegUIqwEQAA"><div class="tF2Cxc"><div class="yuRUbf" style="white-space:nowrap"><a href="https://dl.uswr.ac.ir/bitstream/Hannan/139708/1/9781118136737.pdf" data-ved="2ahUKEwii8dSYivzyAhWDGFkFHduYDGMQFnoFCKkBEAE" onmousedown="return rwt(this,'','','','','AOvVaw0MBNfwyJwzkR3G5aeZZGGT','','2ahUKEwii8dSYivzyAhWDGFkFHduYDGMQFnoFCKkBEAE','','',event)" target="_blank" rel="noopener"><br><h3 class="LC20lb DKV0Md">DSM-5 in Action</h3><div class="TbwUpd NJjxre"><cite class="iUh30 Zu0yb qLRx3b tjvcx">https://dl.uswr.ac.ir<span class="dyjrff qzEoUe"> › bitstream › Hannan</span></cite></div></a><div class="B6fmyf"><div class="TbwUpd"><cite class="iUh30 Zu0yb qLRx3b tjvcx">https://dl.uswr.ac.ir<span class="dyjrff qzEoUe"> › bitstream › Hannan</span></cite></div><div class="eFM0qc"><span class="ZGwO7 C0kchf NaCKVc VDgVie">PDF</span></div></div></div><div class="IsZvec"><div class="VwiC3b yXK7lf MUxGbd yDYNvb lyLwlc lEBKkf" style="-webkit-line-clamp:2"><span>such as the <em>Diagnostic</em> and <em>Statistical Manual</em> of. <em>Mental Disorders</em>, <em>5th ed</em>. (<em>DSM</em>-<em>5</em>; American. <em>Psychiatric</em> Association, 2013) and the Interna-.</span></div></div><div jscontroller="K6HGfd" id="eob_132" jsdata="fxg5tf;_;B5ueEw" jsaction="rcuQ6b:npT2md" data-ved="2ahUKEwii8dSYivzyAhWDGFkFHduYDGMQ2Z0BegUIqwEQAg"></div></div></div></div>
'''
#print(parseEachItem(txt))
    
#file = 'F:\\All-Books\\192a84d98b500f01cce7faaf12d99148.html'

def processFile(link_slug, file):
    content = fileutil.readFile(file)
    if not content:
        return
    #print(type(content))
    cards = getTableOfContents(content)
    #print(dir(cards))
    #print(len(cards))
    
    #print(type(cards))
    item={}
    for c in cards:
        #print(dir(c))
        #print(type(c))
        item_name, sub_item_name = parseEachItem(c) #<class 'bs4.element.Tag'>
        if len(item_name) > 2:
            item[item_name] = sub_item_name
    #if not item:
       # return
    print(item)
    item_string = json.dumps(item)
    print(type(item_string))
    print(item_string)
    item_self =  json.loads(item_string)
    
    print(type(item_self))
    print(item_self)
    
    crawldb.updateLinkInfo(link_slug, item_string)
    
def process(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    results = getSearchResult(soup)
    
    linkInfo = []
    for r in results:
        item = parseEachItem(r)
        if item is None:
            continue
        title = docutil.getLinkTitle(item[0],item[2],item[1], doc_type='pdf')
        
        print(item)
        print(title)
        info={}
        info['title'] = title
        info['link'] = item
        linkInfo.append(info)
    return linkInfo
content = fileutil.readFile('google-r-2.html')
process(content)