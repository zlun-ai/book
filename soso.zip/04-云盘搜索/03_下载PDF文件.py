# -*- coding:utf-8 -*-
import fileutil
import pdfutil
import isbnutil
import random
import os
import time
import dbutil
import sys
import stringutil
import re
import htmlutil
import html
import tabledb
import downloadutil
import fileutil
import datetimeutil
import concurrent.futures, threading

def hasDownload(filename):
    dirs = [r'D:\ProgramData\BookDataset\02-城通']
    
    for d in dirs:
        f = d+"\\"+filename
        if fileutil.fileexist(f):
            return True
    return False
MAX_FREE_SPACE = 1024 * 1024 * 1024

def init():
    global MAX_FREE_SPACE
    free_space = fileutil.getDiskFreeSpaceByte('D:\\')
    if free_space < MAX_FREE_SPACE:
        return None
    #
    #遍历所有的链接
    table = "yunpan_link"
    keys = 'link_id, file_name, file_download_url'
    data= {'file_is_download':0}
    links = tabledb.query(table, keys, data,  num = None)

    lx = len(links)
    all_data = [{"link_id": x[0], "file_name":x[1], "file_download_url":x[2]} for x in links]
    print(f"all_data={len(all_data)}")
    print("start")
    return all_data

def run(data, concurrency = 2):
    with concurrent.futures.ProcessPoolExecutor(max_workers = concurrency) as executor:
        futures = [executor.submit(startDownload(data[i])) for i in range(concurrency)]  # 提交多个任务
        for future in concurrent.futures.as_completed(futures):  # 按完成顺序获取结果
            #print(future.result())
            pass

def startDownload(item):
    table = "link"
    link_url = item["file_download_url"]
    print(f"link_url={link_url}")
    link_id = item["link_id"]
    file_name = item["file_name"]
    print(link_url)
    if link_url is None:
        return

    if link_url !="":
        #if not link_url.endswith(".pdf"):
            #return
        # set visite time
        current_time = datetimeutil.getCurrent()
        link_info = "visit_date_time = '" + current_time + "'"
        # 获取url后缀
        #dirname, filename, extend = fileutil.getFilePathInfo(link_url)
        #if extend.lower().strip() !=".pdf":
           # return

        filename = file_name#link_slug + ".pdf"
        if hasDownload(filename):
            print("已存在")
            return
        f = "D:\\ProgramData\\BookDataset\\02-城通\\"+filename
        print(f)
        print(link_url)
        status = downloadutil.download(link_url, f)
        
        if status[0]:
            full_pdf = pdfutil.isFullPdf(f)
            if not full_pdf:
                print(f + " is not a full pdf")
                fileutil.deleteFile(f)
            else:
                #更新大小
                #update
                update_data = {"link_download": 1, 'link_date': current_time}
                where_data = {"link_slug": link_slug}
                tabledb.update(table, update_data, where_data)
        else:
            update_data = {'link_date': current_time}
            where_data = {"link_slug": link_slug}
            tabledb.update(table, update_data, where_data)
            # check is full pdf
            if fileutil.fileexist(f):
                if not fileutil.isUsedByOtherApp(f):
                    full_pdf = pdfutil.isFullPdf(f)
                    if not full_pdf:
                        print(f + " is not a full pdf")
                        fileutil.deleteFile(f)
        time.sleep(1)
#
if __name__ == '__main__':
    dbutil.connect()
    all_data = init()
    lx = len(all_data)
    for i in range(0, lx, 2):
        sub_data = all_data[i:i + 2]
        run(sub_data)
#startDownload()