# -*- coding:utf-8 -*-
import fileutil
import pdfutil
import isbnutil
import random
import os
import time
import netutil
import sys, fitz
import stringutil
import googlebookutil
import re
from bs4 import BeautifulSoup
import htmlutil
import html
import bookdb
import linkdb

#load all links
links = linkdb.getNeedMoveLinks()
#print(links)  
#link_id,link_name,link_url,link_content  
def getLinkInfoFromWordPresPost(link_post_name, link_content):
    url = 'https://book.beginnerlibrary.com/'+link_post_name+"/"
    link_content = htmlutil.filter_taglist(link_content, taglist = ['p','img','strong','span'])
    #print(link_content)
    link_content = link_content.replace("\n",' ')
    return url,link_content 
                                        
if links:
    for link in links:
        link_url = link[2]
        link_title = link[1]
        link_desc  = link[3]
        link_id = link[0]
        
        '''link_url, link_desc = getLinkInfoFromWordPresPost(link_url, link_desc)
        link_title = '[PDF] '+link_title+" PDF Free Download"
        print(link_title)
        print(link_desc)
        print(link_url)'''
        googlebookutil.processLink(link_url, link_title, link_desc, book_name = None)  
        #linkdb.updateMoveLink(link_id, info = ' post_author = 2' )#info = 'is_send=1')
        
        linkdb.updateMoveLink(link_id, info = 'is_send=1')