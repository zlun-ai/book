<?php


function mbRepeatToLength($str, $length=4, $encoding = 'UTF-8') {
    if ($length <= 0 || empty($str)) {
        return '';
    }
    
    $strLength = mb_strlen($str, $encoding);
    $repeats = ceil($length / $strLength);
    $result = '';
    
    for ($i = 0; $i < $repeats; $i++) {
        $result .= $str;
    }
    
    return $result;#mb_substr($result, 0, $length, $encoding);
}


function get_fenci_words($text){
$gbk_text = mb_convert_encoding($text, 'GBK', 'UTF-8');

	$current_dir = dirname(__FILE__);
	require_once $current_dir.'/pscws23/pscws2.class.php';
	$pscws = new PSCWS2($current_dir.'/pscws23/dict/dict.xdb');
	
	$seg_list = $pscws->segment($gbk_text);
	$result = [];
	foreach ($seg_list as $word) {
		// 跳过纯标点、符号、空白字符
		$word = mb_convert_encoding($word, 'UTF-8', 'GBK');
		if (!preg_match('/^[\p{P}\p{S}\p{Z}]+$/u', $word)) {
			$result[] = $word;
		}
	}
	
	//$result = array_values(array_unique(array_filter($seg_list, function($item) { return strlen((string)$item) >= 1; })));
	//print_r($result);
	//重复，确保最短为4
	$x=array();
	foreach($result as $t){
		if(!is_numeric($t)){
			$t=mbRepeatToLength($t);
		}
		
		$x[]=$t;
	}
	
	return $x;
}
//print_r(get_fenci_words("威尔斯经典科幻丛书（套装共7册）.epub"));



?>